////lxm
////server.cpp
//#include <iostream>
//#include <fstream>
//#include <string>
//#include <winsock2.h>
//#include <ws2tcpip.h> 
//#include <ctime>
//#include <chrono>
//#include <iomanip>
//#include <sstream>
//#include <filesystem>
//#include <cstdint>
//#include <cstring>
//
//using namespace std;
//#define _WINSOCK_DEPRECATED_NO_WARNINGS
//
//#define serverport 55555 // ��̬�˿ڷ�Χ���ʺ���Ϊ�Զ������˿�
//#define clientport 55556 // �����˲�ͬ��Ҳ�ڶ�̬��Χ��
//const int TIMEOUT = 1000;
//const int MAX_SEQ = 1;
//int Seq = 0;
//
//SOCKET clientsocket;
//SOCKADDR_IN clientaddr;
//string clientip = "127.0.0.1";
//int clientaddrlen = sizeof(clientaddr);
//SOCKET serversocket;
//SOCKADDR_IN serveraddr;
//string serverip = "127.0.0.1";
//int serveraddrlen = sizeof(serveraddr);
//
//#pragma comment(lib, "ws2_32.lib")
//
////const int BUFFER_SIZE = 1024;
////
////struct Packet {
////    int seq;
////    int checksum;
////    char data[BUFFER_SIZE];
////};
//const int MSS = 1024; // Maximum Segment Size
//const uint16_t CFH = 0x1; // Example flag for Custom Flag Header
//const uint16_t ACK = 0x2; // ACK flag
//const uint16_t SYN = 0x4; // SYN flag
//const uint16_t FIN = 0x8; // FIN flag
//
//struct Packet {
//    uint32_t SrcPort; // Source port
//    uint32_t DstPort; // Destination port
//    uint32_t Seq;     // Sequence number
//    uint32_t Ack;     // Acknowledgment number
//    uint32_t Length;  // Data length
//    uint16_t Flag;    // Flags
//    uint16_t Check;   // Checksum
//    char Data[MSS];   // Payload
//
//    // Constructor to initialize fields
//    Packet()
//        : SrcPort(0), DstPort(0), Seq(0), Ack(0), Length(0), Flag(0), Check(0) {
//        memset(this->Data, 0, MSS);
//    }
//
//    // Flag manipulation methods
//    void Set_CFH() { this->Flag |= CFH; }
//    bool Is_CFH() const { return this->Flag & CFH; }
//
//    void Set_ACK() { this->Flag |= ACK; }
//    bool Is_ACK() const { return this->Flag & ACK; }
//
//    void Set_SYN() { this->Flag |= SYN; }
//    bool Is_SYN() const { return this->Flag & SYN; }
//
//    void Set_FIN() { this->Flag |= FIN; }
//    bool Is_FIN() const { return this->Flag & FIN; }
//
//    // Calculate and set checksum
//    void Set_Check() {
//        this->Check = 0; // Clear checksum before calculation
//        uint32_t sum = 0;
//        uint16_t* p = reinterpret_cast<uint16_t*>(this);
//        for (int i = 0; i < sizeof(*this) / 2; i++) {
//            sum += *p++;
//            while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
//        }
//        this->Check = ~(sum & 0xFFFF); // Complement the final sum
//    }
//
//    // Validate checksum
//    bool CheckValid() const {
//        uint32_t sum = 0;
//        const uint16_t* p = reinterpret_cast<const uint16_t*>(this);
//        for (int i = 0; i < sizeof(*this) / 2; i++) {
//            sum += *p++;
//            while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
//        }
//        return (sum & 0xFFFF) == 0xFFFF; // Valid if sum is all 1s
//    }
//
//    // Print packet details
//    void Print_Packet() const {
//        std::cout << "Packet Details:\n";
//        std::cout << "  SrcPort: " << SrcPort << "\n";
//        std::cout << "  DstPort: " << DstPort << "\n";
//        std::cout << "  Seq: " << Seq << "\n";
//        std::cout << "  Ack: " << Ack << "\n";
//        std::cout << "  Length: " << Length << "\n";
//        std::cout << "  Flag: 0x" << std::hex << Flag << std::dec << "\n";
//        std::cout << "  Checksum: 0x" << std::hex << Check << std::dec << "\n";
//        std::cout << "  Data: " << std::string(Data, Data + Length) << "\n";
//    }
//};
////int calculateChecksum(Packet& packet) {
////    int sum = packet.seq;
////    for (int i = 0; i < BUFFER_SIZE; i++) {
////        sum += static_cast<unsigned char>(packet.data[i]);
////    }
////    return sum;
////}
//
//string getCurrentTime() {
//    auto now = chrono::system_clock::now();
//    time_t timeNow = chrono::system_clock::to_time_t(now);
//    tm localTime;
//    localtime_s(&localTime, &timeNow);
//    stringstream ss;
//    ss << put_time(&localTime, "%Y-%m-%d %H:%M:%S");
//    return ss.str();
//}
//
////void logEvent(const string& event, const Packet& packet, const string& extra = "") {
////    cout << "[" << getCurrentTime() << "] " << event
////        << " Seq: " << packet.seq
////        << ", Checksum: " << packet.checksum
////        << (extra.empty() ? "" : ", " + extra) << endl;
////}
//
////string determineFileExtension(const string& packet) {
////    if (packet.find("JFIF") != string::npos || packet.find("Exif") != string::npos) {
////        return ".jpg";
////    }
////    else if (packet.find("\n") != string::npos || packet.find("\r\n") != string::npos) {
////        return ".txt";
////    }
////    else {
////        return ".bin"; // Default binary file
////    }
////}
//int Send(Packet& msg)
//{
//    msg.SrcPort = serverport;
//    msg.DstPort = clientport;
//    msg.Set_Check();
//    return sendto(serversocket, (char*)&msg, sizeof(msg), 0, (SOCKADDR*)&clientaddr, clientaddrlen);
//}
//
////void receiveFile(SOCKET& sock, sockaddr_in& clientAddr) {
////    string filePath = "received_file";
////    ofstream file;
////
////    int expectedSeq = 0;
////    Packet packet;
////    char ackBuffer[sizeof(int)];
////    int clientLen = sizeof(clientAddr);
////
////    auto start = chrono::high_resolution_clock::now();
////    int bytesReceived = 0;
////    bool fileOpened = false;
////
////    cout << "Waiting for file transmission..." << endl;
////    while (true) {
////        int bytesReceivedNow = recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////        if (bytesReceivedNow > 0) {
////            logEvent("Packet received", packet);
////
////            if (calculateChecksum(packet) == packet.checksum) {
////                if (packet.seq == -1) {
////                    logEvent("End-of-transmission signal received", packet);
////                    break;
////                }
////
////                if (!fileOpened) {
////                    string packet(packet.data, BUFFER_SIZE);
////                    string extension = determineFileExtension(packet);
////                    filePath += extension;
////                    file.open(filePath, ios::binary);
////                    if (!file.is_open()) {
////                        cerr << "Failed to open output file." << endl;
////                        return;
////                    }
////                    fileOpened = true;
////                }
////
////                if (packet.seq == expectedSeq) {
////                    file.write(packet.data, BUFFER_SIZE);
////                    bytesReceived += bytesReceivedNow;
////
////                    logEvent("Packet written to file", packet);
////
////                    memcpy(ackBuffer, &expectedSeq, sizeof(expectedSeq));
////                    sendto(sock, ackBuffer, sizeof(ackBuffer), 0, (sockaddr*)&clientAddr, clientLen);
////                    logEvent("ACK sent", packet, "ACK: " + to_string(expectedSeq));
////
////                    expectedSeq = (expectedSeq + 1) % 2;
////                }
////                else {
////                    logEvent("Unexpected sequence number, discarding packet", packet);
////                }
////            }
////            else {
////                logEvent("Invalid checksum, discarding packet", packet);
////            }
////        }
////    }
////
////    auto end = chrono::high_resolution_clock::now();
////    double duration = chrono::duration<double>(end - start).count();
////    double throughput = (bytesReceived / 1e6) / duration;
////    cout << "File received successfully. Saved as " << filePath << ". Time: " << duration << " seconds, Throughput: " << throughput << " MB/s" << endl;
////
////    if (file.is_open()) {
////        file.close();
////    }
////}
//bool connect()
//{
//    Packet con_msg[3];
//    while (true)
//    {
//        // * First-Way Handshake
//        if (recvfrom(serversocket, (char*)&con_msg[0], sizeof(con_msg[0]), 0, (SOCKADDR*)&clientaddr, &clientaddrlen) > 0)
//        {
//            // cout <<"[Server] "<< "Receive Message from Router! -- First-Way Handshake" << endl;
//            con_msg[0].Print_Packet();
//            if (!(con_msg[0].Is_SYN() && con_msg[0].CheckValid() && con_msg[0].Seq == Seq + 1))
//            {
//                cout << "Error Message!" << endl;
//                exit(EXIT_FAILURE);
//            }
//            Seq = con_msg[0].Seq;
//            // * Second-Way Handshake
//            con_msg[1].Ack = con_msg[0].Seq;
//            con_msg[1].Seq = ++Seq;
//            con_msg[1].Set_ACK();
//            con_msg[1].Set_SYN();
//            int re = Send(con_msg[1]);
//            float msg2_Send_Time = clock();
//            if (re > 0)
//            {
//                // cout <<"[Server] "<< "Send Message to Router! -- Second-Way Handshake" << endl;
//                con_msg[1].Print_Packet();
//                // * Third-Way Handshake
//                while (true)
//                {
//                    if (recvfrom(serversocket, (char*)&con_msg[2], sizeof(con_msg[2]), 0, (SOCKADDR*)&clientaddr, &clientaddrlen) > 0)
//                    {
//                        // cout <<"[Server] "<< "Receive Message from Router! -- Third-Way Handshake" << endl;
//                        con_msg[2].Print_Packet();
//                        if (!(con_msg[2].Is_ACK() && con_msg[2].CheckValid() && con_msg[2].Seq == Seq + 1 && con_msg[2].Ack == con_msg[1].Seq))
//                        {
//                            cout << "Error Message!" << endl;
//                            exit(EXIT_FAILURE);
//                        }
//                        Seq = con_msg[2].Seq;
//                        // cout <<"[Server] "<< "Third-Way Handshake is successful!" << endl;
//                        return true;
//                    }
//                    if ((clock() - msg2_Send_Time) > TIMEOUT)
//                    {
//                        int re = Send(con_msg[1]);
//                        msg2_Send_Time = clock();
//                        if (re > 0)
//                        {
//                            HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
//                            cout << "Time Out! -- Send Message to Router! -- Second-Way Handshake" << endl;
//                            con_msg[1].Print_Packet();
//                            SetConsoleTextAttribute(hConsole, 7);
//                        }
//                    }
//                }
//            }
//        }
//    }
//    return false;
//}
//void receive()
//{
//    char file_name[MSS] = {};
//    Packet rec_msg;
//    int file_length = rec_msg.Length;
//    while (true)
//    {
//        //int file_length = rec_msg.Length;
//        if (recvfrom(serversocket, (char*)&rec_msg, sizeof(rec_msg), 0, (SOCKADDR*)&clientaddr, &clientaddrlen) > 0)
//        {
//            // cout <<"[Server] "<< "Receive Message from Router!" << endl;
//            rec_msg.Print_Packet();
//            //int file_length = rec_msg.Length;
//            if (rec_msg.Is_CFH() && rec_msg.CheckValid() && rec_msg.Seq == Seq + 1)
//            {
//                Seq = rec_msg.Seq;
//                //int file_length = rec_msg.Length;
//                for (int i = 0; rec_msg.Data[i]; i++)
//                    file_name[i] = rec_msg.Data[i];
//                cout << "Receive File Name: " << file_name << " File Size: " << file_length << endl;
//                Packet reply_msg;
//                reply_msg.Ack = rec_msg.Seq;
//                reply_msg.Seq = ++Seq;
//                reply_msg.Set_ACK();
//                if (Send(reply_msg) > 0)
//                {
//                    // cout<<"[Server] "<< "Receive Seq = "<<rec_msg.Seq<<" Reply Ack = "<<reply_msg.Ack<<endl;
//                    break;
//                }
//            }
//            else if (rec_msg.CheckValid() && rec_msg.Seq != Seq + 1)
//            {
//                Packet reply_msg;
//                reply_msg.Ack = rec_msg.Seq;
//                // reply_msg.Seq = ++Seq;
//                reply_msg.Set_ACK();
//                if (Send(reply_msg) > 0)
//                {
//                    // cout<<"[Server] [!Repeatedly!]"<<" Reply Ack = "<<reply_msg.Ack<<endl;
//                }
//            }
//            else
//            {
//                cout << "Error Message!" << endl;
//                exit(EXIT_FAILURE);
//            }
//        }
//    }
//    ofstream Recv_File(file_name, ios::binary);
//    // Recv_File = fopen(file_name, "wb");
//    int complete_num = file_length / MSS;
//    int last_length = file_length % MSS;
//
//    // char *file_buffer = new char[MSS];
//    cout << "[Server] "
//        << "Start Receiving File!" << endl;
//    for (int i = 0; i <= complete_num; i++)
//    {
//        while (true)
//        {
//            Packet data_msg;
//            if (recvfrom(serversocket, (char*)&data_msg, sizeof(rec_msg), 0, (SOCKADDR*)&clientaddr, &clientaddrlen) > 0)
//            {
//                // cout <<"[Server] "<< "Receive Message from Router!" << endl;
//                data_msg.Print_Packet();
//                if (data_msg.Seq < Seq + 1)
//                {
//                    continue;
//                }
//                if (data_msg.CheckValid() && data_msg.Seq == Seq + 1)
//                {
//                    Seq = data_msg.Seq;
//                    Packet reply_msg;
//                    reply_msg.Ack = data_msg.Seq;
//                    reply_msg.Seq = ++Seq;
//                    reply_msg.Set_ACK();
//                    if (Send(reply_msg) > 0)
//                    {
//                        // cout<<"[Server] "<< "Receive Seq = "<<data_msg.Seq<<" Reply Ack = "<<reply_msg.Ack<<endl;
//                        if (i != complete_num)
//                        {
//                            Recv_File.write(data_msg.Data, MSS);
//                        }
//                        else
//                        {
//                            Recv_File.write(data_msg.Data, last_length);
//                        }
//                        break;
//                    }
//                }
//                else if (data_msg.CheckValid() && data_msg.Seq != Seq + 1)
//                {
//                    Packet reply_msg;
//                    reply_msg.Ack = data_msg.Seq;
//                    // reply_msg.Seq = ++Seq;
//                    reply_msg.Set_ACK();
//                    if (Send(reply_msg) > 0)
//                    {
//                        // cout<<"[Server] [!Repeatedly!]"<< " Reply Ack = "<<reply_msg.Ack<<endl;
//                    }
//                }
//                else
//                {
//                    cout << "Error Message!" << endl;
//                    exit(EXIT_FAILURE);
//                }
//            }
//        }
//    }
//    cout << "Finish Receiving!" << endl;
//    // cout<<"[Server] "<< "Start Writing File!"<<endl;
//}
//void Disconnect() // * Router�������Ͽ�����
//{
//    Packet discon_msg[4];
//    while (true)
//    {
//        // * First-Way Wavehand
//        if (recvfrom(serversocket, (char*)&discon_msg[0], sizeof(discon_msg[0]), 0, (SOCKADDR*)&clientaddr, &clientaddrlen) > 0)
//        {
//            // cout <<"[Server] "<< "Receive Message from Router! -- First-Way Wavehand" << endl;
//            if (discon_msg[0].Seq < Seq + 1)
//            {
//                continue;
//            }
//            if (!(discon_msg[0].Is_FIN() && discon_msg[0].CheckValid() && discon_msg[0].Seq == Seq + 1))
//            {
//                cout << "[Server] "
//                    << "Error Message!" << endl;
//                exit(EXIT_FAILURE);
//            }
//            Seq = discon_msg[0].Seq;
//        }
//        // * Second-Way Wavehand
//        discon_msg[1].Ack = discon_msg[0].Seq;
//        discon_msg[1].Seq = ++Seq;
//        discon_msg[1].Set_ACK();
//        int re = Send(discon_msg[1]);
//        // clock dismsg2_Send_Time = clock();
//        if (re > 0)
//        {
//            // cout <<"[Server] "<< "Send Message to Router! -- Second-Way Wavehand" << endl;
//            discon_msg[1].Print_Packet();
//        }
//        break;
//    }
//    // * Third-Way Wavehand
//    discon_msg[2].Ack = discon_msg[1].Seq;
//    discon_msg[2].Seq = ++Seq;
//    discon_msg[2].Set_ACK();
//    discon_msg[2].Set_FIN();
//    int re = Send(discon_msg[2]);
//    float dismsg3_Send_Time = clock();
//    if (re > 0)
//    {
//        // cout <<"[Server] "<< "Send Message to Router! -- Third-Way Wavehand" << endl;
//        discon_msg[2].Print_Packet();
//    }
//    // * Fourth-Way Wavehand
//    while (true)
//    {
//        if (recvfrom(serversocket, (char*)&discon_msg[3], sizeof(discon_msg[3]), 0, (SOCKADDR*)&clientaddr, &clientaddrlen) > 0)
//        {
//            // cout <<"[Server] "<< "Receive Message from Router! -- Fourth-Way Wavehand" << endl;
//            discon_msg[3].Print_Packet();
//            if (discon_msg[3].Seq < Seq + 1)
//            {
//                continue;
//            }
//            else if (!(discon_msg[3].Is_ACK() && discon_msg[3].CheckValid() && discon_msg[3].Seq == Seq + 1 && discon_msg[3].Ack == discon_msg[2].Seq))
//            {
//                cout << "[Server] "
//                    << "Error Message!" << endl;
//                exit(EXIT_FAILURE);
//            }
//            Seq = discon_msg[3].Seq;
//            cout << "[Server] "
//                << "Fourth-Way Wavehand is successful!" << endl;
//            break;
//        }
//        if ((clock() - dismsg3_Send_Time) > TIMEOUT)
//        {
//            int re = Send(discon_msg[2]);
//            dismsg3_Send_Time = clock();
//            if (re > 0)
//            {
//                HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
//                cout
//                    << "Time Out! -- Send Message to Router! -- Third-Way Wavehand" << endl;
//                discon_msg[2].Print_Packet();
//                SetConsoleTextAttribute(hConsole, 7);
//            }
//        }
//    }
//    //Exit();
//    closesocket(serversocket);
//    WSACleanup();
//    cout << "Server is closed!" << endl;
//    system("pause");
//    return;
//}
////void Exit()
////{
////    closesocket(serversocket);
////    WSACleanup();
////    cout << "[Server] "
////        << "Server is closed!" << endl;
////    system("pause");
////}
//int main() {
//    WSADATA wsaData;
//    WSAStartup(MAKEWORD(2, 2), &wsaData);
//
//    serversocket = socket(AF_INET, SOCK_DGRAM, 0);
//    if (serversocket == INVALID_SOCKET) {
//        cerr << "Socket creation failed." << endl;
//        return -1;
//    }
//    cout << "Socket creation succeeded!" << endl;
//
//    /*sockaddr_in serveraddr, clientAddr;
//    serveraddr.sin_family = AF_INET;
//    serveraddr.sin_port = htons(8080);
//    serveraddr.sin_addr.s_addr = INADDR_ANY;*/
//    struct in_addr addr;
//    if (inet_pton(AF_INET, serverip.c_str(), &addr) <= 0) {
//        std::cerr << "Invalid IP address format" << std::endl;
//        return 1;
//    }
//    serveraddr.sin_family = AF_INET;
//    serveraddr.sin_port = htons(serverport);
//    serveraddr.sin_addr.S_un.S_addr = addr.s_addr;
//    //serveraddr.sin_addr.S_un.S_addr = inet_addr(serverip.c_str());
//
//    if (bind(serversocket, (SOCKADDR*)&serveraddr, sizeof(SOCKADDR)) == SOCKET_ERROR)
//    {
//        cout << "Error in Binding Socket!\n";
//        exit(EXIT_FAILURE);
//        return false;
//    }
//    cout << "Binding Socket to port " << serverport << " is successful!" << endl<< endl;
//
//    if (!connect())
//    {
//        cout << "Error in Connecting!" << endl;
//        exit(EXIT_FAILURE);
//    }
//    receive();
//    Disconnect();
//    //receiveFile(sock, clientAddr);
//
//    /*closesocket(sock);
//    WSACleanup();*/
//    return 0;
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////#include <iostream>
////#include <fstream>
////#include <winsock2.h>
////#include <chrono>
////#include <iomanip>
////#include <sstream>
////
////using namespace std;
////
////#pragma comment(lib, "ws2_32.lib")
////
////const int BUFFER_SIZE = 1024;
////
////enum PacketType { SYN, SYN_ACK, ACK, FIN, FIN_ACK, DATA };
////
////struct Packet {
////    PacketType type;
////    int seq;
////    int checksum;
////    char data[BUFFER_SIZE];
////};
////
////int calculateChecksum(Packet& packet) {
////    int sum = packet.type + packet.seq;
////    for (int i = 0; i < BUFFER_SIZE; i++) {
////        sum += static_cast<unsigned char>(packet.data[i]);
////    }
////    return sum;
////}
////
////void logEvent(const string& event, const Packet& packet) {
////    cout << "[" << chrono::system_clock::to_time_t(chrono::system_clock::now())
////        << "] " << event << " | Type: " << packet.type << ", Seq: " << packet.seq
////        << ", Checksum: " << packet.checksum << endl;
////}
////
////bool establishConnection(SOCKET& sock, sockaddr_in& clientAddr) {
////    Packet packet;
////    int clientLen = sizeof(clientAddr);
////
////    // Wait for SYN
////    recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////    if (packet.type == SYN) {
////        logEvent("Received SYN", packet);
////
////        // Send SYN-ACK
////        packet.type = SYN_ACK;
////        packet.checksum = calculateChecksum(packet);
////        sendto(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, clientLen);
////        logEvent("Sent SYN-ACK", packet);
////
////        // Wait for ACK
////        recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////        if (packet.type == ACK) {
////            logEvent("Received ACK", packet);
////            return true;
////        }
////    }
////    cerr << "Connection establishment failed." << endl;
////    return false;
////}
////
////void terminateConnection(SOCKET& sock, sockaddr_in& clientAddr) {
////    Packet packet;
////    int clientLen = sizeof(clientAddr);
////
////    // Wait for FIN
////    recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////    if (packet.type == FIN) {
////        logEvent("Received FIN", packet);
////
////        // Send FIN-ACK
////        packet.type = FIN_ACK;
////        packet.checksum = calculateChecksum(packet);
////        sendto(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, clientLen);
////        logEvent("Sent FIN-ACK", packet);
////
////        // Wait for final ACK
////        recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////        if (packet.type == ACK) {
////            logEvent("Received final ACK", packet);
////        }
////    }
////    cout << "Connection terminated." << endl;
////}
////
////void receiveFile(SOCKET& sock, sockaddr_in& clientAddr) {
////    if (!establishConnection(sock, clientAddr)) {
////        return;
////    }
////
////    ofstream file("received_file", ios::binary);
////    if (!file.is_open()) {
////        cerr << "Failed to open output file." << endl;
////        return;
////    }
////
////    Packet packet;
////    int clientLen = sizeof(clientAddr);
////    int expectedSeq = 0;
////
////    cout << "Waiting for file data..." << endl;
////    while (true) {
////        recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////        logEvent("Packet received", packet);
////
////        if (packet.type == DATA) {
////            if (calculateChecksum(packet) == packet.checksum && packet.seq == expectedSeq) {
////                file.write(packet.data, BUFFER_SIZE);
////                logEvent("Data written to file", packet);
////
////                // Send ACK
////                Packet ackPacket = { ACK, expectedSeq, 0, {0} };
////                ackPacket.checksum = calculateChecksum(ackPacket);
////                sendto(sock, (char*)&ackPacket, sizeof(ackPacket), 0, (sockaddr*)&clientAddr, clientLen);
////                logEvent("Sent ACK", ackPacket);
////
////                expectedSeq = (expectedSeq + 1) % 2;
////            }
////            else {
////                logEvent("Checksum or sequence mismatch, ignoring packet", packet);
////            }
////        }
////        else if (packet.type == FIN) {
////            logEvent("Received FIN, ending transmission", packet);
////            break;
////        }
////    }
////
////    file.close();
////    terminateConnection(sock, clientAddr);
////    cout << "File received successfully." << endl;
////}
////
////int main() {
////    WSADATA wsaData;
////    WSAStartup(MAKEWORD(2, 2), &wsaData);
////
////    SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
////    if (sock == INVALID_SOCKET) {
////        cerr << "Socket creation failed." << endl;
////        return -1;
////    }
////
////    sockaddr_in serveraddr, clientAddr;
////    serveraddr.sin_family = AF_INET;
////    serveraddr.sin_port = htons(8080);
////    serveraddr.sin_addr.s_addr = INADDR_ANY;
////
////    if (bind(sock, (sockaddr*)&serveraddr, sizeof(serveraddr)) == SOCKET_ERROR) {
////        cerr << "Bind failed." << endl;
////        return -1;
////    }
////
////    cout << "Server is ready to receive files..." << endl;
////    receiveFile(sock, clientAddr);
////
////    closesocket(sock);
////    WSACleanup();
////    return 0;
////}
//
//
//
//
//
//
//
//
//
//
//
//
//
////#include <iostream>
////#include <fstream>
////#include <winsock2.h>
////#include <chrono>
////#include <iomanip>
////
////using namespace std;
////using namespace chrono;
////
////#pragma comment(lib, "ws2_32.lib")
////
////const int BUFFER_SIZE = 1024;
////
////enum PacketType { SYN, SYN_ACK, ACK, FIN, FIN_ACK, DATA };
////
////struct Packet {
////    PacketType type;
////    int seq;
////    int checksum;
////    char data[BUFFER_SIZE];
////};
////
////int calculateChecksum(Packet& packet) {
////    int sum = packet.type + packet.seq;
////    for (int i = 0; i < BUFFER_SIZE; i++) {
////        sum += static_cast<unsigned char>(packet.data[i]);
////    }
////    return sum;
////}
////
////void logEvent(const string& event, const Packet& packet, const steady_clock::time_point& startTime, const steady_clock::time_point& endTime) {
////    auto duration = duration_cast<milliseconds>(endTime - startTime).count();
////
////    // ��ȡ��ǰʱ�䲢ת��Ϊ tm �ṹ��
////    time_t now = system_clock::to_time_t(system_clock::now());
////    struct tm buf;
////    localtime_s(&buf, &now);
////
////    // ��ʽ��ʱ��Ϊ yyyy-mm-dd hh:mm:ss
////    char timeStr[20];
////    strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %H:%M:%S", &buf);
////
////    cout << "[" << timeStr << "] "
////        << event << " | Type: " << packet.type << ", Seq: " << packet.seq
////        << ", Checksum: " << packet.checksum
////        << ", Time: " << duration << " ms" << endl;
////}
////
////bool establishConnection(SOCKET& sock, sockaddr_in& clientAddr) {
////    Packet packet;
////    int clientLen = sizeof(clientAddr);
////
////    // Wait for SYN
////    recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////    if (packet.type == SYN) {
////        logEvent("Received SYN", packet, steady_clock::now(), steady_clock::now());
////
////        // Send SYN-ACK
////        packet.type = SYN_ACK;
////        packet.checksum = calculateChecksum(packet);
////        sendto(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, clientLen);
////        logEvent("Sent SYN-ACK", packet, steady_clock::now(), steady_clock::now());
////
////        // Wait for ACK
////        recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////        if (packet.type == ACK) {
////            logEvent("Received ACK", packet, steady_clock::now(), steady_clock::now());
////            return true;
////        }
////    }
////    cerr << "Connection establishment failed." << endl;
////    return false;
////}
////
////void terminateConnection(SOCKET& sock, sockaddr_in& clientAddr) {
////    Packet packet;
////    int clientLen = sizeof(clientAddr);
////
////    // Wait for FIN
////    recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////    if (packet.type == FIN) {
////        logEvent("Received FIN", packet, steady_clock::now(), steady_clock::now());
////
////        // Send FIN-ACK
////        packet.type = FIN_ACK;
////        packet.checksum = calculateChecksum(packet);
////        sendto(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, clientLen);
////        logEvent("Sent FIN-ACK", packet, steady_clock::now(), steady_clock::now());
////
////        // Wait for final ACK
////        recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////        if (packet.type == ACK) {
////            logEvent("Received final ACK", packet, steady_clock::now(), steady_clock::now());
////        }
////    }
////    cout << "Connection terminated." << endl;
////}
////
////void receiveFile(SOCKET& sock, sockaddr_in& clientAddr) {
////    if (!establishConnection(sock, clientAddr)) {
////        return;
////    }
////
////    ofstream file("received_file", ios::binary);
////    if (!file.is_open()) {
////        cerr << "Failed to open output file." << endl;
////        return;
////    }
////
////    Packet packet;
////    int clientLen = sizeof(clientAddr);
////    int expectedSeq = 0;
////
////    cout << "Waiting for file data..." << endl;
////
////    steady_clock::time_point startTime = steady_clock::now();
////    size_t totalBytesReceived = 0;
////
////    while (true) {
////        steady_clock::time_point packetStart = steady_clock::now();
////        recvfrom(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&clientAddr, &clientLen);
////        steady_clock::time_point packetEnd = steady_clock::now();
////
////        logEvent("Packet received", packet, packetStart, packetEnd);
////
////        if (packet.type == DATA) {
////            if (calculateChecksum(packet) == packet.checksum && packet.seq == expectedSeq) {
////                file.write(packet.data, BUFFER_SIZE);
////                totalBytesReceived += BUFFER_SIZE;
////                logEvent("Data written to file", packet, packetStart, packetEnd);
////
////                // Send ACK
////                Packet ackPacket = { ACK, expectedSeq, 0, {0} };
////                ackPacket.checksum = calculateChecksum(ackPacket);
////                sendto(sock, (char*)&ackPacket, sizeof(ackPacket), 0, (sockaddr*)&clientAddr, clientLen);
////                logEvent("Sent ACK", ackPacket, steady_clock::now(), steady_clock::now());
////
////                expectedSeq = (expectedSeq + 1) % 2;
////            }
////            else {
////                logEvent("Checksum or sequence mismatch, ignoring packet", packet, steady_clock::now(), steady_clock::now());
////            }
////        }
////        else if (packet.type == FIN) {
////            logEvent("Received FIN, ending transmission", packet, steady_clock::now(), steady_clock::now());
////            break;
////        }
////    }
////
////    steady_clock::time_point endTime = steady_clock::now();
////    file.close();
////
////    double duration = duration_cast<seconds>(endTime - startTime).count();
////    double throughput = totalBytesReceived / duration / 1024; // in KBps
////
////    cout << "File received successfully." << endl;
////    cout << "Total time: " << duration << " s, Throughput: " << throughput << " KBps" << endl;
////
////    terminateConnection(sock, clientAddr);
////}
////
////int main() {
////    WSADATA wsaData;
////    WSAStartup(MAKEWORD(2, 2), &wsaData);
////
////    SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
////    if (sock == INVALID_SOCKET) {
////        cerr << "Socket creation failed." << endl;
////        return -1;
////    }
////
////    sockaddr_in serveraddr, clientAddr;
////    serveraddr.sin_family = AF_INET;
////    serveraddr.sin_port = htons(8080);
////    serveraddr.sin_addr.s_addr = INADDR_ANY;
////
////    if (bind(sock, (sockaddr*)&serveraddr, sizeof(serveraddr)) == SOCKET_ERROR) {
////        cerr << "Bind failed." << endl;
////        return -1;
////    }
////
////    cout << "Server is ready to receive files..." << endl;
////    receiveFile(sock, clientAddr);
////
////    closesocket(sock);
////    WSACleanup();
////    return 0;
////}



#include <iostream>
#include <WINSOCK2.h>
#include <time.h>
#include <fstream>
#include <string>
#include <ctime>
#include <chrono>    // chrono::system_clock
#include <sstream>   // stringstream
#include <iomanip>   // put_time

#pragma comment(lib, "ws2_32.lib")
#pragma warning(disable : 4996)
using namespace std;

const int MAXSIZE = 8192; // ���仺������󳤶�

//FIN ACK SYN
const unsigned char SYN = 0x1;
const unsigned char ACK = 0x2;
const unsigned char ACK_SYN = 0x3;
const unsigned char FIN = 0x4;
const unsigned char FIN_ACK = 0x5;
const unsigned char OVER = 0x7;


double MAX_TIME = 0.5 * CLOCKS_PER_SEC;

string getCurrentTime() {
    auto now = chrono::system_clock::now();
    time_t timeNow = chrono::system_clock::to_time_t(now);
    tm localTime;
    localtime_s(&localTime, &timeNow);
    stringstream ss;
    ss << put_time(&localTime, "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

u_short checkSum(u_short* mes, int size)//�� 16 λ��u_short ���ͣ�Ϊ��λ������ͺͷ���
{
    int count = (size + 1) / 2;//size�����ֽ�Ϊ��λ�ģ�count������Ҫ������16λ��Ԫ����
    u_short* buf = (u_short*)malloc(size + 1);//���飬����Ϊ16λ��Ԫ��
    memset(buf, 0, size + 1);
    memcpy(buf, mes, size); // ��message����buf
    u_long sum = 0;//�ۼӣ�ʹ��32λ
    while (count--)
    {
        sum += *buf++;
        // ����н�λ�򽫽�λ�ӵ����λ
        if (sum & 0xffff0000)
        {
            sum &= 0xffff;//��16λ����
            sum++;
        }
    }
    // ȡ��
    return ~(sum & 0xffff);
}

struct Packet
{
    u_short sum = 0;          // У��� 16λ
    u_short datasize = 0;     // ���������ݳ��� 16λ
    unsigned char flag = 0;   // ��λ��ʹ�ú���λ��������FIN ACK SYN
    unsigned char SEQ = 0;    // ��λ����������кţ�0~255��������mod
    Packet()
    {
        sum = 0;      // У���    16λ
        datasize = 0; // ���������ݳ���     16λ
        flag = 0;     // 8λ��ʹ�ú���λ��������FIN ACK SYN
        SEQ = 0;      // 8λ
    }
};

int Connect(SOCKET& sockServ, SOCKADDR_IN& ClientAddr, int& ClientAddrLen)
{
    Packet packet;
    char* Buffer = new char[sizeof(packet)];

    // ���յ�һ��������Ϣ
    while (1)
    {
        // ͨ���󶨵�socket���ݡ���������
        if (recvfrom(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, &ClientAddrLen) == -1)
        {
            return -1;
        }
        memcpy(&packet, Buffer, sizeof(packet));
        if (packet.flag == SYN && checkSum((u_short*)&packet, sizeof(packet)) == 0)
        {
            cout << "[" << getCurrentTime() << "] " << "[Receive] Recieved the first handshake! " << endl;
            break;
        }
    }
    // ���͵ڶ���������Ϣ
    packet.flag = ACK;
    packet.sum = 0;
    packet.sum = checkSum((u_short*)&packet, sizeof(packet));
    memcpy(Buffer, &packet, sizeof(packet));

    if (sendto(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, ClientAddrLen) == -1)
    {
        return -1;
    }
    else
    {
        
        cout << "[" << getCurrentTime() << "] " << "[Send] Send the second handshake! " << endl;
    }
    clock_t start = clock(); // ��¼�ڶ������ַ���ʱ��

    // ���յ���������
    while (recvfrom(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, &ClientAddrLen) <= 0)
    {
        // ��ʱ�ش�
        if (clock() - start > MAX_TIME)
        {
            
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mWARNING\033[0m] The second handshake is TIMEOUT " << endl;
            packet.flag = ACK;
            packet.sum = 0;
            packet.flag = checkSum((u_short*)&packet, sizeof(packet));
            memcpy(Buffer, &packet, sizeof(packet));
            if (sendto(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, ClientAddrLen) == -1)
            {
                return -1;
            }
            
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mNote\033[0m] Already transmit repeatedly " << endl;
        }
    }

  
  
    memcpy(&packet, Buffer, sizeof(packet));

    if (packet.flag == ACK_SYN && checkSum((u_short*)&packet, sizeof(packet)) == 0)
    {
        
        cout << "[" << getCurrentTime() << "] " << "[Receive] Recieved the third handshake!" << endl;
        
        cout << "[" << getCurrentTime() << "] " << "[Note] Connected successfully!" << endl;
    }
    else
    {
        
        cout << "[" << getCurrentTime() << "] " << "[Note] Error,please try again!" << endl;
    }
    return 1;
}

int RecvMessage(SOCKET& sockServ, SOCKADDR_IN& ClientAddr, int& ClientAddrLen, char* message)
{
    long int fileLength = 0; // �ѽ����ļ�����
    Packet packet;
    char* Buffer = new char[MAXSIZE + sizeof(packet)];//�������ݵĻ�����
    int seq = 0;//���������к�
    int index = 0;

    while (1)
    {
        int length = recvfrom(sockServ, Buffer, sizeof(packet) + MAXSIZE, 0, (sockaddr*)&ClientAddr, &ClientAddrLen); // ���ձ��ĳ���
        memcpy(&packet, Buffer, sizeof(packet));//���շ�Ƭ���ݰ����洢��Buffer��
        // �жϽ���
        if (packet.flag == OVER && checkSum((u_short*)&packet, sizeof(packet)) == 0)
        {
           
            cout << "[" << getCurrentTime() << "] " << "[Note] Transmit is over!" << endl;
            break;
        }

        //��ÿ�����յ������ݰ�����У�����֤
        if (packet.flag == static_cast<unsigned char>(0) && checkSum((u_short*)Buffer, length - sizeof(packet)))
        {
            // ����յ������кų����������·���ACK����ʱseqû�б仯
            if (checkSum((u_short*)Buffer, length - sizeof(packet)) == 0 && seq != int(packet.SEQ))
            {
                // ˵���������⣬����ACK
                packet.flag = ACK;
                packet.datasize = 0;
                packet.SEQ = (unsigned char)seq;
                packet.sum = checkSum((u_short*)&packet, sizeof(packet));
                memcpy(Buffer, &packet, sizeof(packet));
                // �ط��ð���ACK
                sendto(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, ClientAddrLen);
                
                cout << "[" << getCurrentTime() << "] " << "[Note] Resend the previous confirmation Packet - ACK:" << (int)packet.SEQ << " SEQ:" << (int)packet.SEQ << endl;
                continue; // ���������ݰ�
            }
            seq = int(packet.SEQ);
            if (seq > 255)
            {
                seq = seq - 256;
            }
            
            cout << "[" << getCurrentTime() << "] " << "[Receive] Recived! " << length - sizeof(packet) << " Bytes - Flag:" << int(packet.flag) << " ACK:" << int(packet.SEQ) << " Checksum:" << int(packet.sum) << endl;


            //����
            char* temp = new char[length - sizeof(packet)];
            memcpy(temp, Buffer + sizeof(packet), length - sizeof(packet));// ��ȡ����
            memcpy(message + fileLength, temp, length - sizeof(packet));//���뻺����
            fileLength = fileLength + int(packet.datasize);

            // ����ACK
            packet.flag = ACK;
            packet.datasize = 0;
            packet.SEQ = (unsigned char)seq;
            packet.sum = 0;
            packet.sum = checkSum((u_short*)&packet, sizeof(packet));
            memcpy(Buffer, &packet, sizeof(packet));
            sendto(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, ClientAddrLen);
            //cout << "[\033[1;31mSend\033[0m] �ظ��ͻ��� - flag:" << (int)packet.flag << " SEQ:" << (int)packet.SEQ << " Checksum:" << int(packet.sum) << endl;
            cout << "[" << getCurrentTime() << "] " << "[Send] Reply to the Client - flag:" << (int)packet.flag << " SEQ:" << (int)packet.SEQ << " Checksum:" << int(packet.sum) << endl;
            seq++;
            if (seq > 255)
            {
                seq = seq - 256;
            }
        }
    }
    // ����OVER��Ϣ
    packet.flag = OVER;
    packet.sum = 0;
    packet.sum = checkSum((u_short*)&packet, sizeof(packet));
    memcpy(Buffer, &packet, sizeof(packet));
    if (sendto(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, ClientAddrLen) == -1)
    {
        return -1;
    }
    return fileLength;
}

int disConnect(SOCKET& sockServ, SOCKADDR_IN& ClientAddr, int& ClientAddrLen)
{
    Packet packet;
    char* Buffer = new char[sizeof(packet)];
    while (1)
    {
        int length = recvfrom(sockServ, Buffer, sizeof(packet) + MAXSIZE, 0, (sockaddr*)&ClientAddr, &ClientAddrLen); // ���ձ��ĳ���
        memcpy(&packet, Buffer, sizeof(packet));
        if (packet.flag == FIN && checkSum((u_short*)&packet, sizeof(packet)) == 0)
        {
            //cout << "[\033[1;32mReceive\033[0m] ���յ���һ�λ������� " << endl;
            cout << "[" << getCurrentTime() << "] " << "[Receive] Recieved the first wave! " << endl;
            break;
        }
        else
        {
            return -1;
        }
    }
    // ���͵ڶ��λ�����Ϣ
    packet.flag = ACK;
    packet.sum = 0;
    packet.sum = checkSum((u_short*)&packet, sizeof(packet));
    memcpy(Buffer, &packet, sizeof(packet));
    if (sendto(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, ClientAddrLen) == -1)
    {
        
        cout << "[" << getCurrentTime() << "] " << "[Note] Error to send the second wave!" << endl;
        return -1;
    }
    else
    {
       
        cout << "[" << getCurrentTime() << "] " << "[Send] Send the second wave!" << endl;
    }
    clock_t start = clock(); // ��¼�ڶ��λ��ַ���ʱ��

    // ���յ����λ���
    while (recvfrom(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, &ClientAddrLen) <= 0)
    {
        // ��ʱ�ش��ڶ��λ���
        if (clock() - start > MAX_TIME)
        {
            
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mWARNING\033[0m] The second wave is TIMEOUT " << endl;
            packet.flag = ACK;
            packet.sum = 0;
            packet.sum = checkSum((u_short*)&packet, sizeof(packet));
            memcpy(Buffer, &packet, sizeof(packet));
            if (sendto(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, ClientAddrLen) == -1)
            {
                return -1;
            }
           
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mNote\033[0m] Already transmit repeatedly " << endl;
        }
    }
    // �����յ��ĵ����λ���
    Packet temp1;
    memcpy(&temp1, Buffer, sizeof(packet));
    if (temp1.flag == FIN_ACK && checkSum((u_short*)&temp1, sizeof(temp1) == 0))
    {
        
        cout << "[" << getCurrentTime() << "] " << "[Receive] Recieved the third wave! " << endl;
    }
    else
    {
        
        cout << "[" << getCurrentTime() << "] " << "[Note] Error,please try again!" << endl;
        return -1;
    }

    // ���͵��Ĵλ�����Ϣ
    packet.flag = FIN_ACK;
    packet.sum = 0;
    packet.sum = checkSum((u_short*)&packet, sizeof(packet));
    memcpy(Buffer, &packet, sizeof(packet));
    if (sendto(sockServ, Buffer, sizeof(packet), 0, (sockaddr*)&ClientAddr, ClientAddrLen) == -1)
    {
        
        cout << "[" << getCurrentTime() << "] " << "[Note] Error to send the fourth wave! " << endl;
        return -1;
    }
    else
    {
       
        cout << "[" << getCurrentTime() << "] " << "[Send] Send the fourth wave! " << endl;
    }
    
    cout << "[" << getCurrentTime() << "] " << "[Note] Disconnect! " << endl;
    return 1;
}

int main()
{
    WSADATA wsadata;
    WSAStartup(MAKEWORD(2, 2), &wsadata);

    SOCKADDR_IN serverAddr;
    SOCKET server;

    serverAddr.sin_family = AF_INET;   // ʹ��IPV4
    serverAddr.sin_port = htons(8889); // ����Ϊrouter�Ķ˿�
    serverAddr.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
    server = socket(AF_INET, SOCK_DGRAM, 0);
    //cout << "[\033[1;33mNote\033[0m] �ɹ�����socket " << endl;
    cout <<"[" << getCurrentTime() <<"] " << " Successfully created socket!" << endl;
    bind(server, (SOCKADDR*)&serverAddr, sizeof(serverAddr)); // ���׽��֣��������״̬
    //cout << "[\033[1;33mNote\033[0m] �������״̬���ȴ��ͻ������� " << endl;
    cout << "[" << getCurrentTime() << "] "<< " Enter monitoring mode ! " << endl;

    int len = sizeof(serverAddr);
    // ��������
    Connect(server, serverAddr, len);
    //cout << "[\033[1;33mNote\033[0m] �ɹ��������ӣ����ڵȴ������ļ� " << endl;
    //cout << "[" << getCurrentTime() << "] " << "[Note] Successfully connected! " << endl;

    while (true)
    {
        char* name = new char[20];
        char* data = new char[100000000];
        int namelen = RecvMessage(server, serverAddr, len, name);
        int datalen = RecvMessage(server, serverAddr, len, data);
        string a;
        for (int i = 0; i < namelen; i++)
        {
            a = a + name[i];
        }

        /*cout << endl
            << "[\033[1;36mOut\033[0m] ���յ��ļ���:" << a << endl;*/
        cout << endl << "[" << getCurrentTime() << "] "
            << "[Note] The File:" << a << endl;
        ofstream fout(a.c_str(), ofstream::binary);
        //cout << "[\033[1;36mOut\033[0m] ���յ��ļ�����:" << datalen << endl;
        cout << "[" << getCurrentTime() << "] " << "[Note] The Length of File:" << datalen << endl;
        for (int i = 0; i < datalen; i++)
        {
            fout << data[i];
        }
        fout.close();
        /*cout << "[\033[1;36mOut\033[0m] �ļ��ѳɹ����ص����� " << endl
            << endl;*/
        cout << "[" << getCurrentTime() << "] " << "[Note] Successfully Download! " << endl
            << endl;

        if (disConnect(server, serverAddr, len) == 1)
        {
            break;
        }
    }

    system("pause");
    return 0;
}