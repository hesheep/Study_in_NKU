﻿////lxm
//#include <iostream>
//#include <fstream>
//#include <string>
//#include <winsock2.h>
//#include <ws2tcpip.h>
//#include <ctime>
//#include <chrono>
//#include <iomanip>
//#include <sstream>  // std::stringstream
//#include <cstdint>
//#include <cstring>
////#include <sys/time.h>
//
//
//using namespace std;
//#define _WINSOCK_DEPRECATED_NO_WARNINGS
//
//#define serverport 55555 // 动态端口范围，适合作为自定义服务端口
//#define clientport 55556 // 与服务端不同但也在动态范围内
//const int TIMEOUT = 1000;
////const int MAX_SEQ = 1;
//
//SOCKET clientsocket;
//SOCKADDR_IN clientaddr;
//string clientip = "127.0.0.1";
//int clientaddrlen = sizeof(clientaddr);
//SOCKET serversocket;
//SOCKADDR_IN serveraddr;
//string serverip = "127.0.0.1";
//int serveraddrlen = sizeof(serveraddr);
//
//#pragma comment(lib, "ws2_32.lib")
//
////const int BUFFER_SIZE = 1024;
////struct Packet {
////    int seq;
////    int checksum;
////    char data[BUFFER_SIZE];
////};
//
//
//const int MSS = 1024; // Maximum Segment Size
//const uint16_t CFH = 0x1; // Example flag for Custom Flag Header
//const uint16_t ACK = 0x2; // ACK flag
//const uint16_t SYN = 0x4; // SYN flag
//const uint16_t FIN = 0x8; // FIN flag
//int Seq = 0;
//
//struct Packet {
//    uint32_t SrcPort; // Source port
//    uint32_t DstPort; // Destination port
//    uint32_t Seq;     // Sequence number
//    uint32_t Ack;     // Acknowledgment number
//    uint32_t Length;  // Data length
//    uint16_t Flag;    // Flags
//    uint16_t Check;   // Checksum
//    char Data[MSS];   // Payload
//
//    // Constructor to initialize fields
//    Packet()
//        : SrcPort(0), DstPort(0), Seq(0), Ack(0), Length(0), Flag(0), Check(0) {
//        memset(this->Data, 0, MSS);
//    }
//
//    // Flag manipulation methods
//    void Set_CFH() { this->Flag |= CFH; }
//    bool Is_CFH() const { return this->Flag & CFH; }
//
//    void Set_ACK() { this->Flag |= ACK; }
//    bool Is_ACK() const { return this->Flag & ACK; }
//
//    void Set_SYN() { this->Flag |= SYN; }
//    bool Is_SYN() const { return this->Flag & SYN; }
//
//    void Set_FIN() { this->Flag |= FIN; }
//    bool Is_FIN() const { return this->Flag & FIN; }
//
//    void Set_Data(char* data)
//    {
//        memset(this->Data, 0, MSS);
//        memcpy(this->Data, data, sizeof(data));
//    }
//
//    // Calculate and set checksum
//    void Set_Check() {
//        this->Check = 0; // Clear checksum before calculation
//        uint32_t sum = 0;
//        uint16_t* p = reinterpret_cast<uint16_t*>(this);
//        for (int i = 0; i < sizeof(*this) / 2; i++) {
//            sum += *p++;
//            while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
//        }
//        this->Check = ~(sum & 0xFFFF); // Complement the final sum
//    }
//
//    // Validate checksum
//    bool CheckValid() const {
//        uint32_t sum = 0;
//        const uint16_t* p = reinterpret_cast<const uint16_t*>(this);
//        for (int i = 0; i < sizeof(*this) / 2; i++) {
//            sum += *p++;
//            while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
//        }
//        return (sum & 0xFFFF) == 0xFFFF; // Valid if sum is all 1s
//    }
//
//    // Print packet details
//    void Print_Packet() const {
//        std::cout << "Packet Details:\n";
//        std::cout << "  SrcPort: " << SrcPort << "\n";
//        std::cout << "  DstPort: " << DstPort << "\n";
//        std::cout << "  Seq: " << Seq << "\n";
//        std::cout << "  Ack: " << Ack << "\n";
//        std::cout << "  Length: " << Length << "\n";
//        std::cout << "  Flag: 0x" << std::hex << Flag << std::dec << "\n";
//        std::cout << "  Checksum: 0x" << std::hex << Check << std::dec << "\n";
//        std::cout << "  Data: " << std::string(Data, Data + Length) << "\n";
//    }
//};
////int calculateChecksum(Packet& packet) {
////    int sum = packet.seq;
////    for (int i = 0; i < BUFFER_SIZE; i++) {
////        sum += static_cast<unsigned char>(packet.data[i]);
////    }
////    return sum;
////}
//
//string getCurrentTime() {
//    auto now = chrono::system_clock::now();
//    time_t timeNow = chrono::system_clock::to_time_t(now);
//    tm localTime;
//    localtime_s(&localTime, &timeNow);
//    stringstream ss;
//    ss << put_time(&localTime, "%Y-%m-%d %H:%M:%S");
//    return ss.str();
//}
//
//int send(Packet& msg)
//{
//    msg.SrcPort = clientport;
//    msg.DstPort = serverport;
//    msg.Set_Check();
//    return sendto(clientsocket, (char*)&msg, sizeof(msg), 0, (SOCKADDR*)&serveraddr, serveraddrlen);
//}
//
////void logEvent(const string& event, const Packet& packet, const string& extra = "") {
////    cout << "[" << getCurrentTime() << "] " << event
////        << " Seq: " << packet.seq
////        << ", Checksum: " << packet.checksum
////        << (extra.empty() ? "" : ", " + extra) << endl;
////}
//
//void Send_Message(string file_path) {
//    size_t found = file_path.find_last_of("/\\");
//    string file_name = file_path.substr(found + 1);
//
//    ifstream file(file_path, ios::binary);
//    if (!file.is_open()) {
//        cout << "Error in Opening File!" << endl;
//        exit(EXIT_FAILURE);
//    }
//    cout << "到这里了" << endl;
//    file.seekg(0, ios::end);
//    int file_length = static_cast<int>(file.tellg());
//    file.seekg(0, ios::beg);
//
//    Packet send_msg;
//    //strcpy(send_msg.Data, file_name.c_str());
//    //strcpy_s(send_msg.Data, sizeof(send_msg.Data), file_name.c_str());
//    strcpy_s(send_msg.Data, file_name.c_str());
//    //strncpy_s(send_msg.Data, sizeof(send_msg.Data), file_name.c_str(), sizeof(send_msg.Data) - 1);
//    send_msg.Data[strlen(send_msg.Data)] = '\0';
//
//    send_msg.Length = file_length;
//    send_msg.Seq = ++Seq;
//    cout << "Seq=" << Seq << endl;
//    send_msg.Set_CFH();
//
//    DWORD msg1_Send_Time = GetTickCount();
//    cout << "Time=" << msg1_Send_Time << endl;
//    int re = send(send_msg);
//    cout << "re=" << re << endl;
//    send_msg.Print_Packet();
//    if (re > 0) {
//        //send_msg.Print_Packet();
//        cout << "Send Message to Router! -- File Header" << endl;
//        send_msg.Print_Packet();
//    }
//
//    while (true) {
//        Packet tmp;
//        if (recvfrom(clientsocket, (char*)&tmp, sizeof(tmp), 0, (SOCKADDR*)&serveraddr, &serveraddrlen) > 0) {
//            cout << "Receive Message from Router! -- File Header" << endl;
//            tmp.Print_Packet();
//            if (tmp.Is_ACK() && tmp.CheckValid() && tmp.Seq == Seq + 1) {
//                Seq = tmp.Seq;
//                break;
//            }
//            else if (tmp.CheckValid() && tmp.Seq != Seq + 1)
//            {
//                Packet reply_msg;
//                reply_msg.Ack = tmp.Seq;
//                reply_msg.Set_ACK();
//                // reply_msg.Seq = ++Seq;
//                if (send(reply_msg) > 0)
//                {
//                    cout << "!Repeatedly!"<< "Receive Seq = " << tmp.Seq << " Reply Ack = " << reply_msg.Ack << endl;
//                }
//            }
//        }
//        else if (GetTickCount() - msg1_Send_Time > TIMEOUT) {
//            re = sendto(clientsocket, (char*)&send_msg, sizeof(send_msg), 0, (SOCKADDR*)&serveraddr, serveraddrlen);
//            msg1_Send_Time = GetTickCount();
//            if (re > 0) {
//                cout << "Time Out! -- Send Message to Router! -- File Header" << endl;
//                send_msg.Print_Packet();
//            }
//            else {
//                cout << "Error in Sending Message! -- File Header" << endl;
//                exit(EXIT_FAILURE);
//            }
//        }
//    }
//
//    DWORD complete_time_start = GetTickCount();
//    int complete_num = file_length / MSS;
//    int last_length = file_length % MSS;
//    cout << "Start to Send Message to Router! -- File" << endl;
//
//    for (int i = 0; i <= complete_num; i++) {
//        Packet data_msg;
//        if (i != complete_num) {
//            file.read(data_msg.Data, MSS);
//            data_msg.Length = MSS;
//            data_msg.Seq = ++Seq;
//
//            DWORD every_time_start = GetTickCount();
//            re = send(data_msg);
//            if (re > 0) {
//                data_msg.Print_Packet();
//                Packet tmp;
//                while (true) {
//                    if (recvfrom(clientsocket, (char*)&tmp, sizeof(tmp), 0, (SOCKADDR*)&serveraddr, &serveraddrlen) > 0) {
//                        tmp.Print_Packet();
//                        if (tmp.Is_ACK() && tmp.CheckValid() && tmp.Seq == Seq + 1) {
//                            Seq = tmp.Seq;
//                            DWORD every_time_end = GetTickCount();
//                            if (i % 10 == 0) {
//                                cout << "Time taken for part " << i << ": " << every_time_end - every_time_start << " ms" << endl;
//                            }
//                            break;
//                        }
//                        else if (tmp.CheckValid() && tmp.Seq != Seq + 1)
//                        {
//                            Packet reply_msg;
//                            reply_msg.Ack = tmp.Seq;
//                            reply_msg.Set_ACK();
//                            // reply_msg.Seq = ++Seq;
//                            if (send(reply_msg) > 0)
//                            {
//                                cout << "!Repeatedly!"
//                                    << "Receive Seq = " << tmp.Seq << " Reply Ack = " << reply_msg.Ack << endl;
//                            }
//                        }
//                    }
//                    else if (GetTickCount() - every_time_start > TIMEOUT) {
//                        re = sendto(clientsocket, (char*)&data_msg, sizeof(data_msg), 0, (SOCKADDR*)&serveraddr, serveraddrlen);
//                        if (re > 0) {
//                            cout << "Time Out! -- Resending part " << i << endl;
//                        }
//                        else
//                        {
//                            cout << "Error in Sending Message! Part " << i << " -- File" << endl;
//                            exit(EXIT_FAILURE);
//                        }
//                    }
//                }
//            }
//        }
//        else 
//        {
//            file.read(data_msg.Data, last_length);
//            data_msg.Length = last_length;
//            data_msg.Seq = ++Seq;
//
//            DWORD every_time_start = GetTickCount();
//            re = send(data_msg);
//            if (re > 0) {
//                data_msg.Print_Packet();
//                Packet tmp;
//                while (true) {
//                    if (recvfrom(clientsocket, (char*)&tmp, sizeof(tmp), 0, (SOCKADDR*)&serveraddr, &serveraddrlen) > 0) {
//                        tmp.Print_Packet();
//                        if (tmp.Is_ACK() && tmp.CheckValid() && tmp.Seq == Seq + 1) {
//                            Seq = tmp.Seq;
//                            break;
//                        }
//                        else if (tmp.CheckValid() && tmp.Seq != Seq + 1)
//                        {
//                            Packet reply_msg;
//                            reply_msg.Ack = tmp.Seq;
//                            reply_msg.Set_ACK();
//                            // reply_msg.Seq = ++Seq;
//                            if (send(reply_msg) > 0)
//                            {
//                                cout << "!Repeatedly!"
//                                    << "Receive Seq = " << tmp.Seq << " Reply Ack = " << reply_msg.Ack << endl;
//                            }
//                        }
//                    }
//                    else if (GetTickCount() - every_time_start > TIMEOUT) {
//                        re = sendto(clientsocket, (char*)&data_msg, sizeof(data_msg), 0, (SOCKADDR*)&serveraddr, serveraddrlen);
//                        if (re > 0) {
//                            cout << "Time Out! -- Resending last part" << endl;
//                        }
//                        else
//                        {
//                            cout << "Error in Sending Message! Part " << i << " -- File" << endl;
//                            exit(EXIT_FAILURE);
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//    DWORD send_time = GetTickCount() - complete_time_start;
//    file.close();
//    cout << "Finish Sending File!" << endl;
//    cout << "Send Time: " << send_time << " ms" << endl;
//    cout << "Send Speed: " << file_length / send_time << " Byte/ms" << endl << endl;
//}
//
//bool connect()
//{
//    Packet msg[3];
//    msg[0].Seq = Seq++;
//    msg[0].Set_SYN();
//    int l1 = send(msg[0]);
//    float t1 = clock();
//    if (l1 > 0)
//    {
//        msg[0].Print_Packet();
//
//        while (1)
//        {
//            if (recvfrom(clientsocket, (char*)&msg[1], sizeof(msg[1]), 0, (SOCKADDR*)&serveraddr, &serveraddrlen) > 0)
//            {
//                msg[1].Print_Packet();
//                if (!(msg[1].Is_ACK() && msg[1].Is_SYN() && msg[1].CheckValid() && msg[1].Ack == msg[0].Seq))
//                {
//                    cout << "[Client] "
//                        << "Error Message!" << endl;
//                    exit(EXIT_FAILURE);
//                }
//                Seq = msg[1].Seq;
//                break;
//            }
//            if ((clock() - t1) > TIMEOUT)
//            {
//                int l2 = send(msg[0]);
//                t1 = clock();
//                if (l2 > 0)
//                {
//                    //SetConsoleTextAttribute(hConsole, 12);
//                    cout << "[Client] "
//                        << "Time Out! -- Send Message to Router! -- First-Way Handshake" << endl;
//                    msg[0].Print_Packet();
//                    //SetConsoleTextAttribute(hConsole, 7);
//                }
//            }
//        }
//    }
//
//    msg[2].Ack = msg[1].Seq;
//    msg[2].Seq = ++Seq;
//    msg[2].Set_ACK();
//    int l3 = send(msg[2]);
//    if (l3 > 0)
//        msg[2].Print_Packet();
//    cout << "三次握手成功！" << endl;
//    return true;
//}
//
//void Disconnect() // * Client端主动断开连接
//{
//    Packet discon_msg[4];
//
//    // * First-Way Wavehand
//    discon_msg[0].Seq = ++Seq;
//    discon_msg[0].Set_FIN();
//    int re = send(discon_msg[0]);
//    float dismsg0_Send_Time = clock();
//    if (re > 0)
//    {
//        // cout <<"[Client] "<< "Send Message to Router! -- First-Way Wavehand" << endl;
//        discon_msg[0].Print_Packet();
//    }
//
//    // * Second-Way Wavehand
//    while (true)
//    {
//        if (recvfrom(clientsocket, (char*)&discon_msg[1], sizeof(discon_msg[1]), 0, (SOCKADDR*)&serveraddr, &serveraddrlen) > 0)
//        {
//            // cout <<"[Client] "<< "Receive Message from Router! -- Second-Way Wavehand" << endl;
//            discon_msg[1].Print_Packet();
//            if (!(discon_msg[1].Is_ACK() && discon_msg[1].CheckValid() && discon_msg[1].Seq == Seq + 1 && discon_msg[1].Ack == discon_msg[0].Seq))
//            {
//                cout << "Error Message!" << endl;
//                exit(EXIT_FAILURE);
//            }
//            Seq = discon_msg[1].Seq;
//            // cout <<"[Client] "<< "Second-Way Wavehand is successful!" << endl;
//            break;
//        }
//        if ((clock() - dismsg0_Send_Time) > TIMEOUT)
//        {
//            //SetConsoleTextAttribute(hConsole, 12);
//            cout << "Time Out! -- First-Way Wavehand" << endl;
//            int re = send(discon_msg[0]);
//            dismsg0_Send_Time = clock();
//            if (re > 0)
//            {
//                // cout <<"[Client] "<< "Send Message to Router! -- First-Way Wavehand" << endl;
//                discon_msg[0].Print_Packet();
//                //SetConsoleTextAttribute(hConsole, 7);
//            }
//        }
//    }
//    // * Third-Way Wavehand
//    while (true)
//    {
//        if (recvfrom(clientsocket, (char*)&discon_msg[2], sizeof(discon_msg[2]), 0, (SOCKADDR*)&serveraddr, &serveraddrlen) > 0)
//        {
//            // cout <<"[Client] "<< "Receive Message from Router! -- Third-Way Wavehand" << endl;
//            discon_msg[2].Print_Packet();
//            if (!(discon_msg[2].Is_ACK() && discon_msg[2].Is_FIN() && discon_msg[2].CheckValid() && discon_msg[2].Seq == Seq + 1 && discon_msg[2].Ack == discon_msg[1].Seq))
//            {
//                cout << "Error Message!" << endl;
//                exit(EXIT_FAILURE);
//            }
//            Seq = discon_msg[2].Seq;
//            // cout <<"[Client] "<< "Third-Way Wavehand is successful!" << endl;
//            break;
//        }
//    }
//    // * Fourth-Way Wavehand
//    discon_msg[3].Ack = discon_msg[2].Seq;
//    discon_msg[3].Set_ACK();
//    discon_msg[3].Seq = ++Seq;
//    re = send(discon_msg[3]);
//    // clock dismsg3_Send_Time = clock();
//    if (re > 0)
//    {
//        // cout <<"[Client] "<< "Send Message to Router! -- Fourth-Way Wavehand" << endl;
//        discon_msg[3].Print_Packet();
//    }
//    cout << "Fourth-Way Wavehand is successful!" << endl;
//
//    Packet exit_msg;
//    float exit_msg_time = clock();
//    while (clock() - exit_msg_time < 2 * TIMEOUT)
//    {
//        if (recvfrom(clientsocket, (char*)&exit_msg, sizeof(exit_msg), 0, (SOCKADDR*)&serveraddr, &serveraddrlen) > 0)
//        {
//            Seq = exit_msg.Seq;
//            exit_msg.Ack = exit_msg.Seq;
//            exit_msg.Set_ACK();
//            exit_msg.Seq = ++Seq;
//            send(exit_msg);
//        }
//    }
//    closesocket(clientsocket);
//    WSACleanup();
//    cout << "[Client] "
//        << "Client is closed!" << endl;
//    system("pause");
//    return;
//}
//
//int main() {
//    
//    
//
//    WSADATA wsaData;
//    WSAStartup(MAKEWORD(2, 2), &wsaData);
//
//    //SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
//    clientsocket = socket(AF_INET, SOCK_DGRAM, 0);
//    if (clientsocket == INVALID_SOCKET) {
//        cerr << "Socket creation failed." << endl;
//        return -1;
//    }
//    cout << "Socket creation succeeded!"<<endl;
//
//    /*sockaddr_in serverAddr;
//    serverAddr.sin_family = AF_INET;
//    serverAddr.sin_port = htons(8080);
//    if (inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr) != 1) {
//        cerr << "Invalid IP address." << endl;
//        return -1;
//    }*/
//    struct in_addr addr;
//    if (inet_pton(AF_INET, clientip.c_str(), &addr) <= 0) {
//        std::cerr << "Invalid IP address format" << std::endl;
//        return 1;
//    }
//
//    clientaddr.sin_family = AF_INET;
//    clientaddr.sin_port = htons(clientport);
//    //clientaddr.sin_addr.S_un.S_addr = inet_addr(clientip.c_str());
//    clientaddr.sin_addr.S_un.S_addr = addr.s_addr;
//
//    if (bind(clientsocket, (SOCKADDR*)&clientaddr, sizeof(SOCKADDR)) == SOCKET_ERROR)
//    {
//        cout << "Error in Binding Socket!\n";
//        exit(EXIT_FAILURE);
//        return false;
//    }
//    cout << "Binding Socket to port " << clientport << " is successful!\n\n" ;
//
//    if (!connect())
//    {
//        cout << "Error in Connecting!" << endl;
//    }
//
//    string filePath;
//
//    cout << "Enter the file path to send: ";
//    getline(cin, filePath);
//    cout << "filePath:" << filePath << endl;
//    Send_Message(filePath);
//    Disconnect();
//    /*sendFile(filePath, clientsocket, serverAddr);
//
//    closesocket(sock);
//    WSACleanup();*/
//    return 0;
//}
//
//
//
//
//
//
//
//
//
//
//
//
////#include <iostream>
////#include <fstream>
////#include <string>
////#include <winsock2.h>
////#include <ws2tcpip.h>
////#include <chrono>
////#include <iomanip>
////#include <sstream>
////
////using namespace std;
////
////#pragma comment(lib, "ws2_32.lib")
////
////const int BUFFER_SIZE = 1024;
////const int TIMEOUT = 1000;
////const int MAX_SEQ = 1;
////
////enum PacketType { SYN, SYN_ACK, ACK, FIN, FIN_ACK, DATA };
////
////struct Packet {
////    PacketType type;
////    int seq;
////    int checksum;
////    char data[BUFFER_SIZE];
////};
////
////int calculateChecksum(Packet& packet) {
////    int sum = packet.type + packet.seq;
////    for (int i = 0; i < BUFFER_SIZE; i++) {
////        sum += static_cast<unsigned char>(packet.data[i]);
////    }
////    return sum;
////}
////
////void logEvent(const string& event, const Packet& packet) {
////    cout << "[" << chrono::system_clock::to_time_t(chrono::system_clock::now())
////        << "] " << event << " | Type: " << packet.type << ", Seq: " << packet.seq
////        << ", Checksum: " << packet.checksum << endl;
////}
////
////bool establishConnection(SOCKET& sock, sockaddr_in& serverAddr) {
////    Packet packet = { SYN, 0, 0, {0} };
////    packet.checksum = calculateChecksum(packet);
////
////    // Send SYN
////    sendto(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&serverAddr, sizeof(serverAddr));
////    logEvent("Sent SYN", packet);
////
////    // Wait for SYN-ACK
////    fd_set readfds;
////    FD_ZERO(&readfds);
////    FD_SET(sock, &readfds);
////
////    timeval timeout = { TIMEOUT / 1000, (TIMEOUT % 1000) * 1000 };
////    if (select(0, &readfds, nullptr, nullptr, &timeout) > 0) {
////        recvfrom(sock, (char*)&packet, sizeof(packet), 0, nullptr, nullptr);
////        if (packet.type == SYN_ACK) {
////            logEvent("Received SYN-ACK", packet);
////
////            // Send ACK
////            packet = { ACK, 0, calculateChecksum(packet), {0} };
////            sendto(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&serverAddr, sizeof(serverAddr));
////            logEvent("Sent ACK", packet);
////            return true;
////        }
////    }
////    cerr << "Connection establishment failed." << endl;
////    return false;
////}
////
////void terminateConnection(SOCKET& sock, sockaddr_in& serverAddr) {
////    Packet packet = { FIN, 0, 0, {0} };
////    packet.checksum = calculateChecksum(packet);
////
////    // Send FIN
////    sendto(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&serverAddr, sizeof(serverAddr));
////    logEvent("Sent FIN", packet);
////
////    // Wait for FIN-ACK
////    fd_set readfds;
////    FD_ZERO(&readfds);
////    FD_SET(sock, &readfds);
////
////    timeval timeout = { TIMEOUT / 1000, (TIMEOUT % 1000) * 1000 };
////    if (select(0, &readfds, nullptr, nullptr, &timeout) > 0) {
////        recvfrom(sock, (char*)&packet, sizeof(packet), 0, nullptr, nullptr);
////        if (packet.type == FIN_ACK) {
////            logEvent("Received FIN-ACK", packet);
////
////            // Send final ACK
////            packet = { ACK, 0, calculateChecksum(packet), {0} };
////            sendto(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&serverAddr, sizeof(serverAddr));
////            logEvent("Sent final ACK", packet);
////        }
////    }
////    cout << "Connection terminated." << endl;
////}
////
////void sendFile(const string& filepath, SOCKET& sock, sockaddr_in& serverAddr) {
////    if (!establishConnection(sock, serverAddr)) {
////        return;
////    }
////
////    ifstream file(filepath, ios::binary);
////    if (!file.is_open()) {
////        cerr << "Failed to open file: " << filepath << endl;
////        return;
////    }
////
////    int seq = 0;
////    Packet packet = {};
////    int serverLen = sizeof(serverAddr);
////    file.seekg(0, ios::end);
////    int fileSize = static_cast<int>(file.tellg());
////    file.seekg(0, ios::beg);
////
////    while (file.read(packet.data, BUFFER_SIZE) || file.gcount() > 0) {
////        packet.type = DATA;
////        packet.seq = seq;
////        int dataSize = static_cast<int>(file.gcount());
////        memset(packet.data + dataSize, 0, BUFFER_SIZE - dataSize);
////        packet.checksum = calculateChecksum(packet);
////
////        sendto(sock, (char*)&packet, sizeof(packet), 0, (sockaddr*)&serverAddr, serverLen);
////        logEvent("Sent DATA", packet);
////
////        seq = (seq + 1) % (MAX_SEQ + 1);
////    }
////
////    file.close();
////    terminateConnection(sock, serverAddr);
////}
////
////int main() {
////    string filePath;
////    cout << "Enter the file path to send: ";
////    getline(cin, filePath);
////
////    WSADATA wsaData;
////    WSAStartup(MAKEWORD(2, 2), &wsaData);
////
////    SOCKET sock = socket(AF_INET, SOCK_DGRAM, 0);
////    if (sock == INVALID_SOCKET) {
////        cerr << "Socket creation failed." << endl;
////        return -1;
////    }
////
////    sockaddr_in serverAddr;
////    serverAddr.sin_family = AF_INET;
////    serverAddr.sin_port = htons(8080);
////    inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr);
////
////    sendFile(filePath, sock, serverAddr);
////
////    closesocket(sock);
////    WSACleanup();
////    return 0;
////}
//



#include <iostream>
#include <WINSOCK2.h>
#include <time.h>
#include <fstream>
#include <iomanip>
#include <string>
#include <ctime>
#include <chrono>    // chrono::system_clock
#include <sstream>   // stringstream
#include <iomanip>   // put_time
#pragma comment(lib, "ws2_32.lib")
#pragma warning(disable : 4996)
using namespace std;

const int MAXSIZE = 8192; // 传输缓冲区最大长度

const unsigned char SYN = 0x1;
const unsigned char ACK = 0x2;
const unsigned char ACK_SYN = 0x3;
const unsigned char FIN = 0x4;
const unsigned char FIN_ACK = 0x5;
const unsigned char OVER = 0x7;
// 结束标志 111—— FIN = 1 ACK = 1 SYN = 1

double MAX_TIME = 0.5 * CLOCKS_PER_SEC;

u_short checkSum(u_short* mes, int size)
{
    int count = (size + 1) / 2;
    u_short* buf = (u_short*)malloc(size + 1);
    memset(buf, 0, size + 1);
    memcpy(buf, mes, size);
    u_long sum = 0;
    while (count--)
    {
        sum += *buf++;
        if (sum & 0xffff0000)
        {
            sum &= 0xffff;
            sum++;
        }
    }
    return ~(sum & 0xffff);
}

struct Packet
{
    u_short sum = 0;      // 校验和 16位
    u_short datasize = 0; // 所包含数据长度 16位
    
    unsigned char flag = 0;// 八位，使用后四位，排列是FIN ACK SYN
    
    unsigned char SEQ = 0;// 八位，传输的序列号，0~255，超过后mod
    Packet()
    {
        sum = 0;      // 校验和 16位
        datasize = 0; // 所包含数据长度 16位
        flag = 0;     // 8位，使用后四位，排列是FIN ACK SYN
        SEQ = 0;      // 8位
    }
};
string getCurrentTime() {
    auto now = chrono::system_clock::now();
    time_t timeNow = chrono::system_clock::to_time_t(now);
    tm localTime;
    localtime_s(&localTime, &timeNow);
    stringstream ss;
    ss << put_time(&localTime, "%Y-%m-%d %H:%M:%S");
    return ss.str();
}
int Connect(SOCKET& socketClient, SOCKADDR_IN& servAddr, int& servAddrlen) // 三次握手建立连接
{
    Packet packet;
    char* Buffer = new char[sizeof(packet)];

    // 第一次握手
    packet.flag = SYN;
    packet.sum = 0; // 校验和置0
    packet.sum = checkSum((u_short*)&packet, sizeof(packet));// 计算校验和
    memcpy(Buffer, &packet, sizeof(packet));// 将数据头放入buffer
    if (sendto(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen) == -1)
    {
        return -1;
    }
    else
    {
        //cout << "[\033[1;31mSend\033[0m] 成功发送第一次握手数据" << endl;
        cout << "[" << getCurrentTime() << "] " << "[Send] Send the first handshake!" << endl;
    }
    clock_t start = clock(); // 记录发送第一次握手时间

    // 为了函数能够继续运行，设置socket为非阻塞状态
    u_long mode = 1;
    ioctlsocket(socketClient, FIONBIO, &mode);

    // 第二次握手
    while (recvfrom(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, &servAddrlen) <= 0)
    {
        // 超时需要重传
        if (clock() - start > MAX_TIME) // 超时，重新传输第一次握手
        {
            
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mWARNING\033[0m] The first handshake is TIMEOUT" << endl;
            packet.flag = SYN;
            packet.sum = 0;                                            // 校验和置0
            packet.sum = checkSum((u_short*)&packet, sizeof(packet)); // 计算校验和
            memcpy(Buffer, &packet, sizeof(packet));                   // 将数据头放入Buffer
            sendto(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen);
            start = clock();
            //cout << "[\033[1;33mNote\033[0m] 已经重传" << endl;
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mNote\033[0m] Already transmit repeatedly" << endl;
        }
    }

    // 第二次握手，收到来自接收端的ACK
    // 进行校验和检验
    memcpy(&packet, Buffer, sizeof(packet));
    if (packet.flag == ACK && checkSum((u_short*)&packet, sizeof(packet)) == 0)
    {
        //cout << "[\033[1;32mReceive\033[0m] 接收到第二次握手数据" << endl;
        cout << "[" << getCurrentTime() << "] " << "[Receive] Recieved the second handshake!" << endl;
    }
    else
    {
        //cout << "[\033[1;33mNote\033[0m] 错误数据，请重试" << endl;
        cout << "[" << getCurrentTime() << "] " << "[Note] Error,please try again!" << endl;
        return -1;
    }

    // 进行第三次握手
    packet.flag = ACK_SYN;
    packet.sum = 0;
    packet.sum = checkSum((u_short*)&packet, sizeof(packet)); // 计算校验和
    if (sendto(socketClient, (char*)&packet, sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen) == -1)
    {
        return -1;
    }
    else
    {
        //cout << "[\033[1;31mSend\033[0m] 成功发送第三次握手数据" << endl;
        cout << "[" << getCurrentTime() << "] " << "[Send] Send the third handshake!" << endl;
    }
    //cout << "[\033[1;33mNote\033[0m] 服务器成功连接！可以发送数据" << endl;
    cout << "[" << getCurrentTime() << "] " << "[Note] Connected successfully!" << endl;
    return 1;
}

void send_package(SOCKET& socketClient, SOCKADDR_IN& servAddr, int& servAddrlen, char* message, int len, int& order)
{
    Packet packet;
    char* Buffer = new char[MAXSIZE + sizeof(packet)];
    packet.datasize = len;
    packet.SEQ = static_cast<unsigned char>(order);                 // 序列号
    memcpy(Buffer, &packet, sizeof(packet));                        // 将计算好校验和的packet重新赋值给buffer，此时的buffer可以发送了
    memcpy(Buffer + sizeof(packet), message, len);                  // buffer为packet+message
    packet.sum = checkSum((u_short*)Buffer, sizeof(packet) + len); // 计算校验和
    // 发送
    sendto(socketClient, Buffer, len + sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen);

    cout << "[" << getCurrentTime() << "] " << "[Send] Send " << len << " Bytes，"
        << " flag:" << int(packet.flag)
        << " SEQ:" << int(packet.SEQ) << " Checksum:" << int(packet.sum) << endl;
    clock_t start = clock(); // 记录发送时间

    // 接收ack等信息
    while (1)
    {
        u_long mode = 1;
        ioctlsocket(socketClient, FIONBIO, &mode); // 将套接口状态改为非阻塞，使 recvfrom 不会无限等待

        while (recvfrom(socketClient, Buffer, MAXSIZE, 0, (sockaddr*)&servAddr, &servAddrlen) <= 0)
        {
            // 超时重传
            if (clock() - start > MAX_TIME)
            {
                
                cout << "[" << getCurrentTime() << "] " << "[\033[1;33mWARNING\033[0m] Transmit is TIMEOUT" << endl;
                packet.datasize = len;
                packet.SEQ = u_char(order); // 序列号
                packet.flag = u_char(0x0);  //不设置
                memcpy(Buffer, &packet, sizeof(packet));
                memcpy(Buffer + sizeof(packet), message, sizeof(packet) + len);
                u_short check = checkSum((u_short*)Buffer, sizeof(packet) + len); // 计算校验和
                packet.sum = check;
                memcpy(Buffer, &packet, sizeof(packet));
                sendto(socketClient, Buffer, len + sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen); // 发送
                cout << "[" << getCurrentTime() << "] " << "[\033[1;33mNote\033[0m] Already transmit repeatedly" << endl;
                start = clock(); // 记录发送时间
            }
            else
                break;
        }
        memcpy(&packet, Buffer, sizeof(packet)); // 缓冲区接收到信息，放入packet，此时packet中是收到的数据
        //收到ACK
        if (checkSum((u_short*)&packet, sizeof(packet)) == 0 && packet.SEQ == u_short(order) && packet.flag == ACK)
        {
            cout << "[" << getCurrentTime() << "] " << "[Receive] Confirmed - flag:" << int(packet.flag)
                << " ACK:" << int(packet.SEQ) << " Checksum:" << int(packet.sum) << endl;
            break;
        }
        else
        {
            continue;
        }
    }
    u_long mode = 0;
    ioctlsocket(socketClient, FIONBIO, &mode); // 改回阻塞模式
}

void send(SOCKET& socketClient, SOCKADDR_IN& servAddr, int& servAddrlen, char* message, int len)
{
    int packagenum = len / MAXSIZE + (len % MAXSIZE != 0); // 需要传送的数据包个数
    int seqnum = 0;//序列号从0开始递增，超256则-255
    //cout << packagenum << endl;
    for (int i = 0; i < packagenum; i++)
    {
        send_package(socketClient, servAddr, servAddrlen,message + i * MAXSIZE, i == packagenum - 1 ? len - (packagenum - 1) * MAXSIZE : MAXSIZE, seqnum);
        seqnum++;
        if (seqnum > 255)
        {
            seqnum = seqnum - 256;
        }
    }


    // 发送结束信息
    Packet packet;
    char* Buffer = new char[sizeof(packet)];
    packet.flag = OVER;
    packet.sum = checkSum((u_short*)&packet, sizeof(packet));
    memcpy(Buffer, &packet, sizeof(packet));
    sendto(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen);
    cout << "[" << getCurrentTime() << "] " << "[Send] Send OVER!" << endl;
    clock_t start = clock();
    while (1)
    {
        u_long mode = 1;
        ioctlsocket(socketClient, FIONBIO, &mode);
        // 收到包，存在Buffer中
        while (recvfrom(socketClient, Buffer, MAXSIZE, 0, (sockaddr*)&servAddr, &servAddrlen) <= 0)
        {
           
            if (clock() - start > MAX_TIME)
            {
                //cout << "[\033[1;33mNote\033[0m] 发送OVER信号超时" << endl;
                cout << "[" << getCurrentTime() << "] " << "[\033[1;33mWARNING\033[0m] Send OVER is TIMEOUT" << endl;
                char* Buffer = new char[sizeof(packet)];
                packet.flag = OVER;
                packet.sum = checkSum((u_short*)&packet, sizeof(packet));
                memcpy(Buffer, &packet, sizeof(packet));
                sendto(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen);
                //cout << "[\033[1;33mNote\033[0m] 已经重发OVER信号" << endl;
                cout << "[" << getCurrentTime() << "] " << "[Note] Already transmit repeatedly!" << endl;
                start = clock();
            }
        }
        memcpy(&packet, Buffer, sizeof(packet)); // 缓冲区接收到信息，读取Buffer里的信息
        u_short check = checkSum((u_short*)&packet, sizeof(packet));
        // 收到的数据包为OVER则已经成功接受文件
        if (packet.flag == OVER && check == 0)
        {
           // cout << "[\033[1;33mNote\033[0m] 对方已成功接收文件" << endl;
            cout << "[" << getCurrentTime() << "] " << "[Note] The receiver successfully received the File!" << endl;
            break;
        }
        else
        {
            continue;
        }
    }
    u_long mode = 0;
    ioctlsocket(socketClient, FIONBIO, &mode); // 改回阻塞模式
}

int disConnect(SOCKET& socketClient, SOCKADDR_IN& servAddr, int& servAddrlen)
{
    Packet packet;
    char* Buffer = new char[sizeof(packet)];

    u_short sum;

    // 进行第一次挥手
    packet.flag = FIN;
    packet.sum = 0;                                            // 校验和置0
    packet.sum = checkSum((u_short*)&packet, sizeof(packet)); // 计算校验和
    memcpy(Buffer, &packet, sizeof(packet));                   // 将首部放入缓冲区
    if (sendto(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen) == -1)
    {
        return -1;
    }
    else
    {
        //cout << "[\033[1;31mSend\033[0m] 成功发送第一次挥手数据" << endl;
        cout << "[" << getCurrentTime() << "] " << "[Send] Send the first wave!" << endl;
    }
    clock_t start = clock(); // 记录发送第一次挥手时间

    u_long mode = 1;
    ioctlsocket(socketClient, FIONBIO, &mode); // FIONBIO为命令，允许1/禁止0套接口s的非阻塞1/阻塞0模式。

    // 接收第二次挥手
    while (recvfrom(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, &servAddrlen) <= 0)
    {
        // 超时，重新传输第一次挥手
        if (clock() - start > MAX_TIME)
        {
            //cout << "[\033[1;33mNote\033[0m] 第一次挥手超时" << endl;
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mWARNING\033[0m] The first wave is TIMEOUT" << endl;
            packet.flag = FIN;
            packet.sum = 0;                                            // 校验和置0
            packet.sum = checkSum((u_short*)&packet, sizeof(packet)); // 计算校验和
            memcpy(Buffer, &packet, sizeof(packet));                   // 将首部放入缓冲区
            sendto(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen);
            start = clock();
            //cout << "[\033[1;33mNote\033[0m] 已重传第一次挥手数据" << endl;
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mNote\033[0m] Already transmit repeatedly" << endl;
        }
    }

    // 进行校验和检验
    memcpy(&packet, Buffer, sizeof(packet));
    if (packet.flag == ACK && checkSum((u_short*)&packet, sizeof(packet) == 0))
    {
        //cout << "[\033[1;32mReceive\033[0m] 接收到第二次挥手数据" << endl;
        cout << "[" << getCurrentTime() << "] " << "[Receive] Received the second wave!" << endl;
    }
    else
    {
        /*cout << "[\033[1;33mNote\033[0m] 错误数据，请重试" << endl;*/
        cout << "[" << getCurrentTime() << "] " << "[Note] Error,please try again!" << endl;
        return -1;
    }

    // 进行第三次挥手
    packet.flag = FIN_ACK;
    packet.sum = 0;
    packet.sum = checkSum((u_short*)&packet, sizeof(packet)); // 计算校验和
    if (sendto(socketClient, (char*)&packet, sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen) == -1)
    {
        return -1;
    }
    else
    {
        //cout << "[\033[1;31mSend\033[0m] 成功发送第三次挥手数据" << endl;
        cout << "[" << getCurrentTime() << "] " << "[Send] Send the third wave!" << endl;
    }
    start = clock();
    // 接收第四次挥手
    while (recvfrom(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, &servAddrlen) <= 0)
    {
        if (clock() - start > MAX_TIME) // 超时，重新传输第三次挥手
        {
            //cout << "[\033[1;33mNote\033[0m] 第三次挥手超时" << endl;
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mWARNING\033[0m] The Third wave is TIMEOUT" << endl;
            packet.flag = FIN;
            packet.sum = 0;                                            // 校验和置0
            packet.sum = checkSum((u_short*)&packet, sizeof(packet)); // 计算校验和
            memcpy(Buffer, &packet, sizeof(packet));                   // 将首部放入缓冲区
            sendto(socketClient, Buffer, sizeof(packet), 0, (sockaddr*)&servAddr, servAddrlen);
            start = clock();
            //cout << "[\033[1;33mNote\033[0m] 已重传第三次挥手数据" << endl;
            cout << "[" << getCurrentTime() << "] " << "[\033[1;33mNote\033[0m] Already transmit repeatedly" << endl;
        }
    }
    /*cout << "[\033[1;33mNote\033[0m] 四次挥手结束，连接断开！" << endl;*/
    cout << "[" << getCurrentTime() << "] " << "[Note] Disconnect! " << endl;
    return 1;
}

int main()
{
    cout << MAX_TIME << endl;

    WSADATA wsadata;
    WSAStartup(MAKEWORD(2, 2), &wsadata);

    SOCKADDR_IN serverAddr;
    SOCKET server;

    serverAddr.sin_family = AF_INET; // 使用IPV4
    serverAddr.sin_port = htons(8888);
    serverAddr.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");

    server = socket(AF_INET, SOCK_DGRAM, 0);
    int len = sizeof(serverAddr);

    // 建立连接
    if (Connect(server, serverAddr, len) == -1)
    {
        return 0;
    }

    bool flag = true;
    while (true)
    {
        /*cout << endl
            << "选择你要进行的操作" << endl
            << "1. 退出" << endl;*/
        cout << endl
            << "Please choose:" << endl
            << "1. Exit" << endl;
        if (flag)
        {
            //cout << "2. 传输文件" << endl;
            cout << "2. Transmit" << endl;
            flag = !flag;
        }
        else
        {
            /*cout << "2. 继续传输文件" << endl;*/
            cout << "2. Conntinue to Transmit" << endl;
        }

        int choice = {};

        cin >> choice;
        cout << endl;
        if (choice == 1)
            break;
        else
        {

            // 读取文件内容到buffer
            string inputFile; // 希望传输的文件名称
            /*cout << "请输入希望传输的文件名称" << endl;*/
            cout << "The File:" << endl;
            cin >> inputFile;
            ifstream fileIN(inputFile.c_str(), ifstream::binary); // 以二进制方式打开文件
            char* buffer = new char[100000000];                   // 文件内容
            int i = 0;
            unsigned char temp = fileIN.get();
            while (fileIN)
            {
                buffer[i++] = temp;
                temp = fileIN.get();
            }
            fileIN.close();

            // 发送文件名
            send(server, serverAddr, len, (char*)(inputFile.c_str()), inputFile.length());
            clock_t start1 = clock();
            // 发送文件内容（在buffer里）
            send(server, serverAddr, len, buffer, i);
            clock_t end1 = clock();

            /*cout << "[\033[1;36mOut\033[0m] 传输总时间为:" << (end1 - start1) / CLOCKS_PER_SEC << "s" << endl;*/
            cout << "[" << getCurrentTime() << "] " << "The Total Time is:" << (end1 - start1) / CLOCKS_PER_SEC << "s" << endl;
            /*cout << "[\033[1;36mOut\033[0m] 吞吐率为:" << fixed << setprecision(2) << (((double)i) / ((end1 - start1) / CLOCKS_PER_SEC)) << "byte/s" << endl;*/
            cout << "[" << getCurrentTime() << "] " << "The Throughput Rate is:" << fixed << setprecision(2) << (((double)i) / ((end1 - start1) / CLOCKS_PER_SEC)) << "byte/s" << endl;
        }
    }

    disConnect(server, serverAddr, len);
    system("pause");
    return 0;
}