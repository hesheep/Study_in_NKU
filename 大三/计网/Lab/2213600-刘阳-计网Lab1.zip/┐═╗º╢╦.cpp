
#include <iostream> 
#include <winsock2.h> 
#include <ws2tcpip.h> 
#include <thread> 
#include <chrono> 
#include <iomanip> 
#include <ctime> 
#include <sstream> 

#pragma comment(lib, "ws2_32.lib") // ���� Windows Socket 2 ��

#define PORT 8080 
#define BUFFER_SIZE 1024 

using namespace std; 


string getCurrentTime() {
    auto now = chrono::system_clock::now(); 
    time_t now_c = chrono::system_clock::to_time_t(now); 
    tm parts; 
    localtime_s(&parts, &now_c); 
    stringstream ss; 
    ss << "[" << put_time(&parts, "%Y-%m-%d %H:%M:%S") << "] "; 
    return ss.str(); 
}

// ������Ϣ�ĺ���
void receiveMessages(SOCKET sock) {
    char buffer[BUFFER_SIZE]; 
    while (true) { // ��ѭ��������������Ϣ
        int bytesReceived = recv(sock, buffer, sizeof(buffer), 0); 
        if (bytesReceived <= 0) break; 
        buffer[bytesReceived] = '\0'; 

        
        cout << getCurrentTime() + buffer << endl; 
    }
}

int main() {
    WSADATA wsaData; 
    WSAStartup(MAKEWORD(2, 2), &wsaData); 

    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0); 
    sockaddr_in serverAddr; 

    serverAddr.sin_family = AF_INET; 
    serverAddr.sin_port = htons(PORT); 
    inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr); 

    connect(sock, (struct sockaddr*)&serverAddr, sizeof(serverAddr)); 

    thread(receiveMessages, sock).detach(); 
   
    char welcomeMessage[BUFFER_SIZE];
    int bytesReceived = recv(sock, welcomeMessage, sizeof(welcomeMessage), 0);
    if (bytesReceived > 0) {
        welcomeMessage[bytesReceived] = '\0';
        cout << welcomeMessage << endl; 
    }

    char message[BUFFER_SIZE]; 
    while (true) { // ��ѭ����������ȡ�û�����
        cin.getline(message, BUFFER_SIZE); 
        if (strcmp(message, "/exit") == 0) { // ��������� "/exit"
            break; 
        }
        send(sock, message, strlen(message), 0); 
    }

    
    closesocket(sock); 
    WSACleanup(); 
    return 0; 
}

