#include <swap.h>           // 包含用于交换（swap）相关操作的头文件
#include <swapfs.h>         // 包含交换文件系统的定义和函数的头文件
#include <mmu.h>            // 包含内存管理单元（MMU）相关定义和操作
#include <fs.h>             // 包含文件系统的定义和函数
#include <ide.h>            // 包含IDE设备的操作接口
#include <pmm.h>            // 包含物理内存管理的定义和操作
#include <assert.h>         // 提供断言宏 `assert` 和静态断言宏 `static_assert`

void
swapfs_init(void) {
    static_assert((PGSIZE % SECTSIZE) == 0); // 静态断言：页面大小必须是硬盘扇区大小的整数倍
    if (!ide_device_valid(SWAP_DEV_NO)) {   // 检查交换设备号对应的IDE设备是否有效
        panic("swap fs isn't available.\n"); // 如果设备无效，触发内核错误，打印错误信息并停止执行
    }
    max_swap_offset = ide_device_size(SWAP_DEV_NO) / (PGSIZE / SECTSIZE); // 计算最大交换偏移量，按页面大小划分设备容量
}

int
swapfs_read(swap_entry_t entry, struct Page *page) {
    return ide_read_secs(SWAP_DEV_NO,         // 从交换设备号指定的设备中读取数据
                         swap_offset(entry) * PAGE_NSECT, // 计算读取的起始扇区位置（按交换条目索引换算）
                         page2kva(page),     // 将物理页的地址转换为虚拟地址
                         PAGE_NSECT);        // 每次读取的扇区数量，与页面大小对应
}

int
swapfs_write(swap_entry_t entry, struct Page *page) {
    return ide_write_secs(SWAP_DEV_NO,        // 向交换设备号指定的设备写入数据
                          swap_offset(entry) * PAGE_NSECT, // 计算写入的起始扇区位置（按交换条目索引换算）
                          page2kva(page),     // 将物理页的地址转换为虚拟地址
                          PAGE_NSECT);        // 每次写入的扇区数量，与页面大小对应
}
//根据交换条目 entry 和页面大小 PAGE_NSECT，计算出目标写入的扇区位置；
//将物理页的虚拟地址转换为内核可用的虚拟地址；
//调用 ide_write_secs，将一个页面的数据写入交换设备的指定位置；
//返回写入操作的结果。

