#include <default_pmm.h>
#include <defs.h>
#include <error.h>
#include <memlayout.h>
#include <mmu.h>
#include <pmm.h>
#include <sbi.h>
#include <stdio.h>
#include <string.h>
#include <swap.h>
#include <sync.h>
#include <vmm.h>
#include <riscv.h>

// virtual address of physical page array
// 物理页面数组的虚拟地址
struct Page *pages;
// amount of physical memory (in pages)
// 物理内存的总量（以页为单位）
size_t npage = 0;
// The kernel image is mapped at VA=KERNBASE and PA=info.base
// 内核镜像映射到 VA=KERNBASE，PA=info.base
uint_t va_pa_offset;
// memory starts at 0x80000000 in RISC-V
// 在 RISC-V 上，内存从 0x80000000 开始
const size_t nbase = DRAM_BASE / PGSIZE;

// virtual address of boot-time page directory
// 引导时的页目录的虚拟地址
pde_t *boot_pgdir = NULL;
// physical address of boot-time page directory
// 引导时的页目录的物理地址
uintptr_t boot_cr3;

// physical memory management
// 物理内存管理
const struct pmm_manager *pmm_manager;


static void check_alloc_page(void);
static void check_pgdir(void);
static void check_boot_pgdir(void);

// init_pmm_manager - initialize a pmm_manager instance
// init_pmm_manager - 初始化 pmm_manager 实例
static void init_pmm_manager(void) {
    pmm_manager = &default_pmm_manager;
    cprintf("memory management: %s\n", pmm_manager->name);
    pmm_manager->init();
}

// init_memmap - call pmm->init_memmap to build Page struct for free memory
// init_memmap - 调用 pmm->init_memmap 来构建自由内存的 Page 结构
static void init_memmap(struct Page *base, size_t n) {
    pmm_manager->init_memmap(base, n);
}

// alloc_pages - call pmm->alloc_pages to allocate a continuous n*PAGESIZE
// alloc_pages - 调用 pmm->alloc_pages 分配连续的 n*PAGESIZE 内存
// memory
struct Page *alloc_pages(size_t n) {  //消极换出策略实现
    struct Page *page = NULL;
    bool intr_flag;

    while (1) {
        local_intr_save(intr_flag);  // 保存中断状态
        { page = pmm_manager->alloc_pages(n); }  // 调用物理内存管理器分配页面
        local_intr_restore(intr_flag);  // 恢复中断状态
        //如果有足够的物理页面，就不必换出其他页面
        //如果n>1, 说明希望分配多个连续的页面，但是我们换出页面的时候并不能换出连续的页面
         //swap_init_ok标志是否成功初始化了
        if (page != NULL || n > 1 || swap_init_ok == 0) break;

        extern struct mm_struct *check_mm_struct;
        swap_out(check_mm_struct, n, 0);//调用页面置换的”换出页面“接口。这里必有n=1
    }
    return page;
}

// free_pages - call pmm->free_pages to free a continuous n*PAGESIZE memory
// free_pages - 调用 pmm->free_pages 来释放连续的 n*PAGESIZE 内存
void free_pages(struct Page *base, size_t n) {
    bool intr_flag;//保存中断状态

    local_intr_save(intr_flag);  // 保存中断状态——>将当前的中断标志保存到 intr_flag 中
    { pmm_manager->free_pages(base, n); }  // 调用物理内存管理器释放页面
    local_intr_restore(intr_flag);  // 恢复之前保存的中断标志 intr_flag


// nr_free_pages - call pmm->nr_free_pages to get the size (nr*PAGESIZE)
// of current free memory
// nr_free_pages - 调用 pmm->nr_free_pages 来获取当前空闲内存的大小（以页为单位）
size_t nr_free_pages(void) {
    size_t ret;
    bool intr_flag;
    local_intr_save(intr_flag);  // 保存中断状态
    { ret = pmm_manager->nr_free_pages(); }  // 获取空闲内存的页数
    local_intr_restore(intr_flag);  // 恢复中断状态
    return ret;  // 返回空闲内存的页数
}

/* page_init - initialize the physical memory management */
/* page_init - 初始化物理内存管理 */
static void page_init(void) {
    extern char kern_entry[];  // 引用内核入口地址

    va_pa_offset = KERNBASE - 0x80200000;  // 计算虚拟地址与物理地址的偏移
    uint64_t mem_begin = KERNEL_BEGIN_PADDR;  // 物理内存开始地址
    uint64_t mem_size = PHYSICAL_MEMORY_END - KERNEL_BEGIN_PADDR;  // 物理内存大小
    uint64_t mem_end = PHYSICAL_MEMORY_END;  // 物理内存结束地址
    cprintf("membegin %llx memend %llx mem_size %llx\n",mem_begin, mem_end, mem_size);  // 输出物理内存信息
    cprintf("physcial memory map:\n");
    cprintf("  memory: 0x%08lx, [0x%08lx, 0x%08lx].\n", mem_size, mem_begin, mem_end - 1);  // 输出物理内存映射信息
    uint64_t maxpa = mem_end;

    if (maxpa > KERNTOP) {  // 如果物理内存结束地址大于内核顶部地址，则使用内核顶部地址
        maxpa = KERNTOP;
    }
    extern char end[];  // 引用内核结束符

    npage = maxpa / PGSIZE;  // 计算物理内存的总页数
    // BBL 已经将初始页表放在内核后面的第一个可用页面
    // 所以通过增加额外的偏移量来避免它
    pages = (struct Page *)ROUNDUP((void *)end, PGSIZE);  // 将页结构体对齐到页面边界
    for (size_t i = 0; i < npage - nbase; i++) {
        SetPageReserved(pages + i);  // 设置页面为已保留
    }

    uintptr_t freemem = PADDR((uintptr_t)pages + sizeof(struct Page) * (npage - nbase));  // 计算空闲内存的物理地址
    mem_begin = ROUNDUP(freemem, PGSIZE);  // 将内存开始地址对齐到页边界
    mem_end = ROUNDDOWN(mem_end, PGSIZE);  // 将内存结束地址对齐到页边界
    if (freemem < mem_end) {  // 如果空闲内存小于内存结束地址
        init_memmap(pa2page(mem_begin), (mem_end - mem_begin) / PGSIZE);  // 初始化内存映射
    }
}

static void enable_paging(void) {
    write_csr(satp, (0x8000000000000000) | (boot_cr3 >> RISCV_PGSHIFT));// 设置 satp 寄存器来启用分页
}

/**
 * @brief      setup and enable the paging mechanism
 *
 * @param      pgdir  The page dir
 * @param[in]  la     Linear address of this memory need to map
 * @param[in]  size   Memory size
 * @param[in]  pa     Physical address of this memory
 * @param[in]  perm   The permission of this memory
 */

//将一段线性地址范围（虚拟地址）映射到一段物理地址，并为这些映射设置相应的权限
static void boot_map_segment(pde_t *pgdir, uintptr_t la, size_t size,
                             uintptr_t pa, uint32_t perm) {
    assert(PGOFF(la) == PGOFF(pa));  // 确保线性地址和物理地址的页内偏移相同
    size_t n = ROUNDUP(size + PGOFF(la), PGSIZE) / PGSIZE;  // 计算所需的页数
    la = ROUNDDOWN(la, PGSIZE);  // 将线性地址对齐到页边界
    pa = ROUNDDOWN(pa, PGSIZE);  // 将物理地址对齐到页边界
    for (; n > 0; n--, la += PGSIZE, pa += PGSIZE) {
        pte_t *ptep = get_pte(pgdir, la, 1);  // 获取页表项
        assert(ptep != NULL);  // 确保页表项存在
        *ptep = pte_create(pa >> PGSHIFT, PTE_V | perm);  // 创建页表项并设置权限
    }
}

// boot_alloc_page - 使用 pmm->alloc_pages(1) 分配一页内存
// 返回值：分配的内核虚拟地址
// 注意：该函数用于为页目录表(PDT)和页表(PT)分配内存
static void *boot_alloc_page(void) {
    struct Page *p = alloc_page();  // 调用 alloc_page 函数分配一页物理内存
    if (p == NULL) {  // 如果分配失败，则调用 panic 函数终止程序
        panic("boot_alloc_page failed.\n");  // 如果分配失败，打印错误信息并停止程序
    }
    return page2kva(p);  // 将物理页转换为内核虚拟地址并返回
}


// boot_alloc_page - 使用 pmm->alloc_pages(1) 分配一页内存
// 返回值：分配的内核虚拟地址
// 注意：该函数用于为页目录表(PDT)和页表(PT)分配内存
static void *boot_alloc_page(void) {
    struct Page *p = alloc_page();  // 调用 alloc_page 函数分配一页物理内存
    if (p == NULL) {  // 如果分配失败，则调用 panic 函数终止程序
        panic("boot_alloc_page failed.\n");  // 如果分配失败，打印错误信息并停止程序
    }
    return page2kva(p);  // 将物理页转换为内核虚拟地址并返回
}

// pmm_init - 设置物理内存管理器(pmm)，构建页目录表(PDT)和页表(PT)来设置分页机制
//           - 检查 pmm 和分页机制的正确性，打印 PDT 和 PT
void pmm_init(void) {
    // 我们需要分配/释放物理内存（粒度是 4KB 或其他大小）。
    // 因此，在 pmm.h 中定义了物理内存管理器框架（struct pmm_manager）。
    // 首先，我们应该根据框架初始化物理内存管理器(pmm)。
    // 然后 pmm 可以进行内存的分配和释放。
    // 当前支持的 pmm 模式有 first_fit、best_fit、worst_fit 和 buddy_system。
    init_pmm_manager();  // 初始化物理内存管理器，基于 pmm 框架

    // 检测物理内存空间，保留已使用的内存，
    // 然后使用 pmm->init_memmap 创建空闲页链表
    page_init();  // 初始化页面，检测物理内存，构建空闲页链表

    // 使用 pmm->check 来验证分配/释放功能的正确性
    check_alloc_page();  // 验证内存分配和释放的正确性

    // 创建 boot_pgdir，这是初始的页目录（Page Directory Table, PDT）
    extern char boot_page_table_sv39[];  // 声明外部符号 boot_page_table_sv39，这是初始的页表
    boot_pgdir = (pte_t*)boot_page_table_sv39;  // 将 boot_page_table_sv39 的地址赋值给 boot_pgdir，作为页目录
    boot_cr3 = PADDR(boot_pgdir);  // 设置 CR3 寄存器的值，指向页目录的物理地址
    check_pgdir();  // 检查页目录是否正确

    // static_assert(KERNBASE % PTSIZE == 0 && KERNTOP % PTSIZE == 0);
    // 检查 KERNBASE 和 KERNTOP 是否是页表大小（PTSIZE）的整数倍

    // 将所有物理内存映射到线性内存，基地址为 KERNBASE
    // 线性地址 KERNBASE~KERNBASE+KMEMSIZE 映射到物理地址 0~KMEMSIZE
    // 但是在完成 enable_paging() 和 gdt_init() 之前，不应该使用此映射
    //boot_map_segment(boot_pgdir, KERNBASE, KMEMSIZE, PADDR(KERNBASE),
    //                 READ_WRITE_EXEC);
    // 这段代码是为了将所有物理内存映射到线性地址空间，但在启用分页和初始化 GDT 之前不应该使用此映射

    // 临时映射：
    // 虚拟地址 3G~3G+4M 映射到线性地址 0~4M，再映射到物理地址 0~4M
    // boot_pgdir[0] = boot_pgdir[PDX(KERNBASE)];
    // 这行代码是将虚拟地址 3GB ~ 3GB+4MB 映射到物理地址 0 ~ 4MB

    // enable_paging();
    // 启用分页机制，通常在 GDT 初始化完成后调用该函数

    // 现在基本的虚拟内存映射（参见 memlayout.h）已经建立。
    // 检查基本虚拟内存映射是否正确。
    check_boot_pgdir();  // 检查虚拟内存的基本映射是否正确
}

// get_pte - 获取页表项，并返回这个页表项在内核虚拟地址空间中的地址
//          - 如果页表项不存在，则分配一个新的页表页
// 参数:
//  pgdir:  页目录的内核虚拟基地址
//  la:     需要映射的线性地址
//  create: 如果为真，表示需要创建页表
// 返回值:  页表项的内核虚拟地址
pte_t *get_pte(pde_t *pgdir, uintptr_t la, bool create) {
    /* LAB2 EXERCISE 2: YOUR CODE
     *
     * 如果需要访问物理地址，可以使用 KADDR()
     * 请查看 pmm.h 获取有用的宏
     *
     * 也许你想看看下面的注释，这些注释能帮助你完成代码
     *
     * 一些有用的宏和定义，你可以在下面的实现中使用它们。
     * 宏或函数：
     *   PDX(la) = VIRTUAL ADDRESS la 的页目录项索引
     *   KADDR(pa) : 将物理地址转换为对应的内核虚拟地址
     *   set_page_ref(page, 1) : 表示该页被引用一次
     *   page2pa(page): 获取该 page 结构管理的内存的物理地址
     *   struct Page * alloc_page() : 分配一个页面
     *   memset(void *s, char c, size_t n) : 将内存区的前 n 字节设置为指定的值 c
     * DEFINEs:
     *   PTE_P           0x001                   // 页表项标志：Present
     *   PTE_W           0x002                   // 页表项标志：可写
     *   PTE_U           0x004                   // 页表项标志：用户可访问
     */
    pde_t *pdep1 = &pgdir[PDX1(la)]; // 找到对应的 Giga 页
    if (!(*pdep1 & PTE_V)) {  // 如果下一级页表不存在，则分配一页
        struct Page *page;
        if (!create || (page = alloc_page()) == NULL) {  // 如果不允许创建页表或内存分配失败
            return NULL;  // 返回 NULL
        }
        set_page_ref(page, 1);  // 设置页表页的引用计数
        uintptr_t pa = page2pa(page);  // 获取页表页的物理地址
        memset(KADDR(pa), 0, PGSIZE);  // 将页表页的内存清零
        // 我们现在在虚拟地址空间中，所以要转换为 KADDR 再 memset。
        // 不管页表怎么构造，我们确保物理地址和虚拟地址的偏移量始终相同，
        // 那么就可以用这种方式完成对物理内存的访问。
        *pdep1 = pte_create(page2ppn(page), PTE_U | PTE_V);  // 更新页目录项，标记为有效，并设置权限
    }
    pde_t *pdep0 = &((pde_t *)KADDR(PDE_ADDR(*pdep1)))[PDX0(la)]; // 再下一级页表
    // 这里的逻辑和前面完全一致，页表不存在就分配一个新的页表页
    if (!(*pdep0 & PTE_V)) {
        struct Page *page;
        if (!create || (page = alloc_page()) == NULL) {  // 如果不允许创建页表或内存分配失败
                return NULL;  // 返回 NULL
        }
        set_page_ref(page, 1);  // 设置页表页的引用计数
        uintptr_t pa = page2pa(page);  // 获取页表页的物理地址
        memset(KADDR(pa), 0, PGSIZE);  // 将页表页的内存清零
        *pdep0 = pte_create(page2ppn(page), PTE_U | PTE_V);  // 更新页目录项，标记为有效，并设置权限
    }
    // 找到输入的虚拟地址 la 对应的页表项的地址（可能是刚刚分配的）
    return &((pte_t *)KADDR(PDE_ADDR(*pdep0)))[PTX(la)];  // 返回页表项的地址
}

// get_page - 根据线性地址 la 和页目录 pgdir 获取相关的 Page 结构
struct Page *get_page(pde_t *pgdir, uintptr_t la, pte_t **ptep_store) {
    pte_t *ptep = get_pte(pgdir, la, 0);  // 获取对应的页表项
    if (ptep_store != NULL) {  // 如果传入了 ptep_store 参数
        *ptep_store = ptep;  // 将页表项地址存储到 ptep_store 中
    }
    if (ptep != NULL && *ptep & PTE_V) {  // 如果页表项有效
        return pte2page(*ptep);  // 返回对应的 Page 结构
    }
    return NULL;  // 如果无效，返回 NULL
}

// page_remove_pte - 释放与线性地址 la 相关的 Page 结构，并清除（使其无效）相关的页表项
// 注意：因为页表发生了变化，需要手动刷新 TLB
static inline void page_remove_pte(pde_t *pgdir, uintptr_t la, pte_t *ptep) {
    /*
     *
     * 请检查 ptep 是否有效，如果映射更新了，必须手动更新 TLB
     *
     * 也许你想看看下面的注释，这些注释能帮助你完成代码
     *
     * 一些有用的宏和定义，你可以在下面的实现中使用它们。
     * 宏或函数：
     *   struct Page *page pte2page(*ptep): 根据 ptep 获取对应的 page
     *   free_page : 释放一个页面
     *   page_ref_dec(page) : 减少 page->ref 引用计数。如果 page->ref == 0 ，
     * 那么该页应该被释放。
     *   tlb_invalidate(pde_t *pgdir, uintptr_t la) : 无效化 TLB 条目
     * DEFINEs:
     *   PTE_P           0x001                   // 页表项标志：Present
     */
    if (*ptep & PTE_V) {  // 如果页表项有效
        struct Page *page = pte2page(*ptep);  // 获取对应的 Page 结构
        page_ref_dec(page);  // 减少该页的引用计数
        if (page_ref(page) == 0) {  // 如果引用计数为 0
            free_page(page);  // 释放页面
        }
        *ptep = 0;  // 清除页表项
        tlb_invalidate(pgdir, la);  // 刷新 TLB
    }
}

// page_remove - 释放与线性地址 la 相关的 Page 结构，并清除相关的页表项
void page_remove(pde_t *pgdir, uintptr_t la) {
    pte_t *ptep = get_pte(pgdir, la, 0);  // 获取页表项
    if (ptep != NULL) {
        page_remove_pte(pgdir, la, ptep);  // 删除页表项映射
    }
}

// page_insert - 构建线性地址 la 到物理地址 page 的映射
// 参数:
//  pgdir: 页目录的内核虚拟基地址
//  page:  需要映射的 Page
//  la:    需要映射的线性地址
//  perm:  设置该 Page 相关页表项的权限
// 返回值: 总是返回 0
// 注意：页表发生了变化，因此需要刷新 TLB
int page_insert(pde_t *pgdir, struct Page *page, uintptr_t la, uint32_t perm) {
    // pgdir 是页表基地址(satp)，page 是物理页面，la 是虚拟地址
    pte_t *ptep = get_pte(pgdir, la, 1);  // 获取页表项，如果不存在则分配一个新的页表项
    // 如果没有成功获取到页表项
    if (ptep == NULL) {
        return -E_NO_MEM;  // 返回内存不足错误
    }
    page_ref_inc(page);  // 指向这个物理页面的虚拟地址引用计数加 1
    if (*ptep & PTE_V) {  // 如果原先已经有映射
        struct Page *p = pte2page(*ptep);  // 获取原来映射到的物理页面
        if (p == page) {  // 如果映射到的页面是同一个页面
            page_ref_dec(page);  // 减少该物理页面的引用计数
        } else {  // 如果映射到的是不同的页面
            page_remove_pte(pgdir, la, ptep);  // 删除原来的映射
        }
    }
    *ptep = pte_create(page2ppn(page), PTE_V | perm);  // 创建新的页表项并更新
    tlb_invalidate(pgdir, la);  // 刷新 TLB
    return 0;  // 返回 0 表示成功
}



// invalidate a TLB entry, but only if the page tables being
// edited are the ones currently in use by the processor.
// 使 TLB 条目失效，但仅当被编辑的页表是当前处理器正在使用的页表时
void tlb_invalidate(pde_t *pgdir, uintptr_t la) { flush_tlb(); }  // 刷新 TLB，flush_tlb在pmm.h中定义


// pgdir_alloc_page - 调用 alloc_page 和 page_insert 函数来分配一页物理内存并设置地址映射
//                   - 通过线性地址 la 和页目录 pgdir 建立物理地址和线性地址的映射
struct Page *pgdir_alloc_page(pde_t *pgdir, uintptr_t la, uint32_t perm) {
    struct Page *page = alloc_page();  // 分配一页物理内存
    if (page != NULL) {  // 如果分配成功
        if (page_insert(pgdir, page, la, perm) != 0) {  // 如果映射失败
            free_page(page);  // 释放分配的页
            return NULL;  // 返回 NULL
        }
        if (swap_init_ok) {  // 如果交换区初始化成功
            swap_map_swappable(check_mm_struct, la, page, 0);  // 将页面标记为可交换
            page->pra_vaddr = la;  // 设置页面的虚拟地址
            assert(page_ref(page) == 1);  // 确保页面引用计数为 1
            // cprintf("get No. %d  page: pra_vaddr %x, pra_link.prev %x,
            // pra_link_next %x in pgdir_alloc_page\n", (page-pages),
            // page->pra_vaddr,page->pra_page_link.prev,
            // page->pra_page_link.next);
        }
    }

    return page;  // 返回分配的页面
}

// 检查内存分配情况
static void check_alloc_page(void) {
    pmm_manager->check();  // 检查物理内存管理器状态
    cprintf("check_alloc_page() succeeded!\n");  // 打印检查成功的消息
}

// 检查页目录
static void check_pgdir(void) {
    // assert(npage <= KMEMSIZE / PGSIZE);
    // 由于内存从 2GB 开始，因此 npage 总是大于 KMEMSIZE / PGSIZE
    size_t nr_free_store;

    nr_free_store = nr_free_pages();  // 获取空闲页数量

    assert(npage <= KERNTOP / PGSIZE);  // 确保页数不超过内核顶端
    // boot_pgdir 是页表的虚拟地址
    assert(boot_pgdir != NULL && (uint32_t)PGOFF(boot_pgdir) == 0);  // 确保页表正确
    assert(get_page(boot_pgdir, 0x0, NULL) == NULL);  // 确保虚拟地址 0x0 没有映射

    struct Page *p1, *p2;
    p1 = alloc_page();  // 获取一个物理页面
    assert(page_insert(boot_pgdir, p1, 0x0, 0) == 0);  // 将物理页面插入页目录
    pte_t *ptep;
    assert((ptep = get_pte(boot_pgdir, 0x0, 0)) != NULL);  // 获取虚拟地址 0x0 对应的页表项
    assert(pte2page(*ptep) == p1);  // 确保页表项映射正确
    assert(page_ref(p1) == 1);  // 确保页面引用计数为 1

    ptep = (pte_t *)KADDR(PDE_ADDR(boot_pgdir[0]));  // 获取页目录的第一个页表项
    ptep = (pte_t *)KADDR(PDE_ADDR(ptep[0])) + 1;  // 获取下一级页表项
    assert(get_pte(boot_pgdir, PGSIZE, 0) == ptep);  // 检查 get_pte 是否正确工作

    p2 = alloc_page();  // 获取第二个物理页面
    assert(page_insert(boot_pgdir, p2, PGSIZE, PTE_U | PTE_W) == 0);  // 插入第二个页面并设置权限
    assert((ptep = get_pte(boot_pgdir, PGSIZE, 0)) != NULL);  // 获取虚拟地址 PGSIZE 对应的页表项
    assert(*ptep & PTE_U);  // 确保权限位设置正确
    assert(*ptep & PTE_W);  // 确保权限位设置正确
    assert(boot_pgdir[0] & PTE_U);  // 确保页目录项的权限位设置正确
    assert(page_ref(p2) == 1);  // 确保页面引用计数为 1

    assert(page_insert(boot_pgdir, p1, PGSIZE, 0) == 0);  // 插入 p1 页面并更新映射
    assert(page_ref(p1) == 2);  // 确保页面引用计数增加
    assert(page_ref(p2) == 0);  // 确保 p2 页面引用计数为 0
    assert((ptep = get_pte(boot_pgdir, PGSIZE, 0)) != NULL);  // 获取虚拟地址 PGSIZE 对应的页表项
    assert(pte2page(*ptep) == p1);  // 确保映射指向 p1 页面
    assert((*ptep & PTE_U) == 0);  // 确保权限位正确（不应该是用户权限）

    page_remove(boot_pgdir, 0x0);  // 移除虚拟地址 0x0 对应的映射
    assert(page_ref(p1) == 1);  // 确保 p1 页面引用计数减少
    assert(page_ref(p2) == 0);  // 确保 p2 页面引用计数为 0

    page_remove(boot_pgdir, PGSIZE);  // 移除虚拟地址 PGSIZE 对应的映射
    assert(page_ref(p1) == 0);  // 确保 p1 页面引用计数为 0
    assert(page_ref(p2) == 0);  // 确保 p2 页面引用计数为 0

    assert(page_ref(pde2page(boot_pgdir[0])) == 1);  // 确保页目录项的页面引用计数为 1

    pde_t *pd1 = boot_pgdir, *pd0 = page2kva(pde2page(boot_pgdir[0]));
    free_page(pde2page(pd0[0]));  // 释放页目录项的页面
    free_page(pde2page(pd1[0]));  // 释放页目录项的页面
    boot_pgdir[0] = 0;  // 清除测试痕迹

    assert(nr_free_store == nr_free_pages());  // 确保没有内存泄漏

    cprintf("check_pgdir() succeeded!\n");  // 打印检查成功的消息
}

// 检查 boot_pgdir（启动页表）
static void check_boot_pgdir(void) {
    size_t nr_free_store;
    pte_t *ptep;
    int i;

    nr_free_store = nr_free_pages();  // 获取空闲页数量

    for (i = ROUNDDOWN(KERNBASE, PGSIZE); i < npage * PGSIZE; i += PGSIZE) {
        assert((ptep = get_pte(boot_pgdir, (uintptr_t)KADDR(i), 0)) != NULL);  // 确保每个虚拟地址都有页表项
        assert(PTE_ADDR(*ptep) == i);  // 确保页表项地址正确
    }

    assert(boot_pgdir[0] == 0);  // 确保页目录的第一个条目为空

    struct Page *p;
    p = alloc_page();  // 获取一个新的物理页面
    assert(page_insert(boot_pgdir, p, 0x100, PTE_W | PTE_R) == 0);  // 插入新页面并设置权限
    assert(page_ref(p) == 1);  // 确保页面引用计数为 1
    assert(page_insert(boot_pgdir, p, 0x100 + PGSIZE, PTE_W | PTE_R) == 0);  // 插入页表并更新映射
    assert(page_ref(p) == 2);  // 确保页面引用计数为 2

    const char *str = "ucore: Hello world!!";
    strcpy((void *)0x100, str);  // 在虚拟地址 0x100 写入字符串
    assert(strcmp((void *)0x100, (void *)(0x100 + PGSIZE)) == 0);  // 确保两个地址的字符串相同

    *(char *)(page2kva(p) + 0x100) = '\0';  // 修改页面内容
    assert(strlen((const char *)0x100) == 0);  // 确保字符串长度为 0

    pde_t *pd1 = boot_pgdir, *pd0 = page2kva(pde2page(boot_pgdir[0]));
    free_page(p);  // 释放物理页面
    free_page(pde2page(pd0[0]));  // 释放页目录项
    free_page(pde2page(pd1[0]));  // 释放页目录项
    boot_pgdir[0] = 0;  // 清除测试痕迹

    assert(nr_free_store == nr_free_pages());  // 确保没有内存泄漏

    cprintf("check_boot_pgdir() succeeded!\n");  // 打印检查成功的消息
}

// 分配至少 n 字节的连续内存，返回指向该内存区域的指针
void *kmalloc(size_t n) {  
    void *ptr = NULL;
    struct Page *base = NULL;
    assert(n > 0 && n < 1024 * 0124);  // 确保 n 合理
    int num_pages = (n + PGSIZE - 1) / PGSIZE;  // 向上取整，计算需要多少页
    base = alloc_pages(num_pages);  // 分配页面
    assert(base != NULL);  // 如果分配失败则 panic
    ptr = page2kva(base);  // 获取内存区域的虚拟地址
    // page2kva 是将页面结构转化为内核虚拟地址
    return ptr;  // 返回指向分配内存的指针
}

// 释放指定的内存块
void kfree(void *ptr, size_t n) {
    assert(n > 0 && n < 1024 * 0124);  // 确保 n 合理
    assert(ptr != NULL);  // 确保指针不为空
    struct Page *base = NULL;
    int num_pages = (n + PGSIZE - 1) / PGSIZE;  // 计算需要释放的页数
    base = kva2page(ptr);  // 将虚拟地址转换为页面结构
    free_pages(base, num_pages);  // 释放页面
}
