#include <vmm.h>
#include <sync.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <error.h>
#include <pmm.h>
#include <riscv.h>
#include <swap.h>

/* 
  vmm设计包含两个部分：mm_struct（mm）和vma_struct（vma）
  mm是一个内存管理器，负责管理一组具有相同页目录表(PDT)的连续虚拟内存区域。
  vma是一个连续的虚拟内存区域。
  mm中有一个线性链表用于存储vma，也有一个红黑树链表用于管理vma。
---------------
  mm相关的函数：
   全局函数
     struct mm_struct * mm_create(void)   // 创建一个新的mm_struct结构体
     void mm_destroy(struct mm_struct *mm)  // 销毁一个mm_struct结构体
     int do_pgfault(struct mm_struct *mm, uint_t error_code, uintptr_t addr)  // 处理页面错误
--------------
  vma相关的函数：
   全局函数
     struct vma_struct * vma_create (uintptr_t vm_start, uintptr_t vm_end, ...)  // 创建一个新的vma结构体
     void insert_vma_struct(struct mm_struct *mm, struct vma_struct *vma)  // 将vma结构体插入mm
     struct vma_struct * find_vma(struct mm_struct *mm, uintptr_t addr)  // 查找与指定地址对应的vma
   本地函数
     inline void check_vma_overlap(struct vma_struct *prev, struct vma_struct *next)  // 检查vma之间的重叠
---------------
   正确性检查函数
     void check_vmm(void);  // 检查虚拟内存管理的正确性
     void check_vma_struct(void);  // 检查vma结构体的正确性
     void check_pgfault(void);  // 检查页面错误处理的正确性
*/

// szx func : print_vma and print_mm
void print_vma(char *name, struct vma_struct *vma){
    cprintf("-- %s print_vma --\n", name); // 打印出vma的相关信息，name是函数的名字
    cprintf("   mm_struct: %p\n",vma->vm_mm); // 打印vma所对应的mm_struct指针
    cprintf("   vm_start,vm_end: %x,%x\n",vma->vm_start,vma->vm_end); // 打印vma的虚拟内存区域的起始地址和结束地址
    cprintf("   vm_flags: %x\n",vma->vm_flags); // 打印vma的标志字段
    cprintf("   list_entry_t: %p\n",&vma->list_link); // 打印vma的链表指针
}

void print_mm(char *name, struct mm_struct *mm){
    cprintf("-- %s print_mm --\n",name); // 打印mm_struct的相关信息，name是函数的名字
    cprintf("   mmap_list: %p\n",&mm->mmap_list); // 打印mm_struct中的mmap_list链表的指针
    cprintf("   map_count: %d\n",mm->map_count); // 打印mm_struct中的map_count字段，表示vma的数量
    list_entry_t *list = &mm->mmap_list; // 初始化链表指针
    for(int i=0;i<mm->map_count;i++){ // 遍历所有vma
        list = list_next(list); // 获取下一个vma
        print_vma(name, le2vma(list,list_link)); // 打印当前vma的信息
    }
}

static void check_vmm(void); // 声明检查虚拟内存管理的函数
static void check_vma_struct(void); // 声明检查vma结构体的函数
static void check_pgfault(void); // 声明检查页面错误的函数



// mm_create - 申请一个mm_struct并初始化它
struct mm_struct *
mm_create(void) {
    struct mm_struct *mm = kmalloc(sizeof(struct mm_struct)); // 申请一个mm_struct结构体的内存

    if (mm != NULL) { // 如果内存分配成功
        list_init(&(mm->mmap_list)); // 初始化mmap_list链表，存储vma结构体
        mm->mmap_cache = NULL; // 初始化mmap_cache为空，表示当前没有被缓存的vma
        mm->pgdir = NULL; // 初始化页表指针为空
        mm->map_count = 0; // 初始化vma数量为0

        if (swap_init_ok) swap_init_mm(mm); // 如果页面置换初始化成功，初始化页面置换相关内容
        else mm->sm_priv = NULL; // 否则，将页面置换相关的私有数据置为NULL
    }
    return mm; // 返回申请并初始化后的mm_struct指针
}

// vma_create - 申请一个vma_struct并初始化它（地址范围：vm_start~vm_end）
struct vma_struct *
vma_create(uintptr_t vm_start, uintptr_t vm_end, uint_t vm_flags) {
    struct vma_struct *vma = kmalloc(sizeof(struct vma_struct)); // 申请一个vma_struct结构体的内存

    if (vma != NULL) { // 如果内存分配成功
        vma->vm_start = vm_start; // 设置vma的起始地址
        vma->vm_end = vm_end; // 设置vma的结束地址
        vma->vm_flags = vm_flags; // 设置vma的标志
    }
    return vma; // 返回申请并初始化后的vma_struct指针
}



// find_vma - 查找一个vma  (vma->vm_start <= addr <= vma_vm_end)
// 如果返回NULL，说明查询的虚拟地址不存在/不合法，既不对应内存里的某个页，也不对应硬盘里某个可以换进来的页
struct vma_struct *
find_vma(struct mm_struct *mm, uintptr_t addr) {
    struct vma_struct *vma = NULL;
    if (mm != NULL) { // 如果mm结构体不为空
        vma = mm->mmap_cache; // 首先检查缓存中的vma
        if (!(vma != NULL && vma->vm_start <= addr && vma->vm_end > addr)) { // 如果缓存vma不合适（不包含addr）
            bool found = 0; // 设置找到标志
            list_entry_t *list = &(mm->mmap_list), *le = list;
            while ((le = list_next(le)) != list) { // 遍历mmap_list中的vma
                vma = le2vma(le, list_link); // 获取vma
                if (vma->vm_start <= addr && addr < vma->vm_end) { // 如果地址在vma的范围内
                    found = 1; // 标记为找到
                    break; // 跳出循环
                }
            }
            if (!found) { // 如果没有找到
                vma = NULL; // 设置vma为NULL
            }
        }
        if (vma != NULL) { // 如果找到了vma
            mm->mmap_cache = vma; // 更新缓存
        }
    }
    return vma; // 返回vma，如果未找到则为NULL
}

// check_vma_overlap - 检查vma1是否与vma2重叠？
// 插入一个新的vma_struct之前，我们要保证它和原有的区间都不重合
static inline void
check_vma_overlap(struct vma_struct *prev, struct vma_struct *next) {
    assert(prev->vm_start < prev->vm_end); // 确保prev的区间合法
    assert(prev->vm_end <= next->vm_start); // 确保prev和next不重叠
    assert(next->vm_start < next->vm_end); // 确保next的区间合法，顺便验证start < end
}

// insert_vma_struct - 将vma插入到mm的链表中
void
insert_vma_struct(struct mm_struct *mm, struct vma_struct *vma) {
    assert(vma->vm_start < vma->vm_end); // 确保vma的区间合法
    list_entry_t *list = &(mm->mmap_list); // 获取mm的vma链表
    list_entry_t *le_prev = list, *le_next;

    list_entry_t *le = list;
    while ((le = list_next(le)) != list) { // 遍历链表
        struct vma_struct *mmap_prev = le2vma(le, list_link); // 获取前一个vma
        if (mmap_prev->vm_start > vma->vm_start) { // 找到插入点
            break;
        }
        le_prev = le; // 更新前一个节点
    }
    // 保证插入后所有vma_struct按照区间左端点有序排列
    le_next = list_next(le_prev); // 获取下一个节点

    /* 检查重叠 */
    if (le_prev != list) { // 如果前一个节点不是头节点
        check_vma_overlap(le2vma(le_prev, list_link), vma); // 检查前一个vma与当前vma的重叠
    }
    if (le_next != list) { // 如果下一个节点不是头节点
        check_vma_overlap(vma, le2vma(le_next, list_link)); // 检查当前vma与下一个vma的重叠
    }

    vma->vm_mm = mm; // 设置vma所属的mm
    list_add_after(le_prev, &(vma->list_link)); // 将vma插入链表中

    mm->map_count++; // 增加vma计数器
}

// mm_destroy - 释放mm及其内部字段
void
mm_destroy(struct mm_struct *mm) {

    list_entry_t *list = &(mm->mmap_list), *le;
    while ((le = list_next(list)) != list) { // 遍历mm的vma链表
        list_del(le); // 删除当前vma节点
        kfree(le2vma(le, list_link), sizeof(struct vma_struct));  // 释放vma
    }
    kfree(mm, sizeof(struct mm_struct)); // 释放mm
    mm = NULL; // 将mm指针置为空
}

// vmm_init - 初始化虚拟内存管理
//          - 当前只是调用check_vmm检查vmm的正确性
void
vmm_init(void) {
    check_vmm(); // 检查虚拟内存管理的正确性
}

// check_vmm - 检查vmm的正确性
static void
check_vmm(void) {
    size_t nr_free_pages_store = nr_free_pages(); // 获取当前空闲页面数量
    check_vma_struct(); // 检查vma结构体
    check_pgfault(); // 检查页故障处理

    nr_free_pages_store--; // szx：Sv39三级页表多占一个内存页，所以执行此操作
    assert(nr_free_pages_store == nr_free_pages()); // 确保空闲页面数量正确

    cprintf("check_vmm() succeeded.\n"); // 打印检查成功信息
}

// check_vma_struct - 检查vma结构体的正确性
static void
check_vma_struct(void) {
    size_t nr_free_pages_store = nr_free_pages(); // 保存初始的空闲页面数量

    struct mm_struct *mm = mm_create(); // 创建一个mm_struct
    assert(mm != NULL); // 确保mm结构体成功创建

    int step1 = 10, step2 = step1 * 10; // 定义两个步长，用于控制插入的vma个数

    int i;
    for (i = step1; i >= 1; i --) { // 从step1开始插入vma，插入10个
        struct vma_struct *vma = vma_create(i * 5, i * 5 + 2, 0); // 创建一个vma
        assert(vma != NULL); // 确保vma创建成功
        insert_vma_struct(mm, vma); // 插入vma到mm结构体的链表中
    }

    for (i = step1 + 1; i <= step2; i ++) { // 从step1+1到step2插入vma，插入100个
        struct vma_struct *vma = vma_create(i * 5, i * 5 + 2, 0); // 创建一个vma
        assert(vma != NULL); // 确保vma创建成功
        insert_vma_struct(mm, vma); // 插入vma到mm结构体的链表中
    }

    list_entry_t *le = list_next(&(mm->mmap_list)); // 获取链表的第一个元素

    for (i = 1; i <= step2; i ++) { // 遍历插入的所有vma
        assert(le != &(mm->mmap_list)); // 确保当前节点不为链表头
        struct vma_struct *mmap = le2vma(le, list_link); // 获取vma结构体
        assert(mmap->vm_start == i * 5 && mmap->vm_end == i * 5 + 2); // 验证vma的起始和结束地址是否正确
        le = list_next(le); // 移动到下一个vma
    }

    for (i = 5; i <= 5 * step2; i += 5) { // 访问每个5的倍数地址，验证find_vma的正确性
        struct vma_struct *vma1 = find_vma(mm, i); // 查找vma1
        assert(vma1 != NULL); // 确保找到vma1
        struct vma_struct *vma2 = find_vma(mm, i + 1); // 查找vma2
        assert(vma2 != NULL); // 确保找到vma2
        struct vma_struct *vma3 = find_vma(mm, i + 2); // 查找vma3
        assert(vma3 == NULL); // 确保没有找到vma3（越界）
        struct vma_struct *vma4 = find_vma(mm, i + 3); // 查找vma4
        assert(vma4 == NULL); // 确保没有找到vma4（越界）
        struct vma_struct *vma5 = find_vma(mm, i + 4); // 查找vma5
        assert(vma5 == NULL); // 确保没有找到vma5（越界）

        assert(vma1->vm_start == i && vma1->vm_end == i + 2); // 确保vma1的区间正确
        assert(vma2->vm_start == i && vma2->vm_end == i + 2); // 确保vma2的区间正确
    }

    for (i = 4; i >= 0; i--) { // 检查小于5的虚拟地址
        struct vma_struct *vma_below_5 = find_vma(mm, i); // 查找虚拟地址i的vma
        if (vma_below_5 != NULL) { // 如果找到了vma
            cprintf("vma_below_5: i %x, start %x, end %x\n", i, vma_below_5->vm_start, vma_below_5->vm_end); // 打印信息
        }
        assert(vma_below_5 == NULL); // 确保没有找到小于5的vma
    }

    mm_destroy(mm); // 销毁mm结构体

    assert(nr_free_pages_store == nr_free_pages()); // 检查空闲页面数量是否正确

    cprintf("check_vma_struct() succeeded!\n"); // 打印成功信息
}

// check_pgfault - 检查页故障处理程序的正确性
static void
check_pgfault(void) {
    size_t nr_free_pages_store = nr_free_pages(); // 保存初始的空闲页面数量

    check_mm_struct = mm_create(); // 创建一个mm_struct并赋值给全局变量check_mm_struct

    assert(check_mm_struct != NULL); // 确保mm结构体创建成功
    struct mm_struct *mm = check_mm_struct; // 获取mm结构体
    pde_t *pgdir = mm->pgdir = boot_pgdir; // 设置页目录指针，初始化为boot_pgdir
    assert(pgdir[0] == 0); // 确保页目录的第一个项为0

    struct vma_struct *vma = vma_create(0, PTSIZE, VM_WRITE); // 创建一个vma结构体，表示可以写入的虚拟内存区间

    assert(vma != NULL); // 确保vma创建成功

    insert_vma_struct(mm, vma); // 将vma插入到mm的vma链表中

    uintptr_t addr = 0x100; // 设置测试地址
    assert(find_vma(mm, addr) == vma); // 确保该地址所在的vma是我们插入的vma

    int i, sum = 0;
    for (i = 0; i < 100; i ++) { // 写入100个字节到指定地址
        *(char *)(addr + i) = i;
        sum += i;
    }
    for (i = 0; i < 100; i ++) { // 读取并检查写入的数据
        sum -= *(char *)(addr + i);
    }
    assert(sum == 0); // 确保sum为0，表示所有数据都正确读写

    page_remove(pgdir, ROUNDDOWN(addr, PGSIZE)); // 移除指定地址的页

    free_page(pde2page(pgdir[0])); // 释放页目录中第一个页表项

    pgdir[0] = 0; // 将页目录的第一个项设置为0

    mm->pgdir = NULL; // 将mm结构体的pgdir置为空
    mm_destroy(mm); // 销毁mm结构体

    check_mm_struct = NULL; // 将check_mm_struct置为空
    nr_free_pages_store--; // 因为Sv39第二级页表多占用一个内存页，减去一个页

    assert(nr_free_pages_store == nr_free_pages()); // 检查空闲页面数量是否正确

    cprintf("check_pgfault() succeeded!\n"); // 打印成功信息
}


volatile unsigned int pgfault_num = 0;

/* do_pgfault - 处理页故障的中断处理程序——即缺页异常
 * @mm         : 对应一个虚拟内存区域的控制结构，多个vma共享同一个PDT
 * @error_code : 错误码，记录在trapframe->tf_err，由x86硬件设置
 * @addr       : 导致内存访问异常的地址（来自CR2寄存器）
 *
 * CALL GRAPH: trap--> trap_dispatch-->pgfault_handler-->do_pgfault
 * 处理器提供给ucore的do_pgfault函数两项信息来帮助诊断和恢复异常：
 *   (1) CR2寄存器的内容。处理器将产生异常的32位线性地址加载到CR2寄存器。do_pgfault函数可以利用这个地址来查找对应的页目录和页表项。
 *   (2) 错误码。页故障的错误码格式与其他异常不同，错误码告诉异常处理程序以下三件事：
 *         -- P标志位（bit 0）指示异常是由于页面缺失（0）还是由于访问权限违规或使用保留位（1）引起的。
 *         -- W/R标志位（bit 1）指示导致异常的内存访问是读取（0）还是写入（1）。
 *         -- U/S标志位（bit 2）指示异常发生时处理器是处于用户模式（1）还是内核模式（0）。
 */
int
do_pgfault(struct mm_struct *mm, uint_t error_code, uintptr_t addr) {
    // addr: 访问出错的虚拟地址
    int ret = -E_INVAL; // 默认返回值为无效地址错误
    // 尝试找到包含该地址的vma结构，即判断访问出错的虚拟地址是否在该页表的合法虚拟地址集合
    //（所有可用的虚拟地址/虚拟页的集合，不论当前这个虚拟地址对应的页在内存上还是在硬盘上）里。
    struct vma_struct *vma = find_vma(mm, addr);//就在本文件中定义
    // 如果没有找到vma或者地址不在vma的范围内，表示地址无效
    pgfault_num++; // 页故障次数加一
    // 如果addr不在某个vma的范围内，说明地址不可用
    if (vma == NULL || vma->vm_start > addr) {
        cprintf("not valid addr %x, and  can not find it in vma\n", addr); // 打印出错信息
        goto failed; // 跳到失败处理
    }

    /* 如果是写操作或者：
     * 1. 写入一个不存在的地址且该地址是可写的，或者
     * 2. 读取一个不存在的地址且该地址是可读的
     * 那么就继续处理
     */
    uint32_t perm = PTE_U; // 默认权限为用户可访问
    if (vma->vm_flags & VM_WRITE) { // 如果vma是可写的
        perm |= (PTE_R | PTE_W); // 设置为可读写权限
    }
    addr = ROUNDDOWN(addr, PGSIZE); // 将地址对齐到页面边界，ROUNDDOWN定义在defs.h中

    ret = -E_NO_MEM; // 默认返回值为内存不足

    pte_t *ptep = NULL; // 用于存储页表项的指针
    /*
    * 以下是一些有用的宏和定义，可以帮助你完成代码：
    * 宏和函数：
    *   get_pte : 获取一个pte，并返回该pte的内核虚拟地址，如果页表项不存在，则分配一个页表。
    *   pgdir_alloc_page : 分配一个物理页面，并通过page_insert函数将该页与线性地址关联。
    * 定义：
    *   VM_WRITE  : 如果vma->vm_flags & VM_WRITE == 1/0，则vma为可写/不可写。
    *   PTE_W           0x002                   // 页表项标志位：可写
    *   PTE_U           0x004                   // 页表项标志位：用户可访问
    * 变量：
    *   mm->pgdir : 对应vma的页目录。
    */

    ptep = get_pte(mm->pgdir, addr, 1);  // (1) 尝试获取该地址对应的页表项，如果该页表不存在则创建新页表，get_pte在pmm.c中定义
    if (*ptep == 0) { // 如果页表项为空，说明是刚刚创建的页表项，之前不存在该va和pa的映射关系，表示没有对应的物理页面
        if (pgdir_alloc_page(mm->pgdir, addr, perm) == NULL) { // 分配新的页并更新页表
            cprintf("pgdir_alloc_page in do_pgfault failed\n"); // 分配失败时打印错误信息
            goto failed; // 跳到失败处理
        }
    } else {
        /* LAB3 EXERCISE 3: YOUR CODE
        * 如果页表项存在，且我们认为该页是一个交换条目，那么需要从磁盘加载数据并将其放到物理内存中，
        * 并将该页面的物理地址与逻辑地址建立映射。
        * 以下是一些有用的宏和定义：
        *  宏或函数：
        *    swap_in(mm, addr, &page) : 从磁盘加载数据到物理页面中。
        *    page_insert ： 将物理页面的地址与逻辑地址建立映射。
        *    swap_map_swappable ： 设置页面为可交换。
        */
        if (swap_init_ok) { // 如果已初始化交换功能
            struct Page *page = NULL; // 声明一个物理页面指针

            // 在swap_in函数执行完后，page保存从磁盘加载的物理页面。
            // swap_in可能会将内存中已有的页面交换出去。
            swap_in(mm, addr, &page);  // (1) 根据mm和addr加载对应的磁盘页面到内存中
            page_insert(mm->pgdir, page, addr, perm); // 更新页表，将物理页面与线性地址映射
            //在pmm.c中定义，根据换入的页面和va，建立映射，插入新的页表项，会刷新TLB。
            //(2) 根据mm、addr和page设置物理地址和虚拟地址的映射
            swap_map_swappable(mm, addr, page, 1);  // (3) 设置该页面为可交换状态,把换入的页面加入到FIFO的交换页队列中
            page->pra_vaddr = addr; // 记录页面的虚拟地址
        } else {
            cprintf("no swap_init_ok but ptep is %x, failed\n", *ptep); // 如果交换未初始化，打印错误信息
            goto failed; // 跳到失败处理
        }
   }

   ret = 0; // 如果一切顺利，返回成功
failed:
    return ret; // 返回结果
}
