#ifndef __KERN_MM_MMU_H__  // 如果未定义 __KERN_MM_MMU_H__，则定义它，避免重复包含头文件
#define __KERN_MM_MMU_H__  // 定义头文件宏，避免多次包含

#ifndef __ASSEMBLER__  // 如果不是汇编代码
#include <defs.h>  // 引入 defs.h 头文件，可能包含数据类型等定义
#endif /* !__ASSEMBLER__ */  // 汇编代码段结束

// A linear address 'la' has a four-part structure as follows:
// 线性地址 'la' 的四部分结构如下：

// +--------9-------+-------9--------+-------9--------+---------12----------+
// | Page Directory | Page Directory |   Page Table   | Offset within Page  |
// |     Index 1    |    Index 2     |                |                     |
// +----------------+----------------+----------------+---------------------+
//  \-- PDX1(la) --/ \-- PDX0(la) --/ \--- PTX(la) --/ \---- PGOFF(la) ----/
//  \-------------------PPN(la)----------------------/
//  页面目录索引1   页面目录索引2   页表索引   页内偏移

// The PDX1, PDX0, PTX, PGOFF, and PPN macros decompose linear addresses as shown.
// PDX1, PDX0, PTX, PGOFF 和 PPN 宏将线性地址分解成对应的部分。

// To construct a linear address la from PDX(la), PTX(la), and PGOFF(la),
// use PGADDR(PDX(la), PTX(la), PGOFF(la)).
// 使用 PGADDR(PDX(la), PTX(la), PGOFF(la)) 从 PDX(la), PTX(la) 和 PGOFF(la) 构造线性地址 la。

// RISC-V uses 39-bit virtual address to access 56-bit physical address!
// Sv39 virtual address:
// RISC-V 使用 39 位虚拟地址来访问 56 位物理地址！Sv39 虚拟地址结构：

// +----9----+----9---+----9---+---12--+
// |  VPN[2] | VPN[1] | VPN[0] | PGOFF |
// +---------+----+---+--------+-------+
// Sv39 虚拟地址：
// +---------+----+---+--------+-------+
// | VPN[2]  | VPN[1] | VPN[0] | PGOFF |
// +---------+----+---+--------+-------+

// Sv39 physical address:
// Sv39 物理地址：

// +----26---+----9---+----9---+---12--+
// |  PPN[2] | PPN[1] | PPN[0] | PGOFF |
// +---------+----+---+--------+-------+
// Sv39 物理地址结构：

// Sv39 page table entry:
// Sv39 页表项结构：

// +----26---+----9---+----9---+---2----+-------8-------+
// |  PPN[2] | PPN[1] | PPN[0] |Reserved|D|A|G|U|X|W|R|V|
// +---------+----+---+--------+--------+---------------+
// 页表项结构：PPN部分和标志位

// page directory index
#define PDX1(la) ((((uintptr_t)(la)) >> PDX1SHIFT) & 0x1FF)  // 获取页目录索引1部分，右移 PDX1SHIFT 位后与 0x1FF (9 位掩码) 进行与操作
#define PDX0(la) ((((uintptr_t)(la)) >> PDX0SHIFT) & 0x1FF)  // 获取页目录索引2部分，右移 PDX0SHIFT 位后与 0x1FF 进行与操作

// page table index
#define PTX(la) ((((uintptr_t)(la)) >> PTXSHIFT) & 0x1FF)  // 获取页表索引部分，右移 PTXSHIFT 位后与 0x1FF 进行与操作

// page number field of address
#define PPN(la) (((uintptr_t)(la)) >> PTXSHIFT)  // 获取页号部分，右移 PTXSHIFT 位后得到页号

// offset in page
#define PGOFF(la) (((uintptr_t)(la)) & 0xFFF)  // 获取页内偏移量，取最低 12 位

// construct linear address from indexes and offset
#define PGADDR(d1, d0, t, o) ((uintptr_t)((d1) << PDX1SHIFT | (d0) << PDX0SHIFT | (t) << PTXSHIFT | (o)))  // 从索引和偏移量构造线性地址，使用左移和按位或

// address in page table or page directory entry
#define PTE_ADDR(pte)   (((uintptr_t)(pte) & ~0x3FF) << (PTXSHIFT - PTE_PPN_SHIFT))  // 获取页表项地址，清除低 10 位后左移一定位数
#define PDE_ADDR(pde)   PTE_ADDR(pde)  // 页目录项地址与页表项地址相同，使用同样的宏

/* page directory and page table constants */
#define NPDEENTRY       512  // 每个页目录有 512 个条目
#define NPTEENTRY       512  // 每个页表有 512 个条目

#define PGSIZE          4096  // 每页的字节数，通常为 4KB
#define PGSHIFT         12    // PGSIZE 的对数（log2(4096) = 12）

#define PTSIZE          (PGSIZE * NPTEENTRY)  // 页表项的字节数，页表项数 * 每页大小
#define PTSHIFT         21    // PTSIZE 的对数（log2(PTSIZE)）

#define PTXSHIFT        12    // PTX 在地址中的偏移量
#define PDX0SHIFT       21    // PDX0 在地址中的偏移量
#define PDX1SHIFT       30    // PDX1 在地址中的偏移量
#define PTE_PPN_SHIFT   10    // 页表项中 PPN 的偏移量

// page table entry (PTE) fields
#define PTE_V     0x001  // PTE 的有效位，表示页表项是否有效
#define PTE_R     0x002  // 可读权限位
#define PTE_W     0x004  // 可写权限位
#define PTE_X     0x008  // 可执行权限位
#define PTE_U     0x010  // 用户权限位
#define PTE_G     0x020  // 全局位
#define PTE_A     0x040  // 访问位，表示页表项是否被访问过
#define PTE_D     0x080  // 脏位，表示页表项是否被写入
#define PTE_SOFT  0x300  // 软件保留位，用于特定的标记或功能

#define PAGE_TABLE_DIR (PTE_V)  // 表示页目录条目的有效标志
#define READ_ONLY (PTE_R | PTE_V)  // 只读权限标志
#define READ_WRITE (PTE_R | PTE_W | PTE_V)  // 可读写权限标志
#define EXEC_ONLY (PTE_X | PTE_V)  // 仅执行权限标志
#define READ_EXEC (PTE_R | PTE_X | PTE_V)  // 读/执行权限标志
#define READ_WRITE_EXEC (PTE_R | PTE_W | PTE_X | PTE_V)  // 读/写/执行权限标志

#define PTE_USER (PTE_R | PTE_W | PTE_X | PTE_U | PTE_V)  // 用户级权限标志，支持读写执行，并且有效位为 1

#endif /* !__KERN_MM_MMU_H__ */  // 结束宏定义，防止多次包含
