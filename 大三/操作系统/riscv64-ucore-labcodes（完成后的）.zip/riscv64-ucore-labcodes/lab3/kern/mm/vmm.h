#ifndef __KERN_MM_VMM_H__    // 如果没有定义 __KERN_MM_VMM_H__，则开始包含此头文件
#define __KERN_MM_VMM_H__

#include <defs.h>            // 包含定义相关的头文件
#include <list.h>            // 包含链表操作相关的头文件
#include <memlayout.h>       // 包含内存布局相关的头文件
#include <sync.h>            // 包含同步相关的头文件


// 预定义
struct mm_struct;           // mm_struct 结构体前置声明


//虚拟内存区域(VMA)，每个vma代表了虚拟内存空间中的一个区域，它具有一组属性和访问权限
// 虚拟连续内存区域(vma)，[vm_start, vm_end)，
// 地址属于某个 vma 意味着 vma.vm_start <= addr < vma.vm_end
struct vma_struct {
    struct mm_struct *vm_mm; // 使用相同页目录表(PDT)的一组vma
    uintptr_t vm_start;      // vma的起始地址
    uintptr_t vm_end;        // vma的结束地址，vm_end本身不包含在内
    uint_t vm_flags;         // vma的标志位
    list_entry_t list_link;  // 按照vma的起始地址排序的线性链表链接
};

#define le2vma(le, member)                  \
    to_struct((le), struct vma_struct, member)  // 将链表项(le)转换为 vma_struct 结构体

#define VM_READ                 0x00000001  // 读取权限标志
#define VM_WRITE                0x00000002  // 写入权限标志
#define VM_EXEC                 0x00000004  // 执行权限标志


//内存管理结构(mm_struct)，是一个内存管理结构，包含了一个进程或线程的虚拟内存映射信息。
// 使用相同PDT的一组vma的控制结构
struct mm_struct {
    list_entry_t mmap_list;        // 按照vma的起始地址排序的线性链表链接
    struct vma_struct *mmap_cache; // 当前访问的vma，用于加速访问
    pde_t *pgdir;                  // 这些vma的页目录表
    int map_count;                 // 这些vma的数量
    void *sm_priv;                 // 用于交换管理器的私有数据
};

struct vma_struct *find_vma(struct mm_struct *mm, uintptr_t addr);  // 查找与给定地址对应的vma
struct vma_struct *vma_create(uintptr_t vm_start, uintptr_t vm_end, uint_t vm_flags);  // 创建一个新的vma
void insert_vma_struct(struct mm_struct *mm, struct vma_struct *vma);  // 插入一个新的vma结构体到mm中

struct mm_struct *mm_create(void);  // 创建一个新的内存管理结构mm_struct
void mm_destroy(struct mm_struct *mm);  // 销毁一个内存管理结构mm_struct

void vmm_init(void);  // 初始化虚拟内存管理模块

int do_pgfault(struct mm_struct *mm, uint_t error_code, uintptr_t addr);  // 处理页面错误

extern volatile unsigned int pgfault_num;  // 外部定义的页面错误计数
extern struct mm_struct *check_mm_struct;  // 用于检查mm_struct的外部变量

#endif /* !__KERN_MM_VMM_H__ */  // 如果没有定义 __KERN_MM_VMM_H__，则结束包含此头文件
