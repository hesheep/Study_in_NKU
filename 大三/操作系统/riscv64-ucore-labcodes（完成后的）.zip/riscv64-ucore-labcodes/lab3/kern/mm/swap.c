#include <swap.h>  // 引入交换区相关头文件
#include <swapfs.h>  // 引入交换文件系统相关头文件
#include <swap_fifo.h>  // 引入先进先出（FIFO）页面置换算法头文件
#include <swap_clock.h>  // 引入时钟页面置换算法头文件
#include <stdio.h>  // 引入标准输入输出头文件
#include <string.h>  // 引入字符串处理头文件
#include <memlayout.h>  // 引入内存布局头文件
#include <pmm.h>  // 引入物理内存管理头文件
#include <mmu.h>  // 引入内存管理单元头文件

// 设置检查的虚拟地址范围
#define CHECK_VALID_VIR_PAGE_NUM 5  // 要检查的虚拟页面数量
#define BEING_CHECK_VALID_VADDR 0X1000  // 虚拟地址起始值
#define CHECK_VALID_VADDR (CHECK_VALID_VIR_PAGE_NUM+1)*0x1000  // 虚拟地址的结束值
// 设置检查的物理页面数量
#define CHECK_VALID_PHY_PAGE_NUM 4  // 要检查的物理页面数量
// 设置最大访问序列号
#define MAX_SEQ_NO 10  // 最大的访问序列号数量

static struct swap_manager *sm;  // 交换管理器指针
size_t max_swap_offset;  // 最大交换偏移量

volatile int swap_init_ok = 0;  // 交换初始化状态

unsigned int swap_page[CHECK_VALID_VIR_PAGE_NUM];  // 虚拟页面的数组

unsigned int swap_in_seq_no[MAX_SEQ_NO], swap_out_seq_no[MAX_SEQ_NO];  // 交换进和交换出的序列号数组

// 函数声明
static void check_swap(void);

// 初始化交换管理器
int swap_init(void)
{
     swapfs_init();  // 初始化交换文件系统

     // 因为IDE是虚拟的，它最多只能存储7个页面来通过测试
     if (!(7 <= max_swap_offset && max_swap_offset < MAX_SWAP_OFFSET_LIMIT)) {
        panic("bad max_swap_offset %08x.\n", max_swap_offset);  // 如果最大交换偏移量不在有效范围内，触发panic
     }

     sm = &swap_manager_clock;  // 使用时钟页面置换算法
     int r = sm->init();  // 初始化交换管理器
     
     if (r == 0)  // 如果初始化成功
     {
          swap_init_ok = 1;  // 标记交换初始化成功
          cprintf("SWAP: manager = %s\n", sm->name);  // 输出交换管理器名称
          check_swap();  // 检查交换机制
     }

     return r;  // 返回初始化结果
}

// 初始化内存管理结构体中的交换管理相关数据
int swap_init_mm(struct mm_struct *mm)
{
     return sm->init_mm(mm);  // 调用交换管理器的初始化函数
}

// 时钟中断事件处理
int swap_tick_event(struct mm_struct *mm)
{
     return sm->tick_event(mm);  // 调用交换管理器的时钟事件处理函数
}

// 映射可交换页面
int swap_map_swappable(struct mm_struct *mm, uintptr_t addr, struct Page *page, int swap_in)
{
     return sm->map_swappable(mm, addr, page, swap_in);  // 调用交换管理器的映射函数
}

// 设置页面为不可交换
int swap_set_unswappable(struct mm_struct *mm, uintptr_t addr)
{
     return sm->set_unswappable(mm, addr);  // 调用交换管理器的不可交换设置函数
}

volatile unsigned int swap_out_num = 0;  // 交换出去的页面数量

// 交换出页面的函数
int swap_out(struct mm_struct *mm, int n, int in_tick)
{
     int i;
     for (i = 0; i != n; ++i)  // 交换n个页面
     {
          uintptr_t v;
          struct Page *page;
          int r = sm->swap_out_victim(mm, &page, in_tick);  // 循环调用页面置换算法接口，找到要交换出去的页面，对应swap_fifo.c中的_fifo_swap_out_victim。查找队尾的页面，作为需要释放的页面。
          if (r != 0) {  // 如果没有找到可以交换出去的页面
                  cprintf("i %d, swap_out: call swap_out_victim failed\n", i);  // 输出错误信息
                  break;
          }

          cprintf("SWAP: choose victim page 0x%08x\n", page);  // 输出选择的交换页面

          v = page->pra_vaddr;  // 获取页面的虚拟地址
          pte_t *ptep = get_pte(mm->pgdir, v, 0);  // 获取页表项
          assert((*ptep & PTE_V) != 0);  // 确保页表项有效

          // 将页面内容写入交换区(硬盘)，如果失败，则继续下一轮交换
          if (swapfs_write((page->pra_vaddr / PGSIZE + 1) << 8, page) != 0) {
                      cprintf("SWAP: failed to save\n");  // 输出保存失败的信息
                      sm->map_swappable(mm, v, page, 0);  // 对应于swap_fifo.c的_fifo_map_swappable更新FIFO队列。将队尾的页面移动到队头，防止下一次换出失败。
                      continue;
          }
          else {  // 交换成功
              cprintf("swap_out: i %d, store page in vaddr 0x%x to disk swap entry %d\n", i, v, page->pra_vaddr / PGSIZE + 1);
              *ptep = (page->pra_vaddr / PGSIZE + 1) << 8;  // 更新页表项
              free_page(page);  // 释放页面，调用pmm_manager->free_pages释放页面，在pmm.c中定义
          }
          tlb_invalidate(mm->pgdir, v);  // 刷新TLB，确保页表变更生效，在pmm.c中定义
     }
     return i;  // 返回已交换的页面数量
}

// 交换进页面的函数
int swap_in(struct mm_struct *mm, uintptr_t addr, struct Page **ptr_result)
{
     struct Page *result = alloc_page();  // 分配一个新的物理页面，在pmm.c中定义，申请一块连继续的内存空间
     //在这个过程中，如果申请页面失败，那么说明需要换出页面，则调用swap_out换出页面，之后再次进行申请。

     assert(result != NULL);  // 确保分配成功

     pte_t *ptep = get_pte(mm->pgdir, addr, 0);  // 获取页表项
     int r;
     if ((r = swapfs_read((*ptep), result)) != 0)  // 从交换区读取页面数据到一个内存的物理页
     {
        assert(r != 0);  // 确保读取成功
     }
     cprintf("swap_in: load disk swap entry %d with swap_page in vadr 0x%x\n", (*ptep) >> 8, addr);  // 输出读取页面的日志
     *ptr_result = result;  // 返回读取的页面
     return 0;  // 返回成功
}

// 设置检查内容
static inline void check_content_set(void)
{
     *(unsigned char *)0x1000 = 0x0a;  // 在虚拟地址0x1000写入数据
     assert(pgfault_num == 1);  // 确保缺页中断发生一次
     *(unsigned char *)0x1010 = 0x0a;  // 在虚拟地址0x1010写入数据
     assert(pgfault_num == 1);  // 确保缺页中断发生一次
     *(unsigned char *)0x2000 = 0x0b;  // 在虚拟地址0x2000写入数据
     assert(pgfault_num == 2);  // 确保缺页中断发生两次
     *(unsigned char *)0x2010 = 0x0b;  // 在虚拟地址0x2010写入数据
     assert(pgfault_num == 2);  // 确保缺页中断发生两次
     *(unsigned char *)0x3000 = 0x0c;  // 在虚拟地址0x3000写入数据
     assert(pgfault_num == 3);  // 确保缺页中断发生三次
     *(unsigned char *)0x3010 = 0x0c;  // 在虚拟地址0x3010写入数据
     assert(pgfault_num == 3);  // 确保缺页中断发生三次
     *(unsigned char *)0x4000 = 0x0d;  // 在虚拟地址0x4000写入数据
     assert(pgfault_num == 4);  // 确保缺页中断发生四次
     *(unsigned char *)0x4010 = 0x0d;  // 在虚拟地址0x4010写入数据
     assert(pgfault_num == 4);  // 确保缺页中断发生四次
}

// 检查交换内容
static inline int check_content_access(void)
{
    int ret = sm->check_swap();  // 调用交换管理器检查交换内容
    return ret;  // 返回检查结果
}

// 定义检查的物理页面、页表项、交换虚拟地址等相关数据
struct Page * check_rp[CHECK_VALID_PHY_PAGE_NUM];
pte_t * check_ptep[CHECK_VALID_PHY_PAGE_NUM];
unsigned int check_swap_addr[CHECK_VALID_VIR_PAGE_NUM];

extern free_area_t free_area;  // 引用外部的空闲内存区域结构体

#define free_list (free_area.free_list)  // 空闲列表
#define nr_free (free_area.nr_free)  // 空闲页面数量

// 检查交换机制
static void check_swap(void)
{
    // 备份内存环境
     int ret, count = 0, total = 0, i;
     list_entry_t *le = &free_list;
     while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);  // 遍历空闲链表，获取每个空闲页面
        assert(PageProperty(p));  // 确保页面有效
        count++, total += p->property;  // 统计空闲页面数量和属性
     }
     assert(total == nr_free_pages());  // 确保统计的总数与实际空闲页面数相同
     cprintf("BEGIN check_swap: count %d, total %d\n", count, total);

     // 设置物理页面环境
     struct mm_struct *mm = mm_create();  // 创建新的内存管理结构体
     assert(mm != NULL);

     extern struct mm_struct *check_mm_struct;
     assert(check_mm_struct == NULL);

     check_mm_struct = mm;  // 设置检查的内存管理结构体

     pde_t *pgdir = mm->pgdir = boot_pgdir;  // 设置页目录
     assert(pgdir[0] == 0);  // 确保页目录项为0

     struct vma_struct *vma = vma_create(BEING_CHECK_VALID_VADDR, CHECK_VALID_VADDR, VM_WRITE | VM_READ);  // 创建虚拟内存区域
     assert(vma != NULL);

     insert_vma_struct(mm, vma);  // 将虚拟内存区域插入到内存管理结构体中

     // 设置临时的页表
     cprintf("setup Page Table for vaddr 0X1000, so alloc a page\n");
     pte_t *temp_ptep = NULL;
     temp_ptep = get_pte(mm->pgdir, BEING_CHECK_VALID_VADDR, 1);  // 获取页表项
     assert(temp_ptep != NULL);  // 确保页表项有效
     cprintf("setup Page Table vaddr 0~4MB OVER!\n");

     for (i = 0; i < CHECK_VALID_PHY_PAGE_NUM; i++) {
          check_rp[i] = alloc_page();  // 分配物理页面
          assert(check_rp[i] != NULL);
          assert(!PageProperty(check_rp[i]));  // 确保页面没有属性
     }

     list_entry_t free_list_store = free_list;  // 存储当前空闲列表
     list_init(&free_list);  // 初始化空闲列表
     assert(list_empty(&free_list));  // 确保空闲列表为空

     unsigned int nr_free_store = nr_free;  // 存储当前空闲页面数量
     nr_free = 0;  // 设置空闲页面数量为0
     for (i = 0; i < CHECK_VALID_PHY_PAGE_NUM; i++) {
        free_pages(check_rp[i], 1);  // 释放页面
     }
     assert(nr_free == CHECK_VALID_PHY_PAGE_NUM);  // 确保空闲页面数量正确

     cprintf("set up init env for check_swap begin!\n");

     // 设置虚拟页面和物理页面的映射关系，供页面置换算法使用
     pgfault_num = 0;  // 重置缺页中断次数
     
     check_content_set();  // 设置检查内容
     assert(nr_free == 0);  // 确保空闲页面数量为0

     for (i = 0; i < MAX_SEQ_NO; i++)
         swap_out_seq_no[i] = swap_in_seq_no[i] = -1;

     for (i = 0; i < CHECK_VALID_PHY_PAGE_NUM; i++) {
         check_ptep[i] = 0;
         check_ptep[i] = get_pte(pgdir, (i + 1) * 0x1000, 0);  // 获取页表项
         assert(check_ptep[i] != NULL);  // 确保页表项有效
         assert(pte2page(*check_ptep[i]) == check_rp[i]);  // 确保页表项指向正确的物理页面
         assert((*check_ptep[i] & PTE_V));  // 确保页表项有效
     }
     cprintf("set up init env for check_swap over!\n");

     // 测试页面置换算法
     ret = check_content_access();
     assert(ret == 0);  // 确保测试成功
     
     // 恢复内存环境
     for (i = 0; i < CHECK_VALID_PHY_PAGE_NUM; i++) {
         free_pages(check_rp[i], 1);  // 释放页面
     }

     mm_destroy(mm);  // 销毁内存管理结构体
         
     nr_free = nr_free_store;  // 恢复空闲页面数量
     free_list = free_list_store;  // 恢复空闲列表

     le = &free_list;
     while ((le = list_next(le)) != &free_list) {
         struct Page *p = le2page(le, page_link);  // 遍历空闲链表
         count--, total -= p->property;  // 更新空闲页面数量
     }
     cprintf("count is %d, total is %d\n", count, total);  // 输出检查结果
     //assert(count == 0);  // 确保页面数量正确
     
     cprintf("check_swap() succeeded!\n");  // 输出检查成功的信息
}
