#ifndef __KERN_MM_MEMLAYOUT_H__  // 宏定义，防止头文件重复包含
#define __KERN_MM_MEMLAYOUT_H__

/* This file contains the definitions for memory management in our OS. */
/* 该文件包含我们操作系统中内存管理的定义 */

/* *
 * Virtual memory map:                                          Permissions
 *                                                              kernel/user
 *
 *     4G ------------------> +---------------------------------+
 *                            |                                 |
 *                            |         Empty Memory (*)        |
 *                            |                                 |
 *                            +---------------------------------+ 0xFB000000
 *                            |   Cur. Page Table (Kern, RW)    | RW/-- PTSIZE
 *     VPT -----------------> +---------------------------------+ 0xFAC00000
 *                            |        Invalid Memory (*)       | --/--
 *     KERNTOP -------------> +---------------------------------+ 0xF8000000
 *                            |                                 |
 *                            |    Remapped Physical Memory     | RW/-- KMEMSIZE
 *                            |                                 |
 *     KERNBASE ------------> +---------------------------------+ 0xC0000000
 *                            |                                 |
 *                            |                                 |
 *                            |                                 |
 *                            ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * (*) Note: The kernel ensures that "Invalid Memory" is *never* mapped.
 *     "Empty Memory" is normally unmapped, but user programs may map pages
 *     there if desired.
 *
 * */
/* 
 * 虚拟内存映射: 权限
 * kernel/user
 * 
 * 4G ------------------> +---------------------------------+
 *                        |                                 |
 *                        |         空闲内存 (*)            |
 *                        |                                 |
 *                        +---------------------------------+ 0xFB000000
 *                        |   当前页表 (内核, 读写)         | RW/-- PTSIZE
 * VPT -----------------> +---------------------------------+ 0xFAC00000
 *                        |        无效内存 (*)             | --/--
 * KERNTOP -------------> +---------------------------------+ 0xF8000000
 *                        |                                 |
 *                        |    重映射的物理内存              | RW/-- KMEMSIZE
 *                        |                                 |
 * KERNBASE ------------> +---------------------------------+ 0xC0000000
 *                        |                                 |
 *                        |                                 |
 *                        |                                 |
 *                        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * (*) 注: 内核确保 "无效内存" *永远* 不会被映射。
 *     "空闲内存" 通常是未映射的，但用户程序可以在此映射页面。
 * 
 */

/* All physical memory mapped at this address */
#define KERNBASE            0xFFFFFFFFC0200000 // = 0x80200000(物理内存里内核的起始位置, KERN_BEGIN_PADDR) + 0xFFFFFFFF40000000(偏移量, PHYSICAL_MEMORY_OFFSET)
// 所有物理内存都映射到这个虚拟地址

#define KMEMSIZE            0x7E00000          // the maximum amount of physical memory
// 最大物理内存大小
// 0x7E00000 = 0x8000000 - 0x200000
// QEMU 缺省的RAM为 0x80000000到0x88000000, 128MiB, 0x80000000到0x80200000被OpenSBI占用

#define KERNTOP             (KERNBASE + KMEMSIZE) // 计算内核顶部的虚拟地址

#define PHYSICAL_MEMORY_END         0x88000000
#define PHYSICAL_MEMORY_OFFSET      0xFFFFFFFF40000000
#define KERNEL_BEGIN_PADDR          0x80200000
#define KERNEL_BEGIN_VADDR          0xFFFFFFFFC0200000
// 定义物理内存的结束地址、偏移量和内核起始的物理/虚拟地址

#define KSTACKPAGE          2                           // # of pages in kernel stack
#define KSTACKSIZE          (KSTACKPAGE * PGSIZE)       // sizeof kernel stack
// 定义内核栈的大小为 2 页

#ifndef __ASSEMBLER__  // 如果不是汇编文件

#include <defs.h>
#include <atomic.h>
#include <list.h>

typedef uintptr_t pte_t;
typedef uintptr_t pde_t;
typedef pte_t swap_entry_t; //the pte can also be a swap entry
// 定义页表项（pte_t）、页目录项（pde_t）类型以及交换项（swap_entry_t）

/* *
 * struct Page - Page descriptor structures. Each Page describes one
 * physical page. In kern/mm/pmm.h, you can find lots of useful functions
 * that convert Page to other data types, such as physical address.
 * */
/* struct Page - 页面描述符结构体。每个 Page 描述一个物理页面。在 kern/mm/pmm.h 中，
   可以找到许多有用的函数，能将 Page 转换为其他数据类型，例如物理地址。 */
struct Page {
    int ref;                        // page frame's reference counter 页框引用计数器
    uint_t flags;                   // 描述页面状态的标志位
    uint_t visited;                  // 访问标志
    unsigned int property;          // 空闲内存块的数量，在第一次适配的物理内存管理器中使用
    list_entry_t page_link;         // 链接到空闲链表的节点
    list_entry_t pra_page_link;     // 用于页面置换算法的链表
    uintptr_t pra_vaddr;            // 用于页面置换算法的虚拟地址
};

/* Flags describing the status of a page frame */
#define PG_reserved                 0       // 如果该位=1：表示该页面被内核保留，不能在 alloc/free_pages 中使用；如果该位=0：表示该页面可以使用
#define PG_property                 1       // 如果该位=1：表示该页面是一个空闲内存块的起始页，且可以用来分配内存；如果该位=0：表示该页面已经被分配，或者该页面不是空闲内存块的起始页

#define SetPageReserved(page)       set_bit(PG_reserved, &((page)->flags))  // 设置该页面为保留状态
#define ClearPageReserved(page)     clear_bit(PG_reserved, &((page)->flags))  // 清除页面的保留状态
#define PageReserved(page)          test_bit(PG_reserved, &((page)->flags))  // 判断该页面是否被保留

#define SetPageProperty(page)       set_bit(PG_property, &((page)->flags))  // 设置该页面为空闲内存块的起始页
#define ClearPageProperty(page)     clear_bit(PG_property, &((page)->flags))  // 清除页面的空闲内存块属性
#define PageProperty(page)          test_bit(PG_property, &((page)->flags))  // 判断该页面是否为空闲内存块的起始页

// convert list entry to page
#define le2page(le, member)                 \
    to_struct((le), struct Page, member)
// 将链表节点转换为 Page 结构体指针

/* free_area_t - maintains a doubly linked list to record free (unused) pages */
typedef struct {
    list_entry_t free_list;         // 空闲页面链表头
    unsigned int nr_free;           // 空闲页面的数量
} free_area_t;

#endif /* !__ASSEMBLER__ */  // 如果不是汇编文件

#endif /* !__KERN_MM_MEMLAYOUT_H__ */  // 结束宏定义
