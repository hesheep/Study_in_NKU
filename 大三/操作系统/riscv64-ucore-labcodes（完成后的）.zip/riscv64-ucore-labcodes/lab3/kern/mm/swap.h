#ifndef __KERN_MM_SWAP_H__  // 如果没有定义__KERN_MM_SWAP_H__，则定义该头文件的宏，防止重复包含
#define __KERN_MM_SWAP_H__

#include <defs.h>  // 引入基本定义头文件
#include <memlayout.h>  // 引入内存布局相关头文件
#include <pmm.h>  // 引入物理内存管理相关头文件
#include <vmm.h>  // 引入虚拟内存管理相关头文件

/* *
 * swap_entry_t
 * --------------------------------------------
 * |         offset        |   reserved   | 0 |
 * --------------------------------------------
 *           24 bits            7 bits    1 bit
 * */

#define MAX_SWAP_OFFSET_LIMIT                   (1 << 24)  // 最大交换偏移量限制，2^24

extern size_t max_swap_offset;  // 最大交换偏移量变量的声明

/* *
 * swap_offset - 获取swap_entry（保存在pte中）对应的交换内存映射偏移量
 * */
#define swap_offset(entry) ({                                       \
               size_t __offset = (entry >> 8);                        \  // 将entry右移8位，得到偏移量
               if (!(__offset > 0 && __offset < max_swap_offset)) {    \  // 如果偏移量不合法，发生panic
                    panic("invalid swap_entry_t = %08x.\n", entry);    \  // 打印出错信息
               }                                                    \
               __offset;                                            \  // 返回合法的偏移量
          })

struct swap_manager  // 交换管理器结构体
{
     const char *name;  // 交换管理器的名称
     /* Global initialization for the swap manager */
     int (*init)            (void);  // 初始化交换管理器的函数指针
     /* Initialize the priv data inside mm_struct */
     int (*init_mm)         (struct mm_struct *mm);  // 初始化mm_struct内的私有数据
     /* Called when tick interrupt occured */
     int (*tick_event)      (struct mm_struct *mm);  // 在时钟中断发生时调用的函数
     /* Called when map a swappable page into the mm_struct */
     int (*map_swappable)   (struct mm_struct *mm, uintptr_t addr, struct Page *page, int swap_in);  // 将可交换页面映射到mm_struct中的函数
     /* When a page is marked as shared, this routine is called to
      * delete the addr entry from the swap manager */
     int (*set_unswappable) (struct mm_struct *mm, uintptr_t addr);  // 将页面标记为不可交换的函数
     /* Try to swap out a page, return then victim */
     int (*swap_out_victim) (struct mm_struct *mm, struct Page **ptr_page, int in_tick);  // 尝试交换出一个页面，并返回被交换出的页面
     /* check the page replacement algorithm */
     int (*check_swap)(void);  // 检查页面置换算法的函数
};

extern volatile int swap_init_ok;  // 声明交换初始化标志变量

// 以下是交换相关操作的函数声明：
int swap_init(void);  // 初始化交换管理器
int swap_init_mm(struct mm_struct *mm);  // 初始化mm_struct内的交换数据
int swap_tick_event(struct mm_struct *mm);  // 处理时钟中断事件
int swap_map_swappable(struct mm_struct *mm, uintptr_t addr, struct Page *page, int swap_in);  // 映射可交换页面
int swap_set_unswappable(struct mm_struct *mm, uintptr_t addr);  // 设置页面为不可交换
int swap_out(struct mm_struct *mm, int n, int in_tick);  // 执行页面交换出操作
int swap_in(struct mm_struct *mm, uintptr_t addr, struct Page **ptr_result);  // 执行页面交换进操作

//#define MEMBER_OFFSET(m,t) ((int)(&((t *)0)->m))  // 获取结构体成员在结构体中的偏移量
//#define FROM_MEMBER(m,t,a) ((t *)((char *)(a) - MEMBER_OFFSET(m,t)))  // 根据成员地址反推结构体地址

#endif  // 结束头文件保护宏
