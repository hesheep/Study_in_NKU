#include <defs.h>            // 包含基本定义
#include <riscv.h>           // 包含与 RISC-V 架构相关的定义
#include <stdio.h>           // 标准 I/O 操作
#include <string.h>          // 字符串处理函数
#include <swap.h>            // 换页相关定义
#include <swap_fifo.h>       // FIFO 换页算法的头文件
#include <list.h>            // 双向链表的定义与操作函数

/* 
 * [wikipedia] 最简单的页面置换算法 (PRA) 是 FIFO 算法。FIFO 算法是一种开销较低且实现简单的页面置换算法。
 * 系统用队列跟踪所有内存中的页面，最新页面在队列尾部，最旧页面在队列头部。
 * 当需要替换页面时，选择队列头部的页面（即最早的页面）。虽然 FIFO 实现简单，
 * 但在实际应用中表现较差，因此很少直接使用它。该算法会遇到 Belady 异常。
 * 
 * FIFO PRA 的具体细节：
 * (1) 准备：为了实现 FIFO PRA，需要管理所有可换出的页面，按照时间顺序将它们链接到 `pra_list_head` 中。
 *     首先需要熟悉 `list.h` 中的双向链表结构，例如 `list_init`, `list_add`, `list_del` 等操作。
 *     还有一些宏，例如 `le2page` 可以将一般链表转换为特定结构体。
 */

list_entry_t pra_list_head; // 用于存储可换出的页面链表的头节点

/*
 * (2) _fifo_init_mm：初始化 pra_list_head 并将其地址赋给 `mm->sm_priv`。
 *     通过 `mm_struct` 的 `sm_priv` 字段，可以访问 FIFO PRA。
 */
static int
_fifo_init_mm(struct mm_struct *mm)
{     
     list_init(&pra_list_head);  // 初始化链表头
     mm->sm_priv = &pra_list_head;  // 将链表头的地址存储到 mm->sm_priv
     //cprintf(" mm->sm_priv %x in fifo_init_mm\n",mm->sm_priv); // 调试信息（已注释）
     return 0;  // 返回 0 表示成功
}

/*
 * (3) _fifo_map_swappable：根据 FIFO PRA，将最新到达的页面链接到 pra_list_head 队列的尾部。
 */
static int
_fifo_map_swappable(struct mm_struct *mm, uintptr_t addr, struct Page *page, int swap_in)
{
    list_entry_t *head = (list_entry_t *)mm->sm_priv;  // 获取链表头
    list_entry_t *entry = &(page->pra_page_link);      // 获取页面的链表节点

    assert(entry != NULL && head != NULL);  // 确保链表头和节点不为空
    // 将最新到达的页面插入到链表头的后面
    list_add(head, entry);  // 将新的页面插入到队列中,在list.h中定义
    return 0;  // 返回 0 表示成功
}

/*
 * (4) _fifo_swap_out_victim：根据 FIFO PRA，从 pra_list_head 队列中移除最早到达的页面，
 *                            并将该页面的地址存储到 `ptr_page`。
 */
static int
_fifo_swap_out_victim(struct mm_struct *mm, struct Page **ptr_page, int in_tick)
{
    list_entry_t *head = (list_entry_t *)mm->sm_priv;  // 获取链表头
    assert(head != NULL);  // 确保链表头不为空
    assert(in_tick == 0);  // 确保没有 tick 事件干扰

    /* 选择被替换的页面 */
    list_entry_t *entry = list_prev(head);  // 获取队列中的最前面节点（最旧页面）
    if (entry != head) {  // 如果队列不为空
        list_del(entry);  // 将该节点从链表中移除
        *ptr_page = le2page(entry, pra_page_link);  // 将节点转换为 Page 并存储到 ptr_page
    } else {
        *ptr_page = NULL;  // 如果没有页面可替换，设置为 NULL
    }
    return 0;  // 返回 0 表示成功
}

/*
 * (5) _fifo_check_swap：检查 FIFO 页面置换的逻辑是否正确。
 */
static int
_fifo_check_swap(void) {
    cprintf("write Virt Page c in fifo_check_swap\n");
    *(unsigned char *)0x3000 = 0x0c;  // 写入虚拟页面 c
    assert(pgfault_num == 4);         // 确保缺页异常数为 4
    cprintf("write Virt Page a in fifo_check_swap\n");
    *(unsigned char *)0x1000 = 0x0a;  // 写入虚拟页面 a
    assert(pgfault_num == 4);         // 确保缺页异常数为 4
    cprintf("write Virt Page d in fifo_check_swap\n");
    *(unsigned char *)0x4000 = 0x0d;  // 写入虚拟页面 d
    assert(pgfault_num == 4);         // 确保缺页异常数为 4
    cprintf("write Virt Page b in fifo_check_swap\n");
    *(unsigned char *)0x2000 = 0x0b;  // 写入虚拟页面 b
    assert(pgfault_num == 4);         // 确保缺页异常数为 4
    cprintf("write Virt Page e in fifo_check_swap\n");
    *(unsigned char *)0x5000 = 0x0e;  // 写入虚拟页面 e
    assert(pgfault_num == 5);         // 确保缺页异常数为 5
    cprintf("write Virt Page b in fifo_check_swap\n");
    *(unsigned char *)0x2000 = 0x0b;  // 写入虚拟页面 b
    assert(pgfault_num == 5);         // 确保缺页异常数为 5
    cprintf("write Virt Page a in fifo_check_swap\n");
    *(unsigned char *)0x1000 = 0x0a;  // 写入虚拟页面 a
    assert(pgfault_num == 6);         // 确保缺页异常数为 6
    cprintf("write Virt Page b in fifo_check_swap\n");
    *(unsigned char *)0x2000 = 0x0b;  // 写入虚拟页面 b
    assert(pgfault_num == 7);         // 确保缺页异常数为 7
    cprintf("write Virt Page c in fifo_check_swap\n");
    *(unsigned char *)0x3000 = 0x0c;  // 写入虚拟页面 c
    assert(pgfault_num == 8);         // 确保缺页异常数为 8
    cprintf("write Virt Page d in fifo_check_swap\n");
    *(unsigned char *)0x4000 = 0x0d;  // 写入虚拟页面 d
    assert(pgfault_num == 9);         // 确保缺页异常数为 9
    cprintf("write Virt Page e in fifo_check_swap\n");
    *(unsigned char *)0x5000 = 0x0e;  // 写入虚拟页面 e
    assert(pgfault_num == 10);        // 确保缺页异常数为 10
    cprintf("write Virt Page a in fifo_check_swap\n");
    assert(*(unsigned char *)0x1000 == 0x0a);  // 确保虚拟页面 a 的值正确
    *(unsigned char *)0x1000 = 0x0a;           // 再次写入虚拟页面 a
    assert(pgfault_num == 11);                 // 确保缺页异常数为 11
    return 0;  // 返回 0 表示成功
}

/*
 * (6) _fifo_init：初始化函数
 */
static int
_fifo_init(void)
{
    return 0;  // 返回 0 表示成功
}

/*
 * (7) _fifo_set_unswappable：设置页面不可换出（此处为空实现）。
 */
static int
_fifo_set_unswappable(struct mm_struct *mm, uintptr_t addr)
{
    return 0;  // 返回 0 表示成功
}

/*
 * (8) _fifo_tick_event：处理时钟事件（此处为空实现）。
 */
static int
_fifo_tick_event(struct mm_struct *mm)
{
    return 0;  // 返回 0 表示成功
}

/*
 * 定义 FIFO 页面置换算法的 swap_manager 结构体。
 */

struct swap_manager swap_manager_fifo =
{
     .name            = "fifo swap manager",
     .init            = &_fifo_init,
     .init_mm         = &_fifo_init_mm,
     .tick_event      = &_fifo_tick_event,
     .map_swappable   = &_fifo_map_swappable,
     .set_unswappable = &_fifo_set_unswappable,
     .swap_out_victim = &_fifo_swap_out_victim,
     .check_swap      = &_fifo_check_swap,
};
