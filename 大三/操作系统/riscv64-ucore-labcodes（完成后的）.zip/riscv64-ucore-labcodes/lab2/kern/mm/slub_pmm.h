#ifndef __KERN_MM_SLUB_PMM_H__
#define __KERN_MM_SLUB_PMM_H__
#include <pmm.h>


extern const struct pmm_manager slub_pmm_manager;

#endif /* !__KERN_MM_SLUB_PMM_H__ */
