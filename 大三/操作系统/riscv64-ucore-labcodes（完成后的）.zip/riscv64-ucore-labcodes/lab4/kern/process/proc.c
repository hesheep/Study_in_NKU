#include <proc.h>
#include <kmalloc.h>
#include <string.h>
#include <sync.h>
#include <pmm.h>
#include <error.h>
#include <sched.h>
#include <elf.h>
#include <vmm.h>
#include <trap.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>


/* ------------- 进程/线程机制设计与实现 -------------  
(一个简化的 Linux 进程/线程机制)  
简介：  
  ucore 实现了一个简单的进程/线程机制。进程包含独立的内存空间，至少一个用于执行的线程，内核数据（用于管理）、处理器状态（用于上下文切换）、文件（在 lab6 中实现）等。  
  ucore 需要高效地管理所有这些细节。在 ucore 中，线程只是特殊类型的进程（共享进程的内存）。  
------------------------------  
进程状态            :      含义                  -- 原因  
    PROC_UNINIT     :   未初始化                -- alloc_proc  
    PROC_SLEEPING   :   睡眠状态                -- try_free_pages, do_wait, do_sleep  
    PROC_RUNNABLE   :   可运行（可能正在运行）  -- proc_init, wakeup_proc  
    PROC_ZOMBIE     :   几乎已终止             -- do_exit  

-----------------------------  
进程状态转换：

  alloc_proc                                 RUNNING  
      +                                   +--<----<--+  
      +                                   + proc_run +  
      V                                   +-->---->--+  
PROC_UNINIT -- proc_init/wakeup_proc --> PROC_RUNNABLE -- try_free_pages/do_wait/do_sleep --> PROC_SLEEPING --  
                                           A      +                                                           +  
                                           |      +--- do_exit --> PROC_ZOMBIE                                +  
                                           +                                                                  +  
                                           -----------------------wakeup_proc----------------------------------  
-----------------------------  
进程关系  
父进程:           proc->parent  （proc 是子进程）  
子进程:           proc->cptr    （proc 是父进程）  
前一个兄弟进程:   proc->optr    （proc 是下一个兄弟进程）  
下一个兄弟进程:   proc->yptr    （proc 是前一个兄弟进程）  

-----------------------------  
与进程相关的系统调用：  
SYS_exit        : 进程退出                              -->do_exit  
SYS_fork        : 创建子进程，复制内存管理结构          -->do_fork-->wakeup_proc  
SYS_wait        : 等待进程                              -->do_wait  
SYS_exec        : fork 后，进程执行程序                 -->加载程序并刷新内存管理结构  
SYS_clone       : 创建子线程                            -->do_fork-->wakeup_proc  
SYS_yield       : 进程标记自身需要重新调度             -->proc->need_sched=1，然后调度器会重新调度该进程  
SYS_sleep       : 进程休眠                              -->do_sleep  
SYS_kill        : 杀死进程                              -->do_kill-->proc->flags |= PF_EXITING  
                                                    -->wakeup_proc-->do_wait-->do_exit  
SYS_getpid      : 获取进程的 pid  
*/


// the process set's list
list_entry_t proc_list; //所有进程控制块的双向线性列表，proc_struct中的成员变量list_link将链接入这个链表中。

#define HASH_SHIFT          10                       // 哈希表的位移量，用于计算哈希表大小和哈希函数。
#define HASH_LIST_SIZE      (1 << HASH_SHIFT)        // 哈希表的大小，等于 2 的 HASH_SHIFT 次方。
#define pid_hashfn(x)       (hash32(x, HASH_SHIFT))  // 哈希函数，通过 32 位哈希算法将 pid 映射到哈希表中。

// 基于 pid 的进程集合哈希表
static list_entry_t hash_list[HASH_LIST_SIZE];//所有进程控制块的哈希表，proc_struct中的成员变量hash_link将基于pid链接入这个哈希表中

// 空闲进程（idle 进程）
struct proc_struct *idleproc = NULL;
// 初始化进程（init 进程）
struct proc_struct *initproc = NULL;//本实验：指向一个内核线程。本实验以后，此指针将指向第一个用户态进程。
// 当前进程
struct proc_struct *current = NULL; //当前占用CPU且处于“运行”状态进程控制块指针，通常是只读的，只有在进程切换的时候才修改

static int nr_process = 0;// 系统中的进程总数

void kernel_thread_entry(void);
void forkrets(struct trapframe *tf);
void switch_to(struct context *from, struct context *to);

// alloc_proc - alloc a proc_struct and init all fields of proc_struct
//负责分配并返回一个新的struct proc_struct结构，用于存储新建立的内核线程的管理信息
static struct proc_struct *
alloc_proc(void) {
    // 使用 kmalloc 分配内存，大小为 struct proc_struct 的尺寸
    struct proc_struct *proc = kmalloc(sizeof(struct proc_struct));
    if (proc != NULL) {
    //LAB4:EXERCISE1 YOUR CODE
    /*
     * below fields in proc_struct need to be initialized
     *       enum proc_state state;                      // Process state
     *       int pid;                                    // Process ID
     *       int runs;                                   // the running times of Proces
     *       uintptr_t kstack;                           // Process kernel stack
     *       volatile bool need_resched;                 // bool value: need to be rescheduled to release CPU?
     *       struct proc_struct *parent;                 // the parent process
     *       struct mm_struct *mm;                       // Process's memory management field
     *       struct context context;                     // Switch here to run process
     *       struct trapframe *tf;                       // Trap frame for current interrupt
     *       uintptr_t cr3;                              // CR3 register: the base addr of Page Directroy Table(PDT)
     *       uint32_t flags;                             // Process flag
     *       char name[PROC_NAME_LEN + 1];               // Process name
     */
        proc->state = PROC_UNINIT;                       //给进程设置为未初始化状态
        proc->pid = -1;                                  //未初始化的进程，其pid为-1
        proc->runs = 0;                                  //初始化时间片,刚刚初始化的进程，运行时间一定为零	
        proc->kstack = 0;                                //内核栈地址,该进程分配的地址为0，因为还没有执行，也没有被重定位，因为默认地址都是从0开始的。
        proc->need_resched = 0;                          //不需要调度
        proc->parent = NULL;                             //父进程为空
        proc->mm = NULL;                                 //虚拟内存为空
        memset(&(proc->context), 0, sizeof(struct context));//初始化上下文为0
        proc->tf = NULL;                                 //中断帧指针为空
        proc->cr3 = boot_cr3;                            //页目录为内核页目录表的基址
        proc->flags = 0;                                 //标志位为0
        memset(proc->name, 0, PROC_NAME_LEN+1);          //进程名为空字符串
    }
    return proc;// 返回新分配并初始化的 struct proc_struct
}

// set_proc_name - set the name of proc
char *
set_proc_name(struct proc_struct *proc, const char *name) {
    // 将进程名称字段清零，确保旧名称被清除
    memset(proc->name, 0, sizeof(proc->name));
    // 将传入的名称复制到进程的名称字段，最多复制 PROC_NAME_LEN 个字符
    return memcpy(proc->name, name, PROC_NAME_LEN);
}

// get_proc_name - get the name of proc
char *
get_proc_name(struct proc_struct *proc) {
    // 定义一个静态字符数组，用于存储进程名称，长度为 PROC_NAME_LEN + 1（多一个位置存放字符串结束符）
    static char name[PROC_NAME_LEN + 1];
    // 将该数组清零，确保不存在旧数据
    memset(name, 0, sizeof(name));
    // 从进程的名称字段复制最多 PROC_NAME_LEN 个字符到静态数组中，并返回数组地址
    return memcpy(name, proc->name, PROC_NAME_LEN);
}

// get_pid - 为进程分配一个唯一的 PID
static int
get_pid(void) {
    // 确保 MAX_PID 大于 MAX_PROCESS，否则分配的 PID 可能不够用
    static_assert(MAX_PID > MAX_PROCESS);

    struct proc_struct *proc;                  // 临时变量，用于指向当前遍历的进程控制块
    list_entry_t *list = &proc_list, *le;      // 指向全局进程列表的指针和用于遍历的指针
    static int next_safe = MAX_PID;            // 下一个安全的最大 PID（当前还未被分配）
    static int last_pid = MAX_PID;             // 上一次分配的 PID

    // 更新 last_pid，尝试分配下一个 PID
    if (++last_pid >= MAX_PID) {               // 如果 last_pid 超过了最大值
        last_pid = 1;                          // 从 1 开始重新分配
        goto inside;                           // 跳转到 inside 标签重新检查
    }

    if (last_pid >= next_safe) {               // 如果 last_pid 超过或等于下一个安全值
    inside:
        next_safe = MAX_PID;                   // 重置 next_safe 为最大值
    repeat:
        le = list;                             // 从进程列表的头部开始
        while ((le = list_next(le)) != list) { // 遍历整个进程列表
            proc = le2proc(le, list_link);     // 获取当前节点对应的进程控制块
            if (proc->pid == last_pid) {       // 如果当前 PID 已被使用
                if (++last_pid >= next_safe) { // 尝试分配下一个 PID
                    if (last_pid >= MAX_PID) { // 如果超过最大值，重新从 1 开始
                        last_pid = 1;
                    }
                    next_safe = MAX_PID;       // 重置 next_safe 为最大值
                    goto repeat;               // 重新检查所有进程
                }
            }
            else if (proc->pid > last_pid && next_safe > proc->pid) { 
                // 如果当前进程的 PID 大于 last_pid 且比 next_safe 小
                next_safe = proc->pid;         // 更新 next_safe 为更小的安全值
            }
        }
    }

    // 返回分配的唯一 PID
    return last_pid;
}
//确保唯一性：
//每次分配一个新的 last_pid 时，会遍历当前所有进程的列表，检查是否有其他进程已经占用了这个 last_pid。
//如果发现冲突，会递增 last_pid 并继续检查，直到找到一个未被占用的值。
//如果 last_pid 超过了 MAX_PID，会从 1 重新开始分配，并重新遍历整个进程列表，确保分配的 PID 唯一。
//动态更新 next_safe 提高效率：
//遍历进程列表时，除了检查是否存在重复的 last_pid，还会更新 next_safe，记录当前范围内最小的未被占用的 PID。
//如果找到比当前 last_pid 更大的 PID 且比 next_safe 小，会将其更新为新的 next_safe，从而减少遍历的次数和范围。



// proc_run - 将指定的进程 "proc" 切换到 CPU 上运行
// 注意：在调用 switch_to 之前，需要加载 "proc" 对应的新页目录表基地址（PDT）
void
proc_run(struct proc_struct *proc) {
    if (proc != current) { // 如果目标进程不是当前正在运行的进程，才需要进行切换
        // LAB4:EXERCISE3 YOUR CODE
        /*
        * 可用的宏和函数：
        *   local_intr_save():        禁用中断并保存当前中断状态
        *   local_intr_restore():     恢复之前的中断状态
        *   lcr3():                   设置 CR3 寄存器的值（用于切换页目录表）
        *   switch_to():              在两个进程之间切换上下文
        */
       bool intr_flag; // 定义一个布尔变量，用于保存当前中断状态。
       struct proc_struct *prev = current, *next = proc; // 保存当前进程为 prev，将要切换到的目标进程为 next。
       local_intr_save(intr_flag); // 关闭中断，并保存当前中断状态到 intr_flag。
       {
            current = proc; // 将全局变量 current 更新为目标进程 next。
            lcr3(next->cr3); // 更新 CR3 寄存器为目标进程的页目录基地址。
            switch_to(&(prev->context), &(next->context)); // 切换上下文，从当前进程切换到目标进程。
       }
       local_intr_restore(intr_flag); // 恢复之前的中断状态。
    }
}

// forkret - 新线程/进程的第一个内核入口点
// 注意：forkret 的地址会在 copy_thread 函数中设置
//       在 switch_to 函数切换到新线程/进程后，新进程会从这里开始执行
static void
forkret(void) {
    forkrets(current->tf); // 调用 forkrets 函数，并将当前进程的中断帧指针 (trapframe) 传入
}


// hash_proc - add proc into proc hash_list
static void
hash_proc(struct proc_struct *proc) {
    // 根据进程的 PID 计算哈希值，获取哈希表索引，并将进程的 hash_link 添加到相应的位置
    list_add(hash_list + pid_hashfn(proc->pid), &(proc->hash_link));
}

// find_proc - 根据 pid 从进程哈希表中查找进程
struct proc_struct *
find_proc(int pid) {
    // 如果 pid 在有效范围内（大于 0 且小于最大 PID）
    if (0 < pid && pid < MAX_PID) {
        // 根据 pid 计算哈希值，获取哈希表中对应的链表
        list_entry_t *list = hash_list + pid_hashfn(pid), *le = list;
        
        // 遍历该链表，查找匹配的进程
        while ((le = list_next(le)) != list) {
            // 获取当前链表节点对应的进程结构体
            struct proc_struct *proc = le2proc(le, hash_link);
            // 如果找到匹配的进程 PID，则返回该进程
            if (proc->pid == pid) {
                return proc;
            }
        }
    }
    // 如果没有找到匹配的进程，返回 NULL
    return NULL;
}


// kernel_thread - 使用 "fn" 函数创建一个内核线程
// 注意：临时的 trapframe tf 内容将会在 do_fork -> copy_thread 函数中被复制到 proc->tf
int
kernel_thread(int (*fn)(void *), void *arg, uint32_t clone_flags) {
    // 对trameframe，也就是我们程序的一些上下文进行一些初始化
    struct trapframe tf;//保存内核线程的临时中断帧
    memset(&tf, 0, sizeof(struct trapframe));

    // 设置内核线程的参数和函数指针
    tf.gpr.s0 = (uintptr_t)fn;// s0 寄存器保存函数指针
    tf.gpr.s1 = (uintptr_t)arg;// s1 寄存器保存函数参数
    // 设置 trapframe 中的 status 寄存器（SSTATUS）
    // SSTATUS_SPP：Supervisor Previous Privilege（设置为 supervisor 模式，因为这是一个内核线程）
    // SSTATUS_SPIE：Supervisor Previous Interrupt Enable（设置为启用中断，因为这是一个内核线程）
    // SSTATUS_SIE：Supervisor Interrupt Enable（设置为禁用中断，因为我们不希望该线程被中断）
    //读取sstatus寄存器的值，然后根据特定的位操作，设置SPP和SPIE位，并同时清除SIE位，从而实现特权级别切换、保留中断使能状态并禁用中断的操作
    tf.status = (read_csr(sstatus) | SSTATUS_SPP | SSTATUS_SPIE) & ~SSTATUS_SIE;
    // 将入口点（epc）设置为 kernel_thread_entry 函数，作用实际上是将pc指针指向它(*trapentry.S会用到)
    //在kernel_thread_entry函数中，把参数s1（放的是传给函数的参数）放在了a0寄存器，并跳转到s0（放的是新进程要执行的函数）执行我们指定的函数
    //在这里就是执行init_main函数，参数是“Hello World!”
    tf.epc = (uintptr_t)kernel_thread_entry;
    // 使用 do_fork 创建一个新进程（内核线程），这样才真正用设置的tf创建新进程。
    return do_fork(clone_flags | CLONE_VM, 0, &tf);//把中断帧的指针传递给do_fork函数
}

// setup_kstack - 为进程分配大小为 KSTACKPAGE 的内核栈页
static int
setup_kstack(struct proc_struct *proc) {
    // 调用 alloc_pages 函数为内核栈分配 KSTACKPAGE 页
    struct Page *page = alloc_pages(KSTACKPAGE);

    if (page != NULL) {  // 如果成功分配了页面
        // 将分配到的页面转换为内核虚拟地址，并将该地址赋值给进程的 kstack 成员
        proc->kstack = (uintptr_t)page2kva(page);
        return 0;  // 返回 0 表示分配成功
    }
    return -E_NO_MEM;  // 如果页面分配失败，返回 -E_NO_MEM 表示内存不足
}


// put_kstack - 释放进程内核栈的内存空间
static void
put_kstack(struct proc_struct *proc) {
    // 将进程的内核栈地址（kstack）转换为物理页面，并释放对应的内存页面
    free_pages(kva2page((void *)(proc->kstack)), KSTACKPAGE);
}


// copy_mm - 根据 clone_flags 来复制或共享进程 "current" 的内存管理结构 (mm)
//         - 如果 clone_flags & CLONE_VM，则 "共享" 内存管理结构；否则 "复制"
// 目前只是将 current->mm 设置为 NULL，因为在实验四中只能创建内核线程，
// 进程的 mm 结构体主要描述用户态的内存空间，但目前 mm 在实验中尚未使用。
static int
copy_mm(uint32_t clone_flags, struct proc_struct *proc) {
    // 确保当前进程没有内存管理结构（mm）
    assert(current->mm == NULL);

    // 目前的实验中不需要做任何操作，直接返回 0
    /* do nothing in this project */
    return 0;
}


// copy_thread - 设置进程的 trapframe 在内核栈的顶部，并设置内核入口点和进程的栈
static void
copy_thread(struct proc_struct *proc, uintptr_t esp, struct trapframe *tf) {
    // 在分配的内核栈上分配空间保存 trapframe
    // 这里通过将 proc->kstack + KSTACKSIZE - sizeof(struct trapframe) 指定内核栈的顶部，
    // 然后将传入的 tf 内容复制到该位置，即为新进程设置一个 trapframe。
    proc->tf = (struct trapframe *)(proc->kstack + KSTACKSIZE - sizeof(struct trapframe));
    *(proc->tf) = *tf;

    // 将 a0 寄存器设置为 0，表示这是一个子进程
    proc->tf->gpr.a0 = 0;

    // 设置栈指针（sp）。如果 esp 为 0，表示调用方没有指定栈指针，则使用 proc->tf 作为栈顶。
    // 如果 esp 不为 0，则使用传入的 esp 作为栈指针。
    proc->tf->gpr.sp = (esp == 0) ? (uintptr_t)proc->tf : esp;

    // 设置上下文中的返回地址（ra），即内核入口函数的地址。
    proc->context.ra = (uintptr_t)forkret;

    // 设置上下文中的栈指针（sp），将其指向新进程的 trapframe，
    // 因为在上下文切换时，栈指针会指向当前执行的上下文，这里是指向新进程的 trapframe。
    proc->context.sp = (uintptr_t)(proc->tf);
}


/* do_fork -     parent process for a new child process
 * @clone_flags: used to guide how to clone the child process
 * @stack:       the parent's user stack pointer. if stack==0, It means to fork a kernel thread.
 * @tf:          the trapframe info, which will be copied to child process's proc->tf
 */
//用于创建一个子进程
int do_fork(uint32_t clone_flags, uintptr_t stack, struct trapframe *tf) {
    int ret = -E_NO_FREE_PROC;// 默认返回值为 -E_NO_FREE_PROC，表示没有可用的进程
    struct proc_struct *proc;
    if (nr_process >= MAX_PROCESS) {// 检查是否超出最大进程数限制
        goto fork_out;
    }
    ret = -E_NO_MEM;// 默认错误是内存不足
    //LAB4:EXERCISE2 YOUR CODE
    /*
     * Some Useful MACROs, Functions and DEFINEs, you can use them in below implementation.
     * MACROs or Functions:
     *   alloc_proc:   create a proc struct and init fields (lab4:exercise1)
     *   setup_kstack: alloc pages with size KSTACKPAGE as process kernel stack
     *   copy_mm:      process "proc" duplicate OR share process "current"'s mm according clone_flags
     *                 if clone_flags & CLONE_VM, then "share" ; else "duplicate"
     *   copy_thread:  setup the trapframe on the  process's kernel stack top and
     *                 setup the kernel entry point and stack of process
     *   hash_proc:    add proc into proc hash_list
     *   get_pid:      alloc a unique pid for process
     *   wakeup_proc:  set proc->state = PROC_RUNNABLE
     * VARIABLES:
     *   proc_list:    the process set's list
     *   nr_process:   the number of process set
     */

    //    1. call alloc_proc to allocate a proc_struct
    //    2. call setup_kstack to allocate a kernel stack for child process
    //    3. call copy_mm to dup OR share mm according clone_flag
    //    4. call copy_thread to setup tf & context in proc_struct
    //    5. insert proc_struct into hash_list && proc_list
    //    6. call wakeup_proc to make the new child process RUNNABLE
    //    7. set ret vaule using child proc's pid

    //1
    proc = alloc_proc();                 // 分配新的进程结构体并初始化其字段
    if(proc==NULL)                       // 如果进程结构体分配失败
    {
        goto bad_fork_cleanup_proc;
    }
    proc->parent = current;              // 设置新进程的父进程为当前进程  
    //2             
    if(setup_kstack(proc))               // 为新进程分配内核栈
    {
        goto bad_fork_cleanup_kstack;    // 如果内核栈分配失败，进入清理流程
    }  
    //3    
    if(copy_mm(clone_flags, proc))       // 根据 clone_flags 复制或共享内存管理结构
    {
        goto fork_out;                   // 如果内存管理结构复制失败，跳到退出处理
    }
    //4
    copy_thread(proc, stack, tf);        // 设置子进程trapframe和线程上下文
    int pid = get_pid();                 // 分配一个唯一的进程 ID
    proc->pid = pid;                     // 将 PID 分配给子进程
    //5
    hash_proc(proc);                     // 将子进程插入哈希表，便于快速查找
    list_add(&proc_list, &(proc->list_link)); // 将子进程加入进程链表
    nr_process++;                        // 增加全局进程计数器
    //6
    wakeup_proc(proc);                   // 设置子进程状态为可运行（`PROC_RUNNABLE`），在sched.c中定义
    //7
    ret = proc->pid;                     // 返回子进程的 PID

    

fork_out:
    return ret;

bad_fork_cleanup_kstack:
    put_kstack(proc);// 如果内核栈分配失败，释放分配的内核栈
bad_fork_cleanup_proc:
    kfree(proc);// 如果进程结构体分配失败，释放结构体
    goto fork_out;
}

// do_exit - 由 sys_exit 调用，负责进程退出操作
//   1. 调用 exit_mmap、put_pgdir 和 mm_destroy 来释放进程几乎所有的内存空间
//   2. 将进程的状态设置为 PROC_ZOMBIE，然后调用 wakeup_proc(parent) 请求父进程回收资源
//   3. 调用调度器切换到其他进程

int do_exit(int error_code) {
    panic("process exit!!.\n");  // 此处调用 panic，意味着进程退出时发生了严重错误，程序会打印错误信息并中止执行
}


// init_main - the second kernel thread used to create user_main kernel threads
//在后续的实验中，init_main的工作就是创建特定的其他内核线程或用户进程
static int
init_main(void *arg) {
    cprintf("this initproc, pid = %d, name = \"%s\"\n", current->pid, get_proc_name(current));
    cprintf("To U: \"%s\".\n", (const char *)arg);
    cprintf("To U: \"en.., Bye, Bye. :)\"\n");
    return 0;
}

// proc_init - 设置第一个内核线程 idleproc，并创建第二个内核线程 init_main
void
proc_init(void) {
    int i;

    // 初始化进程链表
    list_init(&proc_list);
    // 初始化哈希表中的所有列表
    for (i = 0; i < HASH_LIST_SIZE; i ++) {
        list_init(hash_list + i);
    }


    // 分配并初始化第一个进程 idleproc（空闲进程）
    if ((idleproc = alloc_proc()) == NULL) {
        panic("cannot alloc idleproc.\n");
    }

    // 检查进程结构的初始化是否正确
    int *context_mem = (int*) kmalloc(sizeof(struct context));
    memset(context_mem, 0, sizeof(struct context));
    int context_init_flag = memcmp(&(idleproc->context), context_mem, sizeof(struct context));

    int *proc_name_mem = (int*) kmalloc(PROC_NAME_LEN);
    memset(proc_name_mem, 0, PROC_NAME_LEN);
    int proc_name_flag = memcmp(&(idleproc->name), proc_name_mem, PROC_NAME_LEN);
    // 如果初始化时的进程结构没有问题，打印验证信息
    if(idleproc->cr3 == boot_cr3 && idleproc->tf == NULL && !context_init_flag
        && idleproc->state == PROC_UNINIT && idleproc->pid == -1 && idleproc->runs == 0
        && idleproc->kstack == 0 && idleproc->need_resched == 0 && idleproc->parent == NULL
        && idleproc->mm == NULL && idleproc->flags == 0 && !proc_name_flag
    ){
        cprintf("alloc_proc() correct!\n");

    }

    //对idleproc内核线程进行进一步初始化
    idleproc->pid = 0;//身份确定，表面idleproc是第0个内核线程
    idleproc->state = PROC_RUNNABLE;//由“初始“态变为“准备工作”态
    idleproc->kstack = (uintptr_t)bootstack;//设置idleproc使用的内核栈的起始地址
    idleproc->need_resched = 1;//当cpu_idle函数执行时，会立马切换进程执行
    set_proc_name(idleproc, "idle");
    nr_process ++;

    current = idleproc;//当前运行进程为idle



    // 创建第二个内核线程 init_main，并传递参数 "Hello world!!"
    int pid = kernel_thread(init_main, "Hello world!!", 0);//通过调用kernel_thread函数创建了一个内核线程init_main,输出一些字符串
    if (pid <= 0) {
        panic("create init_main failed.\n");
    }
    // 获取 init_main 进程的描述符
    initproc = find_proc(pid);
    set_proc_name(initproc, "init");// 设置进程名称为 "init"
    // 确保 idleproc 和 initproc 被正确初始化
    assert(idleproc != NULL && idleproc->pid == 0);
    assert(initproc != NULL && initproc->pid == 1);
}

// cpu_idle - at the end of kern_init, the first kernel thread idleproc will do below works
//idleproc通过执行这个函数让出CPU
void cpu_idle(void) {
    while (1) {
        if (current->need_resched) {
            schedule();
        }
    }
}

